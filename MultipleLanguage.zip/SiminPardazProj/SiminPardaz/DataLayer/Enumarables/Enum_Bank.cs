﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Enumarables
{
    public enum Enum_Bank
    {
        MELLAT,
        PASARGAD,
        SAMAN,
        PARSIAN,
        IRANKISH,
        UP,
        ZARINPAL,
        NEXTPAY,
        MELLI,
        EGHTESAD_NOVIN,
        WEBMONEY,
        SADERAT_MABNA
    }
}
