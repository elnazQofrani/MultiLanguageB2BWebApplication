﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Enumarables
{
    public enum Enum_SmsType
    {
        NEWSLETTER,
        REAGENT,
        ORDER_POST,
        ACCOUNT_REGISTER,
        PAYMENT_SUCCESS,
        PAYMENT_SUCCESS_ADMIN,
        COMMENT,
        QUESTION,
        QUESTION_ANSWER,
        PRODUCT_NOTIFY,
        REBATE,
        FORGET_PASSWORD,
        PRODUCT_NOTIFY_DISCOUNT,
        INQUIRY
    }
}
