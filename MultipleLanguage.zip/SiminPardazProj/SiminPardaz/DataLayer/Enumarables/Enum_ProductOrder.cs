﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Enumarables
{
    public enum Enum_ProductOrder
    {
        NONE,
        NEW,
        OLD,
        RANDOM,
        PRICE_MIN_TO_MAX,
        PRICE_MAX_TO_MIN,
        MORE_SELL,
        SHOWNUMBER,
        SHOWNUMBER_DESC,
        MORE_VISIT,
        MORE_LIKE,
        MORE_RATING,
        UPDATE,
        UPDATE_DESC,
        ID,
        ID_DESC
    }
}
