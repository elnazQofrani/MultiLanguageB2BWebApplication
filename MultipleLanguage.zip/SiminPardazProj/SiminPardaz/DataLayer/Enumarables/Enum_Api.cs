﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Enumarables
{
    public enum Enum_Api
    {
        NONE,
        PRODUCT,
        PRODUCTTYPE,
        PRODUCTBRAND,
        PRODUCTCATEGORY,
        PRODUCTSUBCATEGORY,
        PRODUCTCUSTOMFIELD,

        ITEMCOLOR,
        ITEMSIZE,
        ITEMPARENT,
        ITEM,
        ITEMBARCODE,
        BARCODEQOH,
        ITEMGROUP,
        ITEMCATEGORYL1,
        ITEMCATEGORYL2,
        ITEMCATEGORYL3,
        ITEMUNIT,
        ITEMPACK,
        ITEMPACKS,
        ITEMPACKDETAIL,
        QUANTITYONHAND,
        ITEMIMAGE,
        CUSTOMER,
        ORDER,
        ORDERROW,
        INVOICE,
        CUSTOMERGRADE,
        CUSTOMERCLASS,
        CUSTOMERCREDITDETAIL,
        DISCOUNT,
        CLIENT,
        STOCK,
    }
}
