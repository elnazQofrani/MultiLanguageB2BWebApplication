﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Enumarables
{
    public enum Enum_Social
    {
        TELEGRAM,
        FACEBOOK,
        INSTAGRAM,
        TWITTER,
        WHATSAPP,
        LINKEDIN,
        PINTEREST,
        EMAIL,
        GOOGLE_PLUS
    }
}
