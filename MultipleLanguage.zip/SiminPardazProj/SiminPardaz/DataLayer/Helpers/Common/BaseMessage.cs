﻿using DataLayer.Enumarables;
using DataLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Base
{
    public class BaseMessage
    {
        public static ViewMessage GetMessage()
        {
            return new ViewMessage() { Type = Enum_MessageType.NONE, Body = "" };
        }

        public static ViewMessage GetMessage(Enum_MessageType type, string message)
        {
            return new ViewMessage()
            {
                Type = type,
                Body = message
            };
        }

        public static ViewMessage GetMessage(Enum_Message message)
        {
            return GetMessage(Enum_MessageType.ERROR, message);
        }

        public static ViewMessage GetMessage(Enum_MessageType type)
        {
            return new ViewMessage() { Type = type, Body = "" };
        }

        public static ViewMessage GetMessage(Enum_MessageType type, Enum_Message message)
        {
            string msg = (GetMessageString(message));
            return new ViewMessage() { Type = type, Body = msg };
        }

        private static string GetMessageString(Enum_Message message)
        {
            string msg = "";
            switch (message)
            {
                case Enum_Message.SUCCESSFULL_REGISTER:
                    msg = "ثبت نام شما با موفقیت انجام شد، پرسنل شرکت در اسرع وقت با شما تماس خواهند گرفت";
                    break;
                case Enum_Message.SUCCESSFULL_SUBMIT:
                    msg = "با موفقیت ثبت شد";
                    break;
                case Enum_Message.SUCCESSFULL_UPDATE:
                    msg = "با موفقیت به روز رسانی شد";
                    break;
                case Enum_Message.SUCCESSFULL_API:
                    msg = "با موفقیت انجام شد";
                    break;
                case Enum_Message.SUCCESSFULL_ADD_BASKET:
                    msg = "با موفقیت به سبد استعلام اضافه شد";
                    break;
                case Enum_Message.SUCCESSFULL_DELETE_BASKET:
                    msg = "با موفقیت از سبد استعلام حذف شد";
                    break;
                case Enum_Message.SUCCESSFULL_NEWSLETTER:
                    msg = "شما با موفقیت در خبرنامه ثبت نام کردید";
                    break;
                case Enum_Message.SUCCESSFULL_NEWSLETTER_SENT:
                    msg = "با موفقیت برای اعضای خبرنامه ارسال شد";
                    break;
                case Enum_Message.SUCCESSFULL_FORGET_PASSWORD_EMAIL:
                    msg = "لینک بازیابی رمز عبور برای شما ایمیل شد";
                    break;
                case Enum_Message.SUCCESSFULL_FORGET_PASSWORD_MOBILE:
                    msg = "لینک بازیابی رمز عبور برای شما پیامک شد";
                    break;
                case Enum_Message.SUCCESSFULL_PRODUCT_NOTIFY:
                    msg = "در صورت موجود شدن این محصول، ایمیل و پیامک اطلاع رسانی برای شما ارسال خواهد شد";
                    break;
                case Enum_Message.SUCCESSFULL_PRODUCT_NOTIFY_DISCOUNT:
                    msg = "در صورت تخفیف خوردن این محصول، ایمیل و پیامک اطلاع رسانی برای شما ارسال خواهد شد";
                    break;
                case Enum_Message.DUPLICATED_SITEUSER_EMAIL:
                    msg = "این ایمیل قبلا در سیستم ثبت شده است";
                    break;
                case Enum_Message.DUPLICATED_ACCOUNT_EMAIL:
                    msg = "ایمیل وارد شده در سیستم تکراری می باشد";
                    break;
                case Enum_Message.DUPLICATED_ACCOUNT_MOBILE:
                    msg = "این شماره موبایل قبلا در سیستم ثبت نام شده است";
                    break;
                case Enum_Message.INVALID_APPLICATION_PACKAGE_NAME:
                    msg = "پکیج وارد شده صحیح نمی باشد";
                    break;
                case Enum_Message.INVALID_RECOVER_CODE:
                    msg = "کد بازیابی وارد شده صحیح نمی باشد";
                    break;
                case Enum_Message.INVALID_USERNAME_PASSWORD:
                    msg = "نام کاربری یا رمز عبور صحیح وارد نشده است";
                    break;
                case Enum_Message.INVALID_RECOVER_EMAIL:
                    msg = "ایمیل وارد شده در سیستم ثبت نشده است";
                    break;
                case Enum_Message.INVALID_RECOVER_UNIQUE_ID:
                    msg = "خطا در اعتبارسنجی تغییر رمز عبور";
                    break;
                case Enum_Message.INVALID_SITEUSER_EMAIL:
                    msg = "فرمت ایمیل وارد شده صحیح نمی باشد";
                    break;
                case Enum_Message.INVALID_SHOP_CREATOR:
                    msg = "کد معرفی وارد شده صحیح نمی باشد";
                    break;
                case Enum_Message.INVALID_ACCOUNT_EMAIL:
                    msg = "فرمت ایمیل وارد شده صحیح نمی باشد";
                    break;
                case Enum_Message.INVALID_ACCOUNT_MOBILE:
                    msg = "فرمت موبایل وارد شده صحیح نمی باشد";
                    break;
                case Enum_Message.INVALID_SHOP_USER:
                    msg = "عدم امکان دسترسی به این فروشگاه";
                    break;
                case Enum_Message.INVALID_SITEUSER_CREATORID:
                    msg = "کد معرف صحیح وارد نشده است";
                    break;
                case Enum_Message.INVALID_SHOP_MAX_PRODUCT:
                    msg = "ماکسیمم تعداد محصول برای این فروشگاه ثبت شده است";
                    break;
                case Enum_Message.INVALID_API_KEY:
                    msg = "خطای اعتبارسنجی درخواست";
                    break;
                case Enum_Message.INVALID_DATA:
                    msg = "داده های نامعتبر";
                    break;
                case Enum_Message.INVALID_PAYMENT_OBJECT:
                    msg = "خطا در ساخت اطلاعات پرداخت";
                    break;
                case Enum_Message.INVALID_REBATE_VALUE:
                    msg = "کد تخفیف وارد شده صحیح نمی باشد";
                    break;
                case Enum_Message.INVALID_PRODUCT_ACTIVE:
                    msg = "وضعیت فروش این محصول غیرفعال می باشد";
                    break;
                case Enum_Message.INVALID_ACCOUNT_DATA:
                    msg = "اطلاعات کاربر صحیح وارد نشده است";
                    break;
                case Enum_Message.INVALID_PRODUCT_QUANTITY:
                    msg = "موجودی این کالا به اتمام رسیده است";
                    break;
                case Enum_Message.INVALID_PRODUCT_QUANTITY_SIZE:
                    msg = "موجودی این کالا در این سایز به اتمام رسیده است";
                    break;
                case Enum_Message.INVALID_PRODUCT_QUANTITY_COLOR:
                    msg = "موجودی این کالا در این رنگ به اتمام رسیده است";
                    break;
                case Enum_Message.INVALID_PRODUCT_QUANTITY_COLOR_SIZE:
                    msg = "موجودی این کالا در این رنگ و سایز به اتمام رسیده است";
                    break;
                case Enum_Message.INVALID_MOBILE_FORMAT:
                    msg = "شماره موبایل وارد شده صحیح نمی باشد";
                    break;
                case Enum_Message.INVALID_EMAIL_FORMAT:
                    msg = "فرمت ایمیل وارد شده صحیح نمی باشد";
                    break;
                case Enum_Message.INVALID_RECAPTCHA:
                    msg = "لطفا بر روی من ربات نیستم کلیک کنید";
                    break;
                case Enum_Message.INVALID_REAGENT_CODE:
                    msg = "کد معرف وارد شده صحیح نمی باشد";
                    break;
                case Enum_Message.INVALID_BARCODE_VALUE:
                    msg = "اطلاعات این بارکد در سیستم یافت نشد";
                    break;
                case Enum_Message.INVALID_ORDER_TRACKING_CODE:
                    msg = "سفارشی با این اطلاعات در سیستم ثبت نشده است";
                    break;

                case Enum_Message.INVALID_ORDER_REBATE_BEFORE:
                    msg = "برای این سفارش قبلا کد تخفیف ثبت شده است";
                    break;
                case Enum_Message.INVALID_REBATE_DATETIME:
                    msg = "تاریخ استفاده ازین کد تخفیف به پایان رسیده";
                    break;
                case Enum_Message.INVALID_REBATE_USECOUNT:
                    msg = "تعداد استفاده ازین کد تخفیف به پایان رسیده";
                    break;
                case Enum_Message.INVALID_REBATE_MIN_INVOICE_VALUE:
                    msg = "مبلغ این فاکتور برای استفاده ازین کد تخفیف به حد نصاب نرسیده است";
                    break;
                case Enum_Message.INVALID_REBATE_MAX_INVOICE_VALUE:
                    msg = "مبلغ این فاکتور برای استفاده ازین کد تخفیف بیش از حد مجاز است";
                    break;
                case Enum_Message.INVALID_REBATE_MOBILE:
                    msg = "این کد تخفیف برای شماره موبایل دیگری می باشد";
                    break;
                case Enum_Message.INVALID_CURRENT_CREDIT:
                    msg = "مقدار وارد شده صحیح نمی باشد";
                    break;
                case Enum_Message.INVALID_SUM_CREDIT_ORDER_PRICE:
                    msg = "مجموع مبلغ وارد شده از مبلغ سفارش کمتر است";
                    break;
                case Enum_Message.USER_ID_INACTIVE:
                    msg = "کاربری شما غیرفعال شده است. لطفا با مدیر سامانه تماس بگیرید";
                    break;
                case Enum_Message.REQUIRED_ADMIN_INFO:
                    msg = "وارد کردن اطلاعات مدیر اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_PAYMENT_SUBJECT:
                    msg = "موضوع پرداخت ارسال نشده است";
                    break;
                case Enum_Message.REQUIRED_PAYMENT_MERCHANT:
                    msg = "درگاه پرداخت انتخاب نشده است";
                    break;
                case Enum_Message.REQUIRED_GALLERY_NAME:
                    msg = "وارد کردن نام گالری اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_CATEGORY_NAME:
                    msg = "وارد کردن نام دسته بندی اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_POST_NAME:
                    msg = "وارد کردن عنوان پست اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_MENU_NAME:
                    msg = "وارد کردن عنوان منو اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_MENU_TYPE_ITEM:
                    msg = "نوع منو انتخاب نشده است";
                    break;
                case Enum_Message.REQUIRED_MENU_POST_ITEM:
                    msg = "پست مربوطه انتخاب نشده است";
                    break;
                case Enum_Message.REQUIRED_MENU_CATEGORY_ITEM:
                    msg = "دسته بندی مربوطه انتخاب نشده است";
                    break;
                case Enum_Message.REQUIRED_CATEGORY_WEBSITE_NAME:
                    msg = "نام وبسایت وارد نشده است";
                    break;
                case Enum_Message.REQUIRED_MENU_GALLERY_ITEM:
                    msg = "گالری مربوطه انتخاب نشده است";
                    break;
                case Enum_Message.REQUIRED_USERGROUP_NAME:
                    msg = "نام گروه کاربری وارد نشده است";
                    break;
                case Enum_Message.REQUIRED_SITEUSER_FULLNAME:
                    msg = "نام و نام خانوادگی کاربر اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_SITEUSER_EMAIL:
                    msg = "ایمیل کاربر اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_SITEUSER_MOBILE:
                    msg = "وارد کردن شماره موبایل اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_SITEUSER_PASSWORD:
                    msg = "رمز عبور کاربر اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_PASSWORD:
                    msg = "رمز عبور اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_PASSWORD_CONFIRM:
                    msg = "وارد کردن تکرار رمز عبور اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_PASSWORD_PREVIOUS:
                    msg = "وارد کردن رمز عبور قبلی اجباری می باشد";
                    break;
                case Enum_Message.INVALID_PASSWORD_PREVIOUS:
                    msg = "رمز عبور قبلی صحیح وارد نشده است";
                    break;
                case Enum_Message.REQUIRED_SELECT_LANGUAGE:
                    msg = "هیچ زبانی انتخاب نشده است";
                    break;
                case Enum_Message.REQUIRED_EVENT_DESCRIPTION:
                    msg = "وارد کردن توضیحات برای رویداد اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_WEBSITE_TITLE:
                    msg = "عنوان وبسایت اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_DOMAIN:
                    msg = "وارد کردن دامنه اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_SHOP_NAME:
                    msg = "وارد کردن نام فروشگاه اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_SHOP_LABEL:
                    msg = "وارد کردن برچسب فروشگاه اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_SHOP_DESCRIPTION:
                    msg = "وارد کردن توضیحات فروشگاه اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_PRODUCT_TYPE_NAME:
                    msg = "وارد کردن نام اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_PRODUCT_NAME:
                    msg = "وارد کردن نام محصول اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_PRODUCT_SHOP:
                    msg = "انتخاب فروشگاه اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_PRODUCT_BRAND_NAME:
                    msg = "وارد کردن نام برند اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_PRODUCT_STATUS:
                    msg = "انتخاب وضعیت محصول اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_COMMENT_BODY:
                    msg = "وارد کردن متن نظر اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_BASKET_ITEM:
                    msg = "آیتم ای در سبد ثبت نشده است";
                    break;
                case Enum_Message.INVALID_PASSWORD_CONFIRM:
                    msg = "رمز ها باهم مطابقت ندارند";
                    break;
                case Enum_Message.INVALID_ADDRESS_POSTAL_CODE:
                    msg = "کدپستی وارد شده صحیح نمی باشد";
                    break;
                case Enum_Message.REQUIRED_EMAIL:
                    msg = "وارد کردن آدرس ایمیل اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_CUSTOM_FIELD_NAME:
                    msg = "وارد کردن عنوان فیلد اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_PRODUCT_CUSTOM_ITEM_VALUE:
                    msg = "وارد کردن مقدار اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_PRODUCT_CATEGORY_NAME:
                    msg = "وارد کردن نام دسته بندی اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_PRODUCT_SUB_CATEGORY_NAME:
                    msg = "وارد کردن نام زیردسته اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_PRODUCTCOMMENT_BODY:
                    msg = "وارد کردن متن نظر اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_PRODUCTCONSULTANT_BODY:
                    msg = "وارد کردن متن اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_PRODUCTQUESTION_BODY:
                    msg = "وارد کردن متن اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_PRODUCTQUESTIONANSWER_BODY:
                    msg = "وارد کردن متن اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_TEMPLATE_NAME:
                    msg = "وارد کردن نام قالب اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_TEMPLATE_LABEL:
                    msg = "وارد کردن برچسب قالب اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_SLIDER_NAME:
                    msg = "وارد کردن عنوان اسلایدر اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_SLIDER_PICTURE:
                    msg = "وارد کردن تصویر اسلایدر اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_ACCOUNT:
                    msg = "اطلاعات کاربر وارد نشده است";
                    break;
                case Enum_Message.REQUIRED_ACCOUNT_FULLNAME:
                    msg = "وارد کردن نام و نام خانوادگی اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_ACCOUNT_EMAIL:
                    msg = "وارد کردن ایمیل اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_ACCOUNT_PASSWORD:
                    msg = "رمز عبور اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_ACCOUNT_MOBILE:
                    msg = "وارد کردن شماره موبایل اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_ACCOUNT_EMAIL_OR_MOBILE:
                    msg = "وارد کردن ایمیل یا موبایل اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_SHOPCONTACT_VALUE:
                    msg = "وارد کردن مقدار اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_LANGUAGE_NAME:
                    msg = "وارد کردن نام زبان اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_LANGUAGE_LABEL:
                    msg = "وارد کردن برچسب زبان اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_LANGUAGE_CULTURE:
                    msg = "وارد کردن مشخصه زبان اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_DISCOUNTGROUP_NAME:
                    msg = "وارد کردن نام اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_DISCOUNT_SHOP:
                    msg = "وارد کردن فروشگاه اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_DISCOUNT_PRODUCTTYPE:
                    msg = "وارد کردن نوع محصول اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_DISCOUNT_CATEGORY:
                    msg = "وارد کردن دسته بندی محصول اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_DISCOUNT_SUBCATEGORY:
                    msg = "وارد کردن زیردسته محصول اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_DISCOUNT_PRODUCT:
                    msg = "وارد کردن محصول اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_DISCOUNT_BRAND:
                    msg = "وارد کردن برند محصول اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_DISCOUNT_GRADE:
                    msg = "وارد کردن سطح کاربری اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_DISCOUNT_CLASS:
                    msg = "وارد کردن کلاس کاربری اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_NEWSLETTER_VALUE:
                    msg = "محتوای خبرنامه پر نشده است";
                    break;
                case Enum_Message.REQUIRED_SMS_NUMBER:
                    msg = "انتخاب شماره اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_SMS_TYPE:
                    msg = "انتخاب نوع ارسال پیام اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_SMS_BODY:
                    msg = "وارد کردن متن پیامک اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_TELEGRAMBOT_NAME:
                    msg = "وارد کردن نام ربات اجباری می باشد";
                    break;

                case Enum_Message.REQUIRED_EMAILTYPE_LABEL:
                    msg = "وارد کردن برچسب نوع ایمیل اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_EMAILTYPE_NAME:
                    msg = "وارد کردن نام نوع ایمیل اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_EMAILTYPE_BODY:
                    msg = "وارد کردن محتوا  ایمیل اجباری می باشد";
                    break;
                    

                case Enum_Message.REQUIRED_TELEGRAMBOT_TOKEN:
                    msg = "وارد کردن توکن ربات اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_TELEGRAMCOMMAND_COMMAND:
                    msg = "وارد کردن دستور اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_TELEGRAMCOMMAND_NAME:
                    msg = "وارد کردن نام دستور اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_TELEGRAM_KEYBOARD_NAME:
                    msg = "وارد کردن نام کیبورد اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_TELEGRAMKEYBOARDITEM_NAME:
                    msg = "وارد کردن عنوان آیتم اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_REBATE_NAME:
                    msg = "وارد کردن عنوان کد تخفیف اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_REBATE_CODEVALUE:
                    msg = "وارد کردن کد تخفیف اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_REBATE_SHOP:
                    msg = "وارد کردن فروشگاه اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_REBATE_PRODUCTTYPE:
                    msg = "وارد کردن نوع محصول اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_REBATE_PRODUCTCATEGORY:
                    msg = "وارد کردن دسته بندی اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_REBATE_PRODUCTSUBCATEGORY:
                    msg = "وارد کردن زیردسته اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_REBATE_PRODUCTBRAND:
                    msg = "وارد کردن برند اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_REBATE_SHOPRESELLER:
                    msg = "وارد کردن نماینده فروش اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_REBATE_VALUE:
                    msg = "وارد کردن کد تخفیف اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_PACKAGE_NAME:
                    msg = "وارد کردن نام بسته اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_USERGROUP_DASHBOARD:
                    msg = "انتخاب داشبورد اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_ACCOUNT_ADDRESS_NAMEFAMILY:
                    msg = "وارد کردن نام و نام خانوادگی تحویل گیرنده اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_ACCOUNT_ADDRESS_PHONE:
                    msg = "وارد کردن شماره تلفن تحویل گیرنده اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_ACCOUNT_ADDRESS_MOBILE:
                    msg = "وارد کردن شماره موبایل تحویل گیرنده اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_ACCOUNT_ADDRESS_VALUE:
                    msg = "وارد کردن آدرس اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_ACCOUNT_ADDRESS_POSTAL_CODE:
                    msg = "وارد کردن کد پستی اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_ACCOUNT_ADDRESS_STATE:
                    msg = "انتخاب استان اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_ACCOUNT_ADDRESS_CITY:
                    msg = "انتخاب شهر اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_BANNER_NAME:
                    msg = "وارد کردن نام بنر اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_MALL_NAME:
                    msg = "وارد کردن نام پاساژ اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_COLOR_NAME:
                    msg = "وارد کردن نام رنگ اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_SIZE_NAME:
                    msg = "وارد کردن عنوان سایز اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_COLOR_HEX:
                    msg = "وارد کردن کد رنگ اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_REAGENT_MOBILE_VALUES:
                    msg = "وارد کردن شماره موبایل اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_CONTACT_FORM:
                    msg = "اطلاعات فرم تماس وارد نشده است";
                    break;
                case Enum_Message.REQUIRED_CONTACT_FORM_FULLNAME:
                    msg = "وارد کردن نام و نام خانوادگی اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_CONTACT_FORM_EMAIL:
                    msg = "وارد کردن ایمیل اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_CONTACT_FORM_BODY:
                    msg = "وارد کردن متن اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_TRACKING_CODE:
                    msg = "وارد کردن کد پیگیری پرداخت اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_FILE:
                    msg = "فایلی بارگذاری نشده است";
                    break;
                case Enum_Message.REQUIRED_RESELLER_GALLERY_NAME:
                    msg = "وارد کردن عنوان اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_RESELLER_GALLERY_FILE:
                    msg = "انتخاب فایل اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_RESELLER_GALLERY_IMAGE:
                    msg = "انتخاب تصویر کاور اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_SHOPRESELLER_PRODUCT:
                    msg = "انتخاب محصول اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_SHOPRESELLER_COLLECTION_PICTURE_ID:
                    msg = "انتخاب عکس پیش فرض برای کالکشن اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_SHOPRESELLER_COLLECTION_NAME:
                    msg = "وارد کردن نام کالکشن اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_WEBSITEFORM_NAME:
                    msg = "وارد کردن عنوان فرم اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_WEBSITEFORM_LABEL:
                    msg = "وارد کردن برچسب فرم اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_RECOVER_VALUE:
                    msg = "وارد کردن کد بازیابی اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_SHOPRESELLER_COLLECTION_PRODUCT:
                    msg = "هیچ محصولی انتخاب نشده است";
                    break;
                case Enum_Message.REQUIRED_CREDIT_DESCRIPTION:
                    msg = "وارد کردن توضیحات اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_SENDTYPE_NAME:
                    msg = "وارد کردن نام روش های ارسال اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_INVOICE_ENTITY:
                    msg = "فاکتوری ارسال نشده است";
                    break;
                case Enum_Message.REQUIRED_PACK_NAME:
                    msg = "وارد کردن نام بسته اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_APPLICATION_PACKAGE_NAME:
                    msg = "وارد کردن نام پکیج اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_APPLICATION_NAME:
                    msg = "وارد کردن نام اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_APPLICATION_TYPE:
                    msg = "انتخاب نوع اپلیکیشن اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_GRADE_NAME:
                    msg = "وارد کردن نام سطح کاربری اجباری می باشد";
                    break;
                case Enum_Message.REQUIRED_CLASS_NAME:
                    msg = "وارد کردن نام کلاس کاربری اجباری می باشد";
                    break;
                case Enum_Message.ERROR_INVOICE_SYNCED_BEFORE:
                    msg = "این فاکتور قبلا ارسال شده است";
                    break;
                case Enum_Message.DUPLICATED_NEWSLETTER:
                    msg = "شما قبلا در خبرنامه ثبت نام کرده اید";
                    break;
                case Enum_Message.ERROR_REBATE_USED_BEFORE:
                    msg = "این کد قبلا استفاده شده است";
                    break;
                case Enum_Message.ERROR_FILE_MAX_SIZE:
                    msg = "حجم فایل بیش از حد مجاز است";
                    break;
                case Enum_Message.ERROR_MORE_CURRENT_CREDIT:
                    msg = "میزان مبلغ وارد شده بیش از موجودی حساب شما می باشد";
                    break;
                case Enum_Message.ERROR_API:
                    msg = "خطا در سیستم";
                    break;
                case Enum_Message.ERROR_POSTEKETAB:
                    msg = "خطا در ثبت اطلاعات";
                    break;
                case Enum_Message.UNIQUE_EMAIL:
                    msg = "آدرس ایمیل وارد شده در سیستم تکراری می باشد";
                    break;
                case Enum_Message.UNIQUE_MOBILE:
                    msg = "شماره موبایل وارد شده در سیستم تکراری می باشد";
                    break;
                case Enum_Message.REQUIRED_INQUIRY_PRODUCT:
                    msg = "وارد کردن کد کالا اجباری می باشد";
                    break;
                case Enum_Message.INVALID_PRODUCT_CODEVALUE:
                    msg = "کد کالای وارد شده معتبر نمی باشد";
                    break;
                case Enum_Message.INVALID_IMPORTATION_EMAIL:
                    msg = "فرمت ایمیل صحیح وارد نشده است";
                    break;
                default:
                    break;
            }
            return msg;
        }
    }
}
