﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DataLayer.Base
{
    public static class BaseConvert
    {
        public static string GetCurrencyFormat(this int value)
        {
            return ((long)value).ToString("N0").ToString();
        }

        public static string GetCurrencyFormat(this decimal? value)
        {
            return value == null ? "0" : ((float)value).ToString("N0").ToString();
        }

        public static string GetCurrencyFormat(this int? value)
        {
            return value == null ? "0" : value.Value.GetCurrencyFormat();
        }

        public static string GetCurrencyFormat(this double value)
        {
            return ((float)value).ToString("N0").ToString();
        }

        public static string GetCurrencyFormat(this double? value)
        {
            return value == null ? "0" : ((float)value).ToString("N0").ToString();
        }

        public static int GetInteger(this string str)
        {
            if (str.IsInteger())
                return int.Parse(str);
            return 0;
        }

        public static float GetFloat(this string str)
        {
            if (str.IsFloat())
                return float.Parse(str);
            return 0;
        }

        public static bool GetBoolean(this string str)
        {
            if (str.IsBoolean())
                return bool.Parse(str);
            return false;
        }

        public static Guid GetGuid(this string str)
        {
            if (string.IsNullOrEmpty(str))
                return default(Guid);
            if (str.IsGuid())
                return Guid.Parse(str);
            return default(Guid);
        }

        public static bool IsInteger(this string str)
        {
            int a = 0;
            return int.TryParse(str, out a);
        }

        public static bool IsFloat(this string str)
        {
            float a = 0;
            return float.TryParse(str, out a);
        }

        public static bool IsGuid(this string str)
        {
            Guid a = new Guid();
            return Guid.TryParse(str, out a);
        }
        
        public static bool IsBoolean(this string input)
        {
            bool n;
            return bool.TryParse(input, out n);
        }

        public static bool IsLong(this string input)
        {
            long n;
            return long.TryParse(input, out n);
        }

        public static bool IsDatetime(this string input)
        {
            DateTime n;
            return DateTime.TryParse(input, out n);
        }

        public static bool IsDouble(this string input)
        {
            try
            {
                Double.Parse(input, System.Globalization.CultureInfo.InvariantCulture);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public static string RemoveNumbers(this string input)
        {
            if (string.IsNullOrEmpty(input))
                return input;
            return Regex.Replace(input, @"[\d-]", string.Empty);
        }
    }
}
