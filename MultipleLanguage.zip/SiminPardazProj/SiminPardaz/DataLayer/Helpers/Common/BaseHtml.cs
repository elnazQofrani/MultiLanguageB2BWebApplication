﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace DataLayer.Base
{
    public class BaseHtml
    {
        public static string ConvertToSimpleText(string htmlBody)
        {
            if (htmlBody != null)
            {
                HtmlDocument doc = new HtmlDocument();
                doc.LoadHtml(htmlBody);
                var root = doc.DocumentNode;
                var sb = new StringBuilder();
                foreach (HtmlNode node in doc.DocumentNode.DescendantsAndSelf())
                {
                    if (!node.HasChildNodes)
                    {
                        string text = node.InnerText;
                        if (!string.IsNullOrEmpty(text))
                        {
                            string tempText = text.Trim();
                            tempText = tempText.Replace("&nbsp;", "");

                            sb.AppendLine(tempText);
                        }
                    }
                }
                return sb.ToString();
            }
            else
                return null;
        }

        public static string ConvertToHyperlinkString(string url)
        {
            if (string.IsNullOrEmpty(url))
                return url;
            string regex = @"((www\.|(http|https|ftp|news|file)+\:\/\/)[_.a-z0-9-]+\.[a-z0-9\/_:@=.+?,##%&~-]*[^.|\'|\# |!|\(|?|,| |>|<|;|\)])";
            Regex r = new Regex(regex, RegexOptions.IgnoreCase);
            return r.Replace(url, "<a href=\"$1\">$1</a>").Replace("href=\"www", "href=\"http://www");
        }
    }
}
