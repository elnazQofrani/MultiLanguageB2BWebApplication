﻿using DataLayer.Entities;
using DataLayer.Enumarables;
using DataLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Base
{
    public static class BaseStore
    {
        public static string GetMainPicture(this Product product)
        {
            if (product.PictureId == null)
            {
                if (product.ProductPicture.Count > 0)
                    return product.ProductPicture.FirstOrDefault().Picture.GetUrl();
            }
            else
                return product.Picture.GetUrl();
            return "";
        }

        public static string GetDiscountString(this ViewDiscountGroup group)
        {
            string body = "";
            if (group.Type.Label == Enum_Code.DISCOUNTGROUP_TYPE_PRICE.ToString())
                body = group.PriceValue.GetCurrencyFormat() + " تومان";
            else
                body = group.PercentValue + "% از مبلغ کل";

            body = body.ToPersian();
            return body;
        }

        public static string GetDiscountName(this ViewDiscount discount)
        {
            string body = "";
            if (discount.Type.Label == Enum_Code.DISCOUNT_TYPE_SHOP.ToString())
                body = "فروشگاه - ";
            else if (discount.Type.Label == Enum_Code.DISCOUNT_TYPE_PRODUCTTYPE.ToString())
                body = "نوع محصول (" + discount.ProductType.Name + ") - ";
            else if (discount.Type.Label == Enum_Code.DISCOUNT_TYPE_CATEGORY.ToString())
                body = "دسته بندی (" + discount.ProductCategory.Name + ") - ";
            else if (discount.Type.Label == Enum_Code.DISCOUNT_TYPE_SUBCATEGORY.ToString())
                body = "زیردسته محصولات (" + discount.ProductSubCategory.Name + ") - ";
            else if (discount.Type.Label == Enum_Code.DISCOUNT_TYPE_PRODUCT.ToString())
                body = "محصول (" + discount.Product.Name + ") - ";
            else if (discount.Type.Label == Enum_Code.DISCOUNT_TYPE_BRAND.ToString())
                body = "برند (" + discount.ProductBrand.Name + ") - ";

            string value;
            if (discount.PercentValue != null && discount.PercentValue != 0)
                value = discount.PercentValue + "% از مبلغ کل";
            else
                value = discount.PriceValue + " تومان از مبلغ کل";

            body = (body + " " + value).ToPersian();
            return body;
        }

        public static string GetRebateName(this Rebate rebate)
        {
            string body = "";
            if (rebate.Code.Label == Enum_Code.REBATE_TYPE_SHOP.ToString())
                body = rebate.Name + " (تمامی محصولات فروشگاه)";
            else if (rebate.Code.Label == Enum_Code.REBATE_TYPE_PRODUCTTYPE.ToString())
                body = rebate.Name + " (تمامی محصولات - " + rebate.ProductType.Name + ")";
            else if (rebate.Code.Label == Enum_Code.REBATE_TYPE_PRODUCTCATEGORY.ToString())
                body = rebate.Name + " (تمامی محصولات - " + rebate.ProductCategory.Name + ")";
            else if (rebate.Code.Label == Enum_Code.REBATE_TYPE_PRODUCTSUBCATEGORY.ToString())
                body = rebate.Name + " (تمامی محصولات - " + rebate.ProductSubCategory.Name + ")";
            else if (rebate.Code.Label == Enum_Code.REBATE_TYPE_PRODUCTBRAND.ToString())
                body = rebate.Name + " (تمامی محصولات - " + rebate.ProductBrand.Name + ")";
            else
                body = rebate.Name;
            return body;
        }

        public static int? GetDiscountValue(this ViewDiscount discount)
        {
            if (discount.Type.Label == Enum_Code.DISCOUNT_TYPE_PRODUCT.ToString())
            {
                int body = 0;
                if (discount.PriceValue != null && discount.PriceValue != 0)
                {
                    body = (discount.Product.Price - discount.PriceValue.Value);
                }
                else if (discount.PercentValue != null && discount.PercentValue != 0)
                {
                    body = ((discount.Product.Price / 100) * discount.PercentValue.Value);
                }
                return body;
            }
            return null;
        }

        public static int GetDiscountPrice(this Product product, Discount discount)
        {
            if (discount != null)
            {
                int body = 0;
                if (discount.PriceValue != null && discount.PriceValue != 0)
                {
                    body = discount.PriceValue.GetValueOrDefault();
                }
                else if (discount.PercentValue != null && discount.PercentValue != 0)
                {
                    body = ((product.Price.GetValueOrDefault() / 100) * discount.PercentValue.Value);
                }
                body = body < 0 ? 0 : body;
                return body;
            }
            else
                return product.Price.GetValueOrDefault();
        }

        //public static int GetDiscountBasePrice(this Product product, Discount discount)
        //{
        //    if (discount != null)
        //    {
        //        int body = 0;
        //        if (discount.PriceValue != null && discount.PriceValue != 0)
        //        {
        //            body = discount.PriceValue.GetValueOrDefault();
        //        }
        //        else if (discount.PercentValue != null && discount.PercentValue != 0)
        //        {
        //            body = (int)((product.BasePrice.GetValueOrDefault() / 100) * discount.PercentValue.Value);
        //        }
        //        body = body < 0 ? 0 : body;
        //        return body;
        //    }
        //    else
        //        return (int)product.BasePrice.GetValueOrDefault();
        //}

        //public static double? GetDiscountBasePrice(this Product product, int? colorId = null)
        //{
        //    UnitOfWork _context = new UnitOfWork();
        //    List<Discount> list = _context.Discount.GetAllByProduct(product, colorId);
        //    int? MaxDiscount = 0;
        //    foreach (Discount item in list)
        //    {
        //        int discountPrice = GetDiscountBasePrice(product, item);
        //        if (item.IsTop)
        //            MaxDiscount = discountPrice;
        //        else
        //            MaxDiscount = discountPrice > MaxDiscount ? discountPrice : MaxDiscount;
        //    }

        //    _context.Dispose();
        //    return product.BasePrice.GetValueOrDefault() - MaxDiscount.GetValueOrDefault();
        //}

        public static int GetDiscountPrice(this Product product, int? colorId = null)
        {
            UnitOfWork _context = new UnitOfWork();
            List<Discount> list = _context.Discount.GetAllByProduct(product, colorId);
            int? MaxDiscount = 0;
            foreach (Discount item in list)
            {
                int discountPrice = GetDiscountPrice(product, item);
                if (item.IsTop)
                    MaxDiscount = discountPrice;
                else
                    MaxDiscount = discountPrice > MaxDiscount ? discountPrice : MaxDiscount;
            }

            _context.Dispose();
            return product.Price.GetValueOrDefault() - MaxDiscount.GetValueOrDefault();
        }

        public static int GetDiscountPercent(this Product product, int? colorId = null)
        {
            UnitOfWork _context = new UnitOfWork();
            ViewAccount account = BaseWebsite.CurrentAccount;
            List<Discount> list = _context.Discount.GetAllByProduct(product, colorId);
            int discountPercent = 0;

            foreach (Discount item in list)
            {
                int temp = item.PercentValue.GetValueOrDefault();
                if (item.IsTop)
                    discountPercent = temp;
                else
                    discountPercent = temp > discountPercent ? temp : discountPercent;
            }
            _context.Dispose();
            return discountPercent;
        }

        public static Discount GetDiscountObject(this Product product, int? colorId = null)
        {
            UnitOfWork _context = new UnitOfWork();
            ViewAccount account = BaseWebsite.CurrentAccount;
            List<Discount> list = _context.Discount.GetAllByProduct(product, colorId);
            int discountPercent = 0;
            Discount discount = null;
            foreach (Discount item in list)
            {
                int temp = item.PercentValue.GetValueOrDefault();
                if (item.IsTop || temp > discountPercent)
                {
                    discountPercent = temp;
                    discount = item;
                }
            }
            return discount;
        }

        public static string GetDiscountString(this DiscountGroup group)
        {
            string body = "";
            if (group.Code.Label == Enum_Code.DISCOUNTGROUP_TYPE_PRICE.ToString())
                body = group.PriceValue.GetCurrencyFormat() + " تومان";
            else
                body = group.PercentValue + "% از مبلغ کل";

            body = body.ToPersian();
            return body;
        }

        public static string GetAddressString(this AccountAddress address)
        {
            if (address == null)
                return "-";
            else
            {
                string addressString = (address.StateId != null ? (address.State.Name + " - ") : "") + address.AddressValue + "<br />";
                addressString += address.StateId != null ? "<b>استان: </b>" + address.State.Name + "&nbsp;&nbsp;" : "";
                addressString += address.CityId != null ? "<b>شهرستان: </b>" + address.City.Name + "&nbsp;&nbsp;" : "";
                addressString += string.IsNullOrEmpty(address.CityName) == false ? "<b>شهر: </b>" + address.CityName + "&nbsp;&nbsp;" : "";
                addressString += "<b>نام تحویل گیرنده:</b> " + (string.IsNullOrEmpty(address.NameFamily) ? "-" : address.NameFamily) + "&nbsp;&nbsp;";
                addressString += "<b>شماره تلفن:</b> " + (string.IsNullOrEmpty(address.Phone) ? "-" : address.Phone) + "&nbsp;&nbsp;";
                if (address.AccountId != null && address.Mobile != address.Account.Mobile)
                {
                    addressString += "<b>تلفن همراه:</b> " + (string.IsNullOrEmpty(address.Mobile) ? "-" : address.Mobile) + "&nbsp;&nbsp;";
                }
                addressString += "<b>کدپستی:</b> " + (string.IsNullOrEmpty(address.PostalCode) ? "-" : address.PostalCode) + "&nbsp;&nbsp;";
                addressString = addressString.ToPersian();
                return addressString;
            }
        }

        public static string GetCustomValue(this Product product, string label)
        {
            ProductCustomValue value = product.ProductCustomValue.FirstOrDefault(p =>
                p.ProductCustomField.Label == label
            );
            if (value != null)
            {
                if (value.ProductCustomField.Code.Label == Enum_Code.FIELD_TYPE_DROPDOWN.ToString() && value.ItemId != null)
                    return value.ProductCustomItem.Value;
                else
                    return value.Value;
            }
            else
                return "";
        }

        public static List<ProductSize> GetActiveSizes(this Product product)
        {
            List<ProductSize> listSize = new List<ProductSize>();
            List<ProductQuantity> listQuantity = product.ProductQuantity.ToList();
            foreach (var item in product.ProductSize)
            {
                if (listQuantity.Any(p => p.SizeId == item.SizeId))
                    listSize.Add(item);
            }
            return listSize;
        }

        public static ProductCustomValue GetCustomValueObject(this Product product, string label)
        {
            ProductCustomValue value = product.ProductCustomValue.FirstOrDefault(p =>
                p.ProductCustomField.Label == label
            );

            if (value == null)
            {
                value = new ProductCustomValue()
                {
                    FieldId = 0,
                    ItemId = 0,
                    Value = ""
                };
            }

            return value;
        }

        public static int GetPrice(this SendType sendType, AccountOrder order)
        {
            if (sendType == null)
                return 0;
            int price = 0;
            int count = order.AccountOrderProduct.Sum(p => p.Count);
            if (sendType.FreePrice != null && sendType.FreePrice != 0 && order.Price >= sendType.FreePrice)
            {
                price = 0;
            }
            else
            {
                price = (sendType == null) ? 0 : sendType.BasePrice.GetValueOrDefault() + (count * sendType.PerProductPrice.GetValueOrDefault());
                price = sendType.MaxPrice != null && price > sendType.MaxPrice ? sendType.MaxPrice.GetValueOrDefault() : price;
            }

            return price;
        }

        public static int GetPrice(this SendType sendType, int count, int? orderPrice = null)
        {
            if (sendType == null)
                return 0;
            int price;
            if (sendType.FreePrice != null && orderPrice >= sendType.FreePrice)
            {
                price = 0;
            }
            else
            {
                price = (sendType == null) ? 0 : sendType.BasePrice.GetValueOrDefault() + (count * sendType.PerProductPrice.GetValueOrDefault());
                price = sendType.MaxPrice != null && price > sendType.MaxPrice ? sendType.MaxPrice.GetValueOrDefault() : price;
            }
            return price;
        }

        public static int? GetRateValue(this Product product)
        {
            double? rateValue = product.ProductRate.Average(p => p.RateValue);
            return rateValue == null ? default(int?) : Convert.ToInt32((Math.Round(rateValue.GetValueOrDefault())));
        }

        public static int? GetBestRate(this Product product)
        {
            return product.ProductRate.Max(p => p.RateValue);
        }

        public static int? GetWorstRate(this Product product)
        {
            return product.ProductRate.Min(p => p.RateValue);
        }

        public static int? GetRateCount(this Product product)
        {
            return product.ProductRate.Count;
        }

        public static AccountOrder GetOrder(this Payment payment)
        {
            return payment.PaymentProductOrder.OrderByDescending(p => p.ID).FirstOrDefault()?.AccountOrder;
        }

        public static ProductPicture GetProductPicture(this ProductColor productColor)
        {
            return productColor.Product.ProductPicture.FirstOrDefault(p => p.ColorId == productColor.ColorId && p.ColorImage == true);
        }
    }
}
