﻿using DataLayer.Entities;
using DataLayer.Enumarables;
using DataLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Configuration;
using System.Web.Routing;
using System.Text.RegularExpressions;

namespace DataLayer.Base
{
    public static class BaseUrl
    {
        public static string CacheVersion { get { return WebConfigurationManager.AppSettings["CACHE_VERSION"]; } }

        public static string CurrentUrl
        {
            get
            {
                Uri url = HttpContext.Current.Request.Url;
                if (url.Host == "localhost")
                    return url.Scheme + "://" + url.Host + ":" + url.Port + "/";
                return url.Scheme + "://" + url.Host + "/";
            }
        }

        public static string GetUrl(this ViewPicture picture, string domain = "")
        {
            string type_panel_string = Enum_Code.SYSTEM_TYPE_PANEL.ToString();
            string type_shop_string = Enum_Code.SYSTEM_TYPE_SHOP.ToString();

            if (String.IsNullOrEmpty(domain))
            {
                if (picture != null)
                {
                    string url = picture.Url;
                    url = url.Replace(type_panel_string, BaseWebsite.PanelUrl);
                    url = url.Replace(type_shop_string, BaseWebsite.ShopUrl);
                    return url;
                }
                else
                    return "";
            }
            else
            {
                if (String.IsNullOrEmpty(picture.Url))
                    return "";
                else
                    return picture.Url.Replace(type_panel_string, domain);
            }
        }

        public static string GetUrl(this Picture picture)
        {
            if (picture != null)
            {
                string url = picture.Url;
                url = url.Replace(Enum_Code.SYSTEM_TYPE_PANEL.ToString(), BaseWebsite.PanelUrl);
                url = url.Replace(Enum_Code.SYSTEM_TYPE_SHOP.ToString(), BaseWebsite.ShopUrl);
                url = url.Replace(Enum_Code.SYSTEM_TYPE_SYNCSERVER.ToString(), BaseWebsite.SyncUrl);
                return url;
            }
            else
                return "";
        }

     
        public static string GetUrl(this ProductPicture picture)
        {
            if (picture != null)
                return picture.Picture.GetUrl();
            else
                return "";
        }

        public static string GetUrl(this WebsiteDocument document, string domain = "")
        {
            string type_panel_string = Enum_Code.SYSTEM_TYPE_PANEL.ToString();
            string type_shop_string = Enum_Code.SYSTEM_TYPE_SHOP.ToString();

            if (string.IsNullOrEmpty(domain))
            {
                if (document != null)
                {
                    string url = document.Url;
                    url = url.Replace(type_panel_string, BaseWebsite.PanelUrl);
                    url = url.Replace(type_shop_string, BaseWebsite.ShopUrl);
                    return url;
                }
                else
                    return "";
            }
            else
            {
                if (string.IsNullOrEmpty(document.Url))
                    return "";
                else
                    return document.Url.Replace(type_panel_string, domain);
            }
        }

        public static string GetLink(this Banner banner)
        {
            return "/ba/" + banner.ID + "/" + banner.Name.StandardUrl();
        }

        public static string GetLink(this Product product)
        {
            return "/pr/" + product.ID + "/" + product.Name.StandardUrl();
        }

        public static string GetLinkAbsolute(this Product product)
        {
            return BaseWebsite.ShopUrl + GetLink(product);
        }

        public static string GetLink(this Category category)
        {
            return "/po/" + category.Label.StandardUrl();
        }

        public static string GetLink(this Gallery gallery)
        {
            return "/ga/" + gallery.ID + "/" + gallery.Name.StandardUrl();
        }

        public static string GetLink(this Post post)
        {
            return "/po/" + post.ID + "/" + post.Name.StandardUrl();
        }

        public static string GetLink(this Menu menu)
        {
            string link = "";
            if (menu.Code.Label == Enum_Code.MENU_TYPE_POST.ToString())
                link = menu.Post.GetLink();
            else if (menu.Code.Label == Enum_Code.MENU_TYPE_CATEGORY.ToString())
                link = menu.Category.GetLink();
            else if (menu.Code.Label == Enum_Code.MENU_TYPE_GALLERY.ToString())
                link = menu.Gallery.GetLink();
            else if (menu.Code.Label == Enum_Code.MENU_TYPE_LINK.ToString())
                link = menu.Link;
            return link;
        }

        public static string GetLink(this ProductBrand brand)
        {
            return "/br/" + brand.ID + "/" + brand.Name.StandardUrl();
        }

        public static string GetLink(this ProductType entity, int index = 1)
        {
            return "/pt/" + entity.ID + "/" + index + "/" + entity.Name.StandardUrl();
        }

        public static string GetLink(this ProductCategory entity, int index = 1)
        {
            return "/pc/" + entity.ID + "/" + index + "/" + entity.Name.StandardUrl();
        }

        public static string GetLink(this ProductSubCategory entity, int index = 1)
        {
            return "/ps/" + entity.ID + "/" + index + "/" + entity.Name.StandardUrl();
        }

        private static string GetSearchLink(ProductType type, ProductCategory category, ProductSubCategory subCategory, int index, string name)
        {
            string link = "/search";
            link += "/" + (type == null ? "0" : type.ID.ToString());
            link += "/" + (category == null ? "0" : category.ID.ToString());
            link += "/" + (subCategory == null ? "0" : subCategory.ID.ToString());
            link += "/" + index + "/";
            link += name.StandardUrl();
            return link;
        }
        
        public static string StandardUrl(this string url)
        {
            if (string.IsNullOrEmpty(url))
                return url;
            url = url.Replace(@" ", "-");
            url = url.Replace(@"%", "-");
            url = url.Replace(@".", "-");
            url = url.Replace(@"&", "-");
            url = url.Replace(@"+", "-");
            url = url.Replace(@"?", "-");
            url = url.Replace(@"*", "-");
            url = url.Replace(@"/", "-");
            url = url.Replace(@"\", "-");
            url = url.Replace(@"(", "-");
            url = url.Replace(@")", "-");
            url = url.Replace(@"|", "-");
            return url.ToLower();
        }

        public static string StandardPersian(this string input)
        {
            if (string.IsNullOrEmpty(input) == true)
                return input;
            input = input.Replace("ي", "ی");
            return input;
        }

        public static string GetShareUrl(this Enum_Social social, string url = null, string text = null)
        {
            url = url == null ? HttpContext.Current.Request.Url.ToString() : url;
            text = text == null ? "" : text;
            switch (social)
            {
                case Enum_Social.TELEGRAM:
                    url = "https://telegram.me/share/url?url=" + url + "&text=" + text;
                    break;
                case Enum_Social.FACEBOOK:
                    url = "https://www.facebook.com/sharer/sharer.php?u=" + url;
                    break;
                case Enum_Social.INSTAGRAM:
                    url = "" + url;
                    break;
                case Enum_Social.TWITTER:
                    url = "https://twitter.com/home?status=" + url;
                    break;
                case Enum_Social.WHATSAPP:
                    url = "https://api.whatsapp.com/send?text=" + url;
                    break;
                case Enum_Social.LINKEDIN:
                    url = "https://www.linkedin.com/shareArticle?mini=true&url=" + url;
                    break;
                case Enum_Social.PINTEREST:
                    url = "" + url;
                    break;
                case Enum_Social.EMAIL:
                    url = "" + url;
                    break;
                case Enum_Social.GOOGLE_PLUS:
                    url = "https://plus.google.com/share?url=" + url;
                    break;
                default:
                    break;
            }
            return url;
        }

        public static string GetOrderName(this Enum_ProductOrder order)
        {
            string name = "";
            switch (order)
            {
                case Enum_ProductOrder.NONE:
                    break;
                case Enum_ProductOrder.NEW:
                    name = "جدیدترین";
                    break;
                case Enum_ProductOrder.OLD:
                    name = "قدیمی ترین";
                    break;
                case Enum_ProductOrder.RANDOM:
                    name = "اتفاقی";
                    break;
                case Enum_ProductOrder.PRICE_MIN_TO_MAX:
                    name = "ارزان ترین";
                    break;
                case Enum_ProductOrder.PRICE_MAX_TO_MIN:
                    name = "گران ترین";
                    break;
                case Enum_ProductOrder.MORE_SELL:
                    name = "پر فروش ترین";
                    break;
                case Enum_ProductOrder.SHOWNUMBER:
                    name = "اولویت نمایش";
                    break;
                case Enum_ProductOrder.SHOWNUMBER_DESC:
                    name = "اولویت نمایش (نزولی)";
                    break;
                case Enum_ProductOrder.MORE_VISIT:
                    name = "پربازدیدترین";
                    break;
                case Enum_ProductOrder.MORE_LIKE:
                    name = "محبوب ترین";
                    break;
                case Enum_ProductOrder.MORE_RATING:
                    name = "محبوب ترین";
                    break;
                case Enum_ProductOrder.UPDATE:
                    name = "جدیدترین";
                    break;
                case Enum_ProductOrder.UPDATE_DESC:
                    name = "قدیمی ترین";
                    break;
                default:
                    break;
            }
            return name;
        }
    }
}
