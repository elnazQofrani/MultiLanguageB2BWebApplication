﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using DataLayer.Entities;
using DataLayer.ViewModels;
using DataLayer.Enumarables;

namespace DataLayer.Base
{
    public static class BaseSeo
    {
        public static ViewSeoPack GetSeoPack(this Post post)
        {
            string WebsiteName = BaseWebsite.ShopWebsite.Title;
            ViewSeoPack pack = new ViewSeoPack();
            pack.Title = post.Name;
            pack.Description = post.Summary;
            pack.Keywords = post.Name + ", " + post.Category.Name;
            pack.OpenGraph = new ViewSeoOpenGraph()
            {
                Url = post.GetLink(),
                Card = post.Summary,
                Description = post.Summary,
                SiteName = WebsiteName,
                Title = post.Name,
                Type = post.Category.Name,
                Locale = "ir_FA",
            };
            return pack;
        }

        public static ViewSeoPack GetSeoPack(this Product product, int amount = 0)
        {
            string image = product.Picture.GetUrl();
            ViewSeoPack pack = new ViewSeoPack();
            pack.Title = product.Name;
            pack.Description = product.Summary;
            pack.Keywords = product.Name;
            pack.OpenGraph = new ViewSeoOpenGraph() {
                Url = product.GetLink(),
                Card = product.Summary,
                Description = product.Summary,
                Title = product.Name,
                Type = "Products",
                Locale = "ir_FA",
                Amount = amount.ToString(),
                Image = product.Picture.GetUrl(),
                Image_Type = image.GetImageType(),
                Image_Width = "250",
                Image_Height = "250",
                Currency = "IRR"
            };
            return pack;
        }

        public static bool IsSeo()
        {
            UnitOfWork _context = new UnitOfWork();
            Uri url = HttpContext.Current.Request.Url;
            string panel_type = Enum_Code.SYSTEM_TYPE_PANEL.ToString();
            //string label = url.Host == "localhost" ? url.Host + ":" + url.Port :
            string label =
                HttpContext.Current.Request.Url.GetLeftPart(UriPartial.Authority) +
                HttpContext.Current.Request.ApplicationPath;

            bool result = _context.WebsiteDomain.Any(p =>
                p.Website.Code.Label == panel_type &&
                p.Website.Seo == true &&
                p.Domain == label);
            _context.Dispose();

            return result;
        }
    }
}
