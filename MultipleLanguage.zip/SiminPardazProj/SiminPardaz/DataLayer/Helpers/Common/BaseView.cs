﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer.ViewModels;
using DataLayer.Entities;

namespace DataLayer.Base
{
    public static class BaseView
    {

        public static List<ViewColor> ToView(this List<Color> list)
        {
            List<ViewColor> Output = new List<ViewColor>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewColor(list[i], i, MaxZero));
            }
            return Output;
        }



        public static List<ViewLanguage> ToView(this List<Language> list)
        {
            List<ViewLanguage> Output = new List<ViewLanguage>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewLanguage(list[i], i, MaxZero));
            }
            return Output;
        }



        public static List<ViewSize> ToView(this List<Size> list)
        {
            List<ViewSize> Output = new List<ViewSize>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewSize(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewProductBrand> ToView(this List<ProductBrand> list)
        {
            List<ViewProductBrand> Output = new List<ViewProductBrand>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewProductBrand(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewProduct> ToView(this List<Product> list)
        {
            List<ViewProduct> Output = new List<ViewProduct>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewProduct(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewSearchProductColorItem> ToViewSearchColor(this List<Product> list)
        {
            List<ViewSearchProductColorItem> Output = new List<ViewSearchProductColorItem>();

            foreach (Product item in list)
            {
                foreach (ProductColor color in item.ProductColor)
                {
                    Output.Add(new ViewSearchProductColorItem()
                    {
                        Product = item,
                        Color = color.Color
                    });
                }
            }
            return Output;
        }

        public static List<ViewProductCustomField> ToView(this List<ProductCustomField> list)
        {
            List<ViewProductCustomField> Output = new List<ViewProductCustomField>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewProductCustomField(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewProductCustomItem> ToView(this List<ProductCustomItem> list)
        {
            List<ViewProductCustomItem> Output = new List<ViewProductCustomItem>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewProductCustomItem(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewProductSubCategory> ToView(this List<ProductSubCategory> list)
        {
            List<ViewProductSubCategory> Output = new List<ViewProductSubCategory>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewProductSubCategory(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewProductType> ToView(this List<ProductType> list)
        {
            List<ViewProductType> Output = new List<ViewProductType>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewProductType(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewProductCategory> ToView(this List<ProductCategory> list)
        {
            List<ViewProductCategory> Output = new List<ViewProductCategory>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewProductCategory(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewUserGroup> ToView(this List<UserGroup> list)
        {
            List<ViewUserGroup> Output = new List<ViewUserGroup>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewUserGroup(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewTemplate> ToView(this List<Template> list)
        {
            List<ViewTemplate> Output = new List<ViewTemplate>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewTemplate(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewGallery> ToView(this List<Gallery> list)
        {
            List<ViewGallery> Output = new List<ViewGallery>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewGallery(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewSlider> ToView(this List<Slider> list)
        {
            List<ViewSlider> Output = new List<ViewSlider>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewSlider(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewWebsiteDomain> ToView(this List<WebsiteDomain> list)
        {
            List<ViewWebsiteDomain> Output = new List<ViewWebsiteDomain>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewWebsiteDomain(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewWebsite> ToView(this List<Website> list)
        {
            List<ViewWebsite> Output = new List<ViewWebsite>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewWebsite(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewDiscountGroup> ToView(this List<DiscountGroup> list)
        {
            List<ViewDiscountGroup> Output = new List<ViewDiscountGroup>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewDiscountGroup(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewDiscount> ToView(this List<Discount> list)
        {
            List<ViewDiscount> Output = new List<ViewDiscount>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewDiscount(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewMerchant> ToView(this List<Merchant> list)
        {
            List<ViewMerchant> Output = new List<ViewMerchant>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewMerchant(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewCategory> ToView(this List<Category> list)
        {
            List<ViewCategory> Output = new List<ViewCategory>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewCategory(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewPost> ToView(this List<Post> list)
        {
            List<ViewPost> Output = new List<ViewPost>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewPost(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewRebate> ToView(this List<Rebate> list)
        {
            List<ViewRebate> Output = new List<ViewRebate>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewRebate(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewAccount> ToView(this List<Account> list)
        {
            List<ViewAccount> Output = new List<ViewAccount>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewAccount(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewAccountOrder> ToView(this List<AccountOrder> list)
        {
            List<ViewAccountOrder> Output = new List<ViewAccountOrder>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewAccountOrder(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewSmsSetting> ToView(this List<SmsSetting> list)
        {
            List<ViewSmsSetting> Output = new List<ViewSmsSetting>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewSmsSetting(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewNewsletterGroup> ToView(this List<NewsletterGroup> list)
        {
            List<ViewNewsletterGroup> Output = new List<ViewNewsletterGroup>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewNewsletterGroup(list[i], i, MaxZero));
            }
            return Output;
        }

        public static List<ViewNewsLetter> ToView(this List<Newsletter> list)
        {
            List<ViewNewsLetter> Output = new List<ViewNewsLetter>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewNewsLetter(list[i], i, MaxZero));
            }
            return Output;
        }


        public static List<ViewEmailType> ToView(this List<EmailType> list)
        {
            List<ViewEmailType> Output = new List<ViewEmailType>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewEmailType(list[i], i, MaxZero));
            }
            return Output;
        }




        public static List<ViewCollaborationRequest> ToView(this List<CollaborationRequest> list)
        {
            List<ViewCollaborationRequest> Output = new List<ViewCollaborationRequest>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewCollaborationRequest(list[i], i, MaxZero));
            }
            return Output;
        }




        public static List<ViewInquiryRequest> ToView(this List<InquiryRequest> list)
        {
            List<ViewInquiryRequest> Output = new List<ViewInquiryRequest>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewInquiryRequest(list[i], i, MaxZero));
            }
            return Output;
        }




        public static List<ViewInquiryRequestGroup> ToView(this List<InquiryRequestGroup> list)
        {
            List<ViewInquiryRequestGroup> Output = new List<ViewInquiryRequestGroup>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewInquiryRequestGroup(list[i], i, MaxZero));
            }
            return Output;
        }

        public static ViewInquiryRequestGroup ToView(this InquiryRequestGroup model)
        {
            ViewInquiryRequestGroup Output = new ViewInquiryRequestGroup(model);

           int price = 0;
            foreach (var inquiryRequest in model.InquiryRequest)
            {                         
                Output.inquiryRequest.Add(new ViewInquiryRequest(inquiryRequest));

                price = price + (inquiryRequest.Count.Value * inquiryRequest.GivenPrice.Value);
            }

            Output.Price = price;
            Output.DateAnnounce = DateTime.Now;
            return Output;
        }

        public static List<ViewImportRequest> ToView(this List<ImportRequest> list)
        {
            List<ViewImportRequest> Output = new List<ViewImportRequest>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewImportRequest(list[i], i, MaxZero));
            }
            return Output;
        }


        public static List<ViewWebsiteContactForm> ToView(this List<WebsiteContactForm> list)
        {
            List<ViewWebsiteContactForm> Output = new List<ViewWebsiteContactForm>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewWebsiteContactForm(list[i], i, MaxZero));
            }
            return Output;
        }


        public static List<ViewMenu> ToView(this List<Menu> list)
        {
            List<ViewMenu> Output = new List<ViewMenu>();
            string MaxZero = list.GetMaxZero();

            for (int i = 0; i < list.Count; i++)
            {
                Output.Add(new ViewMenu(list[i], i, MaxZero));
            }
            return Output;
        }
    }
}
