﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Helpers.Common
{
    public static class BaseEnum
    {
        public static string GetDescription(this Enum en)
        {
            Type type = en.GetType();

            MemberInfo[] memInfo = type.GetMember(en.ToString());

            if (memInfo != null && memInfo.Length > 0)
            {
                object[] attrs = memInfo[0].GetCustomAttributes(typeof(DescriptionAttribute), false);

                if (attrs != null && attrs.Length > 0)
                {
                    return ((DescriptionAttribute)attrs[0]).Description;
                }
            }

            return en.ToString();
        }

        public static List<EnumList> GetEnumFromString<T>(object value)
        {
            if (!typeof(T).IsEnum)
            {
                throw new ArgumentException("T must be an enumerated type");
            }
            var result = new List<EnumList>();
            foreach (T item in (T[])Enum.GetValues(typeof(T)))
            {
                Type type = item.GetType();

                MemberInfo[] memInfo = type.GetMember(item.ToString());

                if (memInfo != null && memInfo.Length > 0)
                {
                    object[] attrs = memInfo[0].GetCustomAttributes(typeof(DescriptionAttribute), false);

                    if (attrs != null && attrs.Length > 0)
                    {
                        var i = new EnumList()
                        {
                            Value = Convert.ToInt32(item),
                            Description = ((DescriptionAttribute)attrs[0]).Description
                        };
                        result.Add(i);
                    }
                }
            }

            return result;

        }

        public class EnumList
        {
            public int Value { get; set; }
            public string Description { get; set; }
        }
    }
}
