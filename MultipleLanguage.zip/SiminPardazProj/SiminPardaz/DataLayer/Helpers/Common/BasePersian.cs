﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Persia;

namespace DataLayer.Base
{
    public static class BasePersian
    {
        public static bool IsPersian(this DateTime datetime)
        {
            if (datetime.Year < 1500)
                return true;
            return false;
        }

        public static string ToPersian(this string str)
        {
            return (string.IsNullOrEmpty(str) == false) ? Number.ConvertToPersian(str) : "";
        }

        public static string ToPersian(this int input)
        {
            return Number.ConvertToPersian(input);
        }

        public static string ToPersian(this int? input)
        {
            return input == null ? 0.ToPersian() : input.Value.ToPersian();
        }

        public static string ToPersianComplete(this DateTime? datetime)
        {
            if (datetime == null)
                return "";
            return datetime.Value.ToPersianComplete();
        }

        public static string ToPersianComplete(this DateTime datetime)
        {
            return Calendar.ConvertToPersian(datetime).Weekday;
        }

        public static string ToPersianWithTime(this DateTime? datetime)
        {
            if (datetime == null)
                return "";
            return datetime.Value.ToPersianWithTime();
        }

        public static string ToPersianWithTime(this DateTime datetime)
        {
            return Calendar.ConvertToPersian(datetime).Simple + " " + datetime.Hour.ToPersian() + ":" + datetime.Minute.ToPersian();
        }

        public static string ToPersian(this DateTime? datetime)
        {
            if (datetime == null)
                return "";
            return datetime.Value.ToPersian();
        }

        public static string ToPersian(this DateTime datetime)
        {
            if (datetime != default(DateTime))
            {
                string temp = Calendar.ConvertToPersian(datetime).Simple.ToString();
                return Number.ConvertToLatin(temp);
            }
            return "";
        }

        public static string ToPersianGiv(this DateTime datetime)
        {
            string temp = "";
            if (datetime != default(DateTime))
            {
                temp += Calendar.ConvertToPersian(datetime).ArrayType[0];
                temp += Calendar.ConvertToPersian(datetime).ArrayType[1].ToString("00");
                temp += Calendar.ConvertToPersian(datetime).ArrayType[2].ToString("00");
            }
            return Number.ConvertToLatin(temp);
        }

        public static string GetEnglish(this string number)
        {
            if (number == null)
                return "";
            return Number.ConvertToLatin(number);
        }
    }
}
