﻿using Quartz;
using Quartz.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Schedules
{
    public class SyncServer_Scheduler
    {
        public static void Start()
        {
            IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
            scheduler.Start();

            SmsScheduler(scheduler);
            EmailScheduler(scheduler);
        }

        public static void EmailScheduler(IScheduler scheduler)
        {
            IJobDetail job = JobBuilder.Create<Sync_Email>().Build();
            ITrigger trigger = TriggerBuilder.Create()
                .WithSimpleSchedule(p =>
                    p.WithIntervalInSeconds(2)
                    .RepeatForever())
                .StartNow()
                .Build();

            scheduler.ScheduleJob(job, trigger);
        }

        public static void SmsScheduler(IScheduler scheduler)
        {
            IJobDetail job = JobBuilder.Create<Sync_Sms>().Build();
            ITrigger trigger = TriggerBuilder.Create()
                .WithSimpleSchedule(p =>
                    p.WithIntervalInSeconds(1)
                    .RepeatForever())
                .StartNow()
                .Build();

            scheduler.ScheduleJob(job, trigger);
        }
    }
}
