﻿using DataLayer.Base;
using DataLayer.Entities;
using DataLayer.Enumarables;
using DataLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Api.Model
{
    public class ApiAccount : ApiResponse
    {
        public static ApiResult Post_DoLogin(UnitOfWork _context, Account account, string password, bool isWeb)
        {
            Account temp = _context.Account.GetByEmail(account.Email);
            Guid uniqueId = temp != null ? temp.UniqueId : new Guid();
            string first_password = BaseSecurity.HashMd5(password);
            string second_password = BaseSecurity.HashPassword(uniqueId, password);
            Account user = _context.Account.GetFromUsernameAndPassword(account, first_password, second_password);
            if (user == null)
                return CreateErrorResult(Enum_Message.INVALID_USERNAME_PASSWORD);
            else
            {
                if (isWeb)
                {
                    _context.AccountBasket.MergeAccountBasket(user.ID);
                }

                AccountLog log = _context.AccountLog.NewLog(user.ID, isWeb);
                _context.AccountLog.Insert(log);
                _context.Save();

                ViewAccount entity = user.ToApi();
                entity.Key = log.AccountKey;
                return CreateSuccessResult(entity);
            }
        }

        public static ApiResult Post_DoLogout(UnitOfWork _context, ViewAccount account)
        {
            if (account != null)
            {
                _context.Account.Logout();
            }
            return CreateSuccessResult();
        }

        public static ApiResult Post_DoRegister(UnitOfWork _context, Account account, bool isWeb, string ConfirmPassword)
        {
            if (account != null)
            {
                account.Mobile = string.IsNullOrEmpty(account.Mobile) == false ? account.Mobile.Trim().GetEnglish().ToString() : account.Mobile;
                account.Email = string.IsNullOrEmpty(account.Email) == false ? account.Email.Trim().GetEnglish().ToString() : account.Email;
            }

            if (account.Mobile == null && BaseSecurity.IsValidInput(account.Email, Enum_Validation.MOBILE))
            {
                account.Mobile = account.Email;
                account.Email = null;
            }

            if (account.Email == null && BaseSecurity.IsValidInput(account.Mobile, Enum_Validation.EMAIL))
            {
                account.Email = account.Mobile;
                account.Mobile = null;
            }

            Account reagentUser = _context.Account.GetFromReagentCode(account.ReagentCode);
            if (account == null)
                return CreateErrorResult(Enum_Message.REQUIRED_ACCOUNT);
            if (account.Mobile == null)
                return CreateErrorResult(Enum_Message.REQUIRED_ACCOUNT_MOBILE);
            else if (string.IsNullOrEmpty(account.FullName))
                return CreateErrorResult(Enum_Message.REQUIRED_ACCOUNT_FULLNAME);
            else if (string.IsNullOrEmpty(account.Email) && string.IsNullOrEmpty(account.Mobile))
                return CreateErrorResult(Enum_Message.REQUIRED_ACCOUNT_EMAIL_OR_MOBILE);
            else if (string.IsNullOrEmpty(account.Password))
                return CreateErrorResult(Enum_Message.REQUIRED_ACCOUNT_PASSWORD);
            else if (account.Password != ConfirmPassword)
                return CreateErrorResult(Enum_Message.INVALID_PASSWORD_CONFIRM);
            else if (BaseSecurity.IsValidInput(account.Mobile, Enum_Validation.MOBILE) == false)
                return CreateErrorResult(Enum_Message.INVALID_ACCOUNT_MOBILE);
            else if (BaseSecurity.IsValidInput(account.Email, Enum_Validation.EMAIL) == false)
                return CreateErrorResult(Enum_Message.INVALID_ACCOUNT_EMAIL);
            else if (account.ReagentCode != null && string.IsNullOrEmpty(account.ReagentCode.Trim()) == false && reagentUser == null)
                return CreateErrorResult(Enum_Message.INVALID_REAGENT_CODE);
            else if (string.IsNullOrEmpty(account.Email) == false && _context.Account.GetByEmail(account.Email) != null)
                return CreateErrorResult(Enum_Message.DUPLICATED_ACCOUNT_EMAIL);
            else if (string.IsNullOrEmpty(account.Mobile) == false && _context.Account.GetByMobile(account.Mobile) != null)
                return CreateErrorResult(Enum_Message.DUPLICATED_ACCOUNT_MOBILE);
            
            account.ReagentCode = _context.Account.GenerateNewReagentCode();
            account.Password = BaseSecurity.HashMd5(account.Password);
            account.UpdateDatetime = DateTime.Now;
            account.CreateDatetime = DateTime.Now;
            account.UniqueId = Guid.NewGuid();
            account.Active = false;
            account.TrackingCode = _context.Account.GenerateNewTrackingCode();
            _context.Account.Insert(account);
            _context.Save();

            ViewAccount entity = account.ToApi();
            AccountLog log = _context.AccountLog.NewLog(account.ID, isWeb);
            _context.AccountLog.Insert(log);
            _context.Save();
            entity.Key = log.AccountKey;

            if (isWeb)
            {
                _context.AccountBasket.MergeAccountBasket(account.ID);
            }

            StringBuilder str = new StringBuilder();
            ViewWebsite website = BaseWebsite.ShopWebsite;
            string token1 = account.Mobile;
            string token2 = ConfirmPassword;
            string token3 = "";
            str.AppendLine("ثبت نام شما در سایت (" + website.Domain + ") با موفقیت انجام شد");
            str.AppendLine("نام کاربری: " + token1);
            str.AppendLine("رمز عبور: " + token2);
            _context.Sms.SaveNewSms(account.Mobile, Enum_SmsType.ACCOUNT_REGISTER, str.ToString(), token1, token2, token3);
            _context.Email.SaveNewEmail(account.Email, Enum_EmailType.ACCOUNT_REGISTER, str.ToString(), "ثبت نام در سایت");
            _context.Save();

            return CreateSuccessResult(Enum_Message.SUCCESSFULL_REGISTER, entity);
        }
        
        public static ApiResult Get_Account(UnitOfWork _context, int accountId)
        {
            Account account = _context.Account.GetById(accountId);
            return CreateSuccessResult(account.ToApi());
        }

        public static ApiResult Put_Account(UnitOfWork _context, ViewAccount account, int accountId)
        {
            Account entity = _context.Account.GetById(accountId);
            entity.Address = account.Address;
            entity.Agent = account.Agent;
            entity.AgentPhone = account.AgentPhone;
            entity.Company = account.Company;
            entity.CompanyNo = account.CompanyNo;
            entity.Email = account.Email;
            entity.FullName = account.FullName;
            entity.IsMale = account.IsMale;
            entity.Job = account.Job;
            entity.Mobile = account.Mobile;
            entity.NationalCode = account.NationalCode;
            entity.Phone = account.Phone;
            entity.ReagentName = account.ReagentName;
            entity.Description = account.Description;
            entity.BirthDate = string.IsNullOrEmpty(account.BirthDate) ? default(DateTime?) : BaseDate.GetGregorian(account.BirthDate);
            _context.Account.Update(entity);
            _context.Save();

            Account tempEntity = _context.Account.GetById(account.Id);
            return CreateSuccessResult(tempEntity.ToApi());
        }

        public static ApiResult Put_ChangePassword(UnitOfWork _context, ViewAccount account, string newPassword, string confirmPassword)
        {
            Account entity = _context.Account.GetById(account.Id);
            
            if (string.IsNullOrEmpty(newPassword))
                return CreateErrorResult(Enum_Message.REQUIRED_PASSWORD);
            else if (string.IsNullOrEmpty(confirmPassword))
                return CreateErrorResult(Enum_Message.REQUIRED_PASSWORD_CONFIRM);
            else if (newPassword != confirmPassword)
                return CreateErrorResult(Enum_Message.INVALID_PASSWORD_CONFIRM);
            
            entity.Password = BaseSecurity.HashMd5(newPassword);
            _context.Save();

            return CreateSuccessResult(entity.ToApi());
        }
    }
}
