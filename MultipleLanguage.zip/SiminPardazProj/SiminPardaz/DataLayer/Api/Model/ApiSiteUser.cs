﻿using DataLayer.Base;
using DataLayer.Entities;
using DataLayer.ViewModels;
using DataLayer.Enumarables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Api.Model
{
    public class ApiSiteUser : ApiResponse
    {
        public static ApiResult Put_ChangePassword(UnitOfWork _context, SiteUser user, string newPassword, string confirmPassword)
        {
            SiteUser entity = _context.SiteUser.GetById(user.ID);

            if (string.IsNullOrEmpty(newPassword))
                return CreateErrorResult(Enum_Message.REQUIRED_PASSWORD);
            else if (string.IsNullOrEmpty(confirmPassword))
                return CreateErrorResult(Enum_Message.REQUIRED_PASSWORD_CONFIRM);
            else if (newPassword != confirmPassword)
                return CreateErrorResult(Enum_Message.INVALID_PASSWORD_CONFIRM);

            entity.Password = BaseSecurity.HashMd5(newPassword);
            _context.Save();

            return CreateSuccessResult();
        }

        public static ApiResult Post_DoLogin(UnitOfWork _context, ViewSiteUser entity)
        {
            if (entity == null)
                return CreateErrorResult(Enum_Message.INVALID_DATA);
            if (string.IsNullOrEmpty(entity.Mobile) && string.IsNullOrEmpty(entity.Email))
                return CreateErrorResult(Enum_Message.REQUIRED_ADMIN_INFO);
            if (string.IsNullOrEmpty(entity.Password))
                return CreateErrorResult(Enum_Message.REQUIRED_PASSWORD);


            string password = BaseSecurity.HashMd5(entity.Password);
            SiteUser user = _context.SiteUser.GetFromUsernameAndPassword(entity, password);
            if (user == null)
                return CreateErrorResult(Enum_Message.INVALID_USERNAME_PASSWORD);
            else if (user.Active == false)
                return CreateErrorResult(Enum_Message.USER_ID_INACTIVE);
            return CreateSuccessResult(user.ToApi());
        }

        public static ApiResult Post_DoLogout(UnitOfWork _context)
        {
            return CreateSuccessResult();
        }
    }
}
