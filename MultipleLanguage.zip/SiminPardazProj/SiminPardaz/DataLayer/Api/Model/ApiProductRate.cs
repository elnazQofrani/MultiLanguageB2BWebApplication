﻿using DataLayer.Entities;
using DataLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Api.Model
{
    public class ApiProductRate : ApiResponse
    {
        public static ApiResult Post(UnitOfWork _context, int productId, int rateValue)
        {
            ViewAccount CurrentUser = _context.Account.GetCurrentAccount();
            if (CurrentUser == null)
                return CreateInvalidKeyResult();

            _context.ProductRate.UpsertProductRating(productId, CurrentUser.Id, rateValue);
            return CreateSuccessResult();
        }
    }
}
