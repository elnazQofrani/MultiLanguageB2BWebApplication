﻿using DataLayer.Base;
using DataLayer.Entities;
using DataLayer.Enumarables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Api.Model
{
    public class ApiBasket : ApiResponse
    {
        public static ApiResult Get(UnitOfWork _context, int? accountId)
        {
            List<AccountBasket> list;
            if (accountId != null)
                list = _context.AccountBasket.GetAllByAccount(accountId.GetValueOrDefault());
            else
                list = _context.AccountBasket.GetAllFromCookie();
            return CreateSuccessResult(list.ToApi());
        }

        public static ApiResult Post(UnitOfWork _context, int? accountId, int productId, int? colorId = null, int? sizeId = null, int? resellerId = null, int count = 1)
        {
            List<AccountBasket> list = new List<AccountBasket>();
            Product product = _context.Product.GetById(productId);
            //if (product.Active == false)
            //    return CreateErrorResult(Enum_Message.INVALID_PRODUCT_ACTIVE);
            if (count < 1)
                return CreateErrorResult(Enum_Message.INVALID_DATA);
            bool isAvailable = _context.AccountBasket.AddToBasket(out list, product, accountId, colorId, sizeId, resellerId, count);

            if (isAvailable == false)
            {
                if (colorId != null && sizeId != null)
                    return CreateErrorResult(Enum_Message.INVALID_PRODUCT_QUANTITY_COLOR_SIZE);
                else if (colorId != null)
                    return CreateErrorResult(Enum_Message.INVALID_PRODUCT_QUANTITY_COLOR);
                else if (sizeId != null)
                    return CreateErrorResult(Enum_Message.INVALID_PRODUCT_QUANTITY_SIZE);
                else
                    return CreateErrorResult(Enum_Message.INVALID_PRODUCT_QUANTITY);
            }

            if (accountId != null)
            {
                _context = new UnitOfWork();
                list = _context.AccountBasket.GetAllByAccount(accountId.GetValueOrDefault());
            }
            else
                list = _context.AccountBasket.CastCookieBasket(list, true);

            return CreateSuccessResult(Enum_Message.SUCCESSFULL_ADD_BASKET , list.ToApi());
        }

        public static ApiResult Delete(UnitOfWork _context, int accountId, int basketId)
        {
            AccountBasket basket = _context.AccountBasket.GetById(basketId);
            if (basket == null)
                return CreateErrorResult(Enum_Message.INVALID_DATA);
            if (basket.AccountId != accountId)
                return CreateInvalidKeyResult();

            _context.AccountBasket.Delete(basket);
            _context.Save();

            List<AccountBasket> list = _context.AccountBasket.GetAllByAccount(accountId);
            return CreateSuccessResult(Enum_Message.SUCCESSFULL_DELETE_BASKET, list.ToApi());
        }

        public static ApiResult Delete(UnitOfWork _context, int productId, int? colorId, int? sizeId)
        {
            List<AccountBasket> listBasket = _context.AccountBasket.GetAllFromCookie(false);
            AccountBasket basket = listBasket.FirstOrDefault(p =>
                    p.ProductId == productId &&
                    p.ProductColorId == colorId &&
                    p.ProductSizeId == sizeId
                );
            if (basket == null)
                return CreateErrorResult(Enum_Message.INVALID_DATA);

            int basketIndex = listBasket.FindIndex(p =>
                            p.ProductId == basket.ProductId &&
                            p.ProductColorId == basket.ProductColorId &&
                            p.ProductSizeId == basket.ProductSizeId);

            listBasket.RemoveAt(basketIndex);
            _context.AccountBasket.SetCookieBasket(listBasket);
            listBasket = _context.AccountBasket.CastCookieBasket(listBasket);
            return CreateSuccessResult(Enum_Message.SUCCESSFULL_DELETE_BASKET, listBasket.ToApi());
        }

        public static ApiResult PutCookie(UnitOfWork _context, string actionType, int productId, int? colorId = null, int? sizeId = null, int count = 1)
        {
            List<AccountBasket> listBasket = _context.AccountBasket.GetAllFromCookie();
            AccountBasket basket = listBasket.FirstOrDefault(p =>
                p.ProductId == productId &&
                p.ProductColorId == colorId &&
                p.ProductSizeId == sizeId
            );

            if (basket == null)
                return CreateErrorResult(Enum_Message.INVALID_DATA);

            if (basket.Count == 1 && actionType == "remove")
                return CreateSuccessResult(Enum_Message.SUCCESSFULL_API);

            ApiResult result = new ApiResult();

            result = UpdateCookieBasket(_context, listBasket, basket, actionType, count);

            listBasket = _context.AccountBasket.CastCookieBasket(listBasket);
            return CreateSuccessResult(Enum_Message.SUCCESSFULL_API, listBasket.ToApi());
        }

        private static ApiResult UpdateCookieBasket(UnitOfWork _context, List<AccountBasket> listBasket, AccountBasket basket, string actionType, int count)
        {
            int basketIndex = listBasket.FindIndex(p =>
                            p.ProductId == basket.ProductId &&
                            p.ProductColorId == basket.ProductColorId &&
                            p.ProductSizeId == basket.ProductSizeId);

            if (actionType == "add")
                basket.Count = basket.Count + 1;
            else if (actionType == "remove")
                basket.Count = basket.Count - 1;
            else if (actionType == "update")
                basket.Count = count;

            if (basket.Product.Code.Label != Enum_Code.PRODUCT_STATUS_AVAILABLE.ToString())
            {
                return CreateErrorResult(Enum_Message.INVALID_PRODUCT_QUANTITY);
            }
            if (basket.ProductColorId != null || basket.ProductSizeId != null)
            {
                ProductQuantity productQuantity = _context.ProductQuantity.FirstOrDefault(p =>
                    p.ColorId == basket.ProductColorId &&
                    p.SizeId == basket.ProductSizeId &&
                    p.ProductId == basket.ProductId
                );
                if (productQuantity == null)
                    return CreateErrorResult(Enum_Message.INVALID_PRODUCT_QUANTITY_COLOR_SIZE);
                else if (productQuantity.Count < basket.Count)
                    return CreateErrorResult(Enum_Message.INVALID_PRODUCT_QUANTITY_COLOR_SIZE);
            }
            else if (basket.Product.Quantity != null && basket.Count > basket.Product.Quantity)
                return CreateErrorResult(Enum_Message.INVALID_PRODUCT_QUANTITY);


            basket.Price = (basket.Count * basket.Product.GetDiscountPrice(basket.ProductColorId));
            basket.Weight = basket.Count * basket.Product.Weight;

            listBasket[basketIndex] = basket;
            _context.AccountBasket.SetCookieBasket(listBasket);

            return CreateSuccessResult();
        }

        public static ApiResult PutAccount(UnitOfWork _context, string actionType, int accountId, int basketId, int count = 1)
        {
            AccountBasket basket = _context.AccountBasket.GetById(basketId);
            if (basket == null)
                return CreateErrorResult(Enum_Message.INVALID_DATA);
            if (basket.AccountId != accountId)
                return CreateInvalidKeyResult();
            if (basket.Count == 1 && actionType == "remove")
                return CreateSuccessResult(Enum_Message.SUCCESSFULL_API);
            ApiResult result = new ApiResult();
            result = UpdateAccountBasket(_context, basket, actionType, count);
            if (result.Code == ApiResult.ResponseCode.Success)
            {
                List<AccountBasket> list = _context.AccountBasket.GetAllByAccount(accountId);
                return CreateSuccessResult(Enum_Message.SUCCESSFULL_API, list.ToApi());
            }
            return result;
        }

        private static ApiResult UpdateAccountBasket(UnitOfWork _context, AccountBasket basket, string actionType, int count)
        {
            if (basket.Product.Code.Label != Enum_Code.PRODUCT_STATUS_AVAILABLE.ToString())
                return CreateErrorResult(Enum_Message.INVALID_PRODUCT_QUANTITY);

            if (actionType == "add")
                basket.Count = basket.Count + 1;
            else if (actionType == "remove")
                basket.Count = basket.Count - 1;
            else if (actionType == "update")
                basket.Count = count;

            if (basket.ProductColorId != null || basket.ProductSizeId != null)
            {
                ProductQuantity productQuantity = _context.ProductQuantity.FirstOrDefault(p =>
                    p.ColorId == basket.ProductColorId &&
                    p.SizeId == basket.ProductSizeId &&
                    p.ProductId == basket.ProductId
                );
                if (productQuantity == null)
                    return CreateErrorResult(Enum_Message.INVALID_PRODUCT_QUANTITY_COLOR_SIZE);
                else if (productQuantity.Count < basket.Count)
                    return CreateErrorResult(Enum_Message.INVALID_PRODUCT_QUANTITY_COLOR_SIZE);
            }
            else if (basket.Product.Quantity != null && basket.Count > basket.Product.Quantity)
                return CreateErrorResult(Enum_Message.INVALID_PRODUCT_QUANTITY);

            basket.Price = (basket.Count * basket.Product.GetDiscountPrice(basket.ProductColorId));
            basket.Weight = basket.Count * basket.Product.Weight;
            _context.AccountBasket.Update(basket);
            _context.Save();

            return CreateSuccessResult();
        }
    }
}
