﻿using DataLayer.Entities;
using DataLayer.Enumarables;
using DataLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Api.Model
{
    public class ApiCollaborationRequest : ApiResponse
    {
        public static ApiResult PostSingle(UnitOfWork _context, ViewCollaborationRequest request)
        {
            if (request == null)
                return CreateErrorResult(Enum_Message.INVALID_DATA);

            CollaborationRequest entity = new CollaborationRequest()
            {
                Address = request.Address,
                CareerBackground = request.CareerBackground,
                CompanyName = request.CompanyName,
                DegreeAndUniversity = request.DegreeAndUniversity,
                DegreeEducation = request.DegreeEducation,
                EmailAddress = request.EmailAddress,
                Family = request.Family,
                Mobile = request.Mobile,
                Name = request.Name,
                SectionRequested = request.SectionRequested,
                SellBAckground = request.SellBAckground,
                Phone = request.Phone,
                SummaryCourses = request.SummaryCourses
            };
            _context.CollaborationRequest.Insert(entity);
            _context.Save();

            return CreateSuccessResult();
        }
    }
}
