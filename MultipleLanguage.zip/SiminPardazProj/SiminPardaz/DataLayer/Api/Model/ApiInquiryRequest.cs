﻿using DataLayer.Entities;
using DataLayer.Enumarables;
using DataLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Api.Model
{
    public class ApiInquiryRequest : ApiResponse
    {
        public static ApiResult PostSingle(UnitOfWork _context, ViewInquiryRequest request)
        {
            ViewAccount CurrentUser = _context.Account.GetCurrentAccount();
            if (CurrentUser == null)
                return CreateInvalidKeyResult();

            if (request == null)
                return CreateErrorResult(Enum_Message.INVALID_DATA);

            if (string.IsNullOrEmpty(request.ProductCodeValue))
                return CreateErrorResult(Enum_Message.REQUIRED_INQUIRY_PRODUCT);

            Product product = _context.Product.GetByCodeValue(request.ProductCodeValue);
            if (product == null)
                return CreateErrorResult(Enum_Message.INVALID_PRODUCT_CODEVALUE);

            InquiryRequestGroup requestGroup = new InquiryRequestGroup()
            {
                AccountId = CurrentUser.Id,
                DateRequest = DateTime.Now,
                Inquiry_Status = _context.Code.GetIdByLabel(Enum_Code.INQUIRY_REQUEST),
            };
            _context.InquiryRequestGroup.Insert(requestGroup);
            _context.Save();

            InquiryRequest entity = new InquiryRequest()
            {
                Count = request.Count,
                InquiryRequestGroupId = requestGroup.ID,
                ProductId = product.ID
            };
            _context.InquiryRequest.Insert(entity);
            _context.Save();
            
            List<SiteUser> listUser = _context.SiteUser.GetAllByUsersForInquiry();
            string message = "استعلام قیمت جدید در سایت شرکت تهران فرگام ثبت شد";
            foreach (var item in listUser)
            {
                _context.Sms.SaveNewSms(item.Mobile, Enum_SmsType.INQUIRY, message);
            }
            _context.Save();

            return CreateSuccessResult();
        }

        public static ApiResult Post(UnitOfWork _context)
        {
            ViewAccount CurrentUser = _context.Account.GetCurrentAccount();
            if (CurrentUser == null)
                return CreateInvalidKeyResult();

            List<AccountBasket> list = _context.AccountBasket.GetAllByAccount(CurrentUser.Id);
            if (list.Any())
            {
                InquiryRequestGroup requestGroup = new InquiryRequestGroup() {
                    AccountId = CurrentUser.Id,
                    DateRequest = DateTime.Now,
                    Inquiry_Status = _context.Code.GetIdByLabel(Enum_Code.INQUIRY_REQUEST),
                };
                _context.InquiryRequestGroup.Insert(requestGroup);
                _context.Save();

                foreach (var item in list)
                {
                    InquiryRequest entity = new InquiryRequest()
                    {
                        Count = item.Count,
                        InquiryRequestGroupId = requestGroup.ID,
                        ProductId = item.ProductId
                    };
                    _context.InquiryRequest.Insert(entity);
                    _context.Save();
                }

                _context.AccountBasket.ClearBasket(CurrentUser.Id);
                _context.AccountBasket.Save();

                List<SiteUser> listUser = _context.SiteUser.GetAllByUsersForInquiry();
                string message = "استعلام قیمت جدید در سایت شرکت تهران فرگام ثبت شد";
                foreach (var item in listUser)
                {
                    _context.Sms.SaveNewSms(item.Mobile, Enum_SmsType.INQUIRY, message);
                }
                _context.Save();
            }
            
            return CreateSuccessResult();
        }
    }
}
