﻿using DataLayer.Entities;
using DataLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Api.Model
{
    public class ApiProductLike : ApiResponse
    {
        public static ApiResult Get(UnitOfWork _context, int accountId)
        {
            List<ProductLike> list = _context.ProductLike.GetAllByAccountId(accountId);
            return CreateSuccessResult(list.ToApi());
        }

        public static ApiResult Post(UnitOfWork _context, int productId)
        {
            ViewAccount CurrentUser = _context.Account.GetCurrentAccount();
            if (CurrentUser != null)
            {
                bool isRepeated = _context.ProductLike.IsAny(productId, CurrentUser.Id);
                if (isRepeated == false)
                {
                    ProductLike like = new ProductLike()
                    {
                        AccountId = CurrentUser.Id,
                        ProductId = productId,
                        Datetime = DateTime.Now
                    };
                    _context.ProductLike.Insert(like);
                    _context.Save();
                }
                
                return CreateSuccessResult();
            }
            else
            {
                return CreateInvalidKeyResult();
            }
        }

        public static ApiResult Delete(UnitOfWork _context, int productId)
        {
            ViewAccount CurrentUser = _context.Account.GetCurrentAccount();
            if (CurrentUser != null)
            {
                ProductLike like = _context.ProductLike.GetByProductIdAndAccountId(productId, CurrentUser.Id);
                if (like != null)
                {
                    _context.ProductLike.Delete(like);
                    _context.Save();
                    return Get(_context, like.AccountId);
                }
                else
                    return CreateSuccessResult();
            }
            else
            {
                return CreateInvalidKeyResult();
            }
        }
    }
}
