﻿using DataLayer.Entities;
using DataLayer.Enumarables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Api
{
    public class ApiProduct : ApiResponse
    {
        public static ApiResult Search(
            UnitOfWork _context,
            string active = null,
            int? notId = null,
            int? index = null, 
            int? pageSize = null,
            string typeId = null, 
            string categoryId = null, 
            string subCategoryId = null,
            string brandId = null,
            string name = null,
            string custom = null,
            int? pricefrom = null,
            int? priceto = null,
            Enum_ProductOrder order = Enum_ProductOrder.NONE)
        {
            pageSize = pageSize == null ? 10 : pageSize;
            index = index == null ? 1 : index;
            List<Product> list = _context.Product.Search(
                active: active,
                notId: notId,
                typeId: typeId,
                categoryId: categoryId,
                brandId: brandId,
                subCategoryId: subCategoryId,
                index: index.Value,
                pageSize: pageSize.Value,
                name: name,
                custom: custom,
                pricefrom: pricefrom,
                priceto: priceto,
                order: order);
            return ApiResponse.CreateSuccessResult(list.ToApi());
        }
    }
}
