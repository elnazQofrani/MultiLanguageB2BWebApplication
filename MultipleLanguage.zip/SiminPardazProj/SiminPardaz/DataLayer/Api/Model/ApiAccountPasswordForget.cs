﻿using DataLayer.Base;
using DataLayer.Entities;
using DataLayer.ViewModels;
using DataLayer.Enumarables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Api.Model
{
    public class ApiAccountPasswordForget : ApiResponse
    {
        public static ApiResult Post(UnitOfWork _context, Account account)
        {
            if (account == null ||
                (
                    string.IsNullOrEmpty(account.Mobile) && 
                    string.IsNullOrEmpty(account.Email))
                )
                return CreateErrorResult(Enum_Message.REQUIRED_ACCOUNT);

            Account entity = null;
            if (string.IsNullOrEmpty(account.Mobile) == false)
                entity = _context.Account.GetByMobile(account.Mobile);
            else if (string.IsNullOrEmpty(account.Email) == false)
                entity = _context.Account.GetByEmail(account.Email);

            if (entity == null)
                return CreateErrorResult(Enum_Message.INVALID_ACCOUNT_DATA);

            Random rand = new Random();
            AccountPasswordForget forget = new AccountPasswordForget() {
                AccountId = entity.ID,
                Datetime = DateTime.Now,
                EmailKey = Guid.NewGuid().ToString(),
                MobileKey = rand.Next(100000, 999999).ToString(),
                IsUsed = false
            };

            _context.AccountPasswordForget.Insert(forget);
            _context.Save();

            if (entity.Mobile != null)
            {
                StringBuilder str = new StringBuilder();
                ViewWebsite website = BaseWebsite.ShopWebsite;
                string token1 = forget.MobileKey;
                string token2 = "";
                string token3 = "";
                str.AppendLine("کد بازیابی رمز عبور شما در سایت " + website.Title + "، " + forget.MobileKey + " می باشد");
                _context.Sms.SaveNewSms(account.Mobile, Enum_SmsType.FORGET_PASSWORD, str.ToString(), token1, token2, token3);
                _context.Save();

                return CreateSuccessResult(Enum_Message.SUCCESSFULL_FORGET_PASSWORD_MOBILE);
            }
            else
            {
                string url = BaseWebsite.ShopUrl;
                if (string.IsNullOrEmpty(url) == false)
                {
                    StringBuilder str = new StringBuilder();
                    str.Append("لینک بازیابی رمز عبور: ");
                    str.Append("<br />");
                    str.Append(url + "recover?k=" + forget.EmailKey + "&a=" + entity.UniqueId);
                    _context.Email.SaveNewEmail(entity.Email, Enum_EmailType.FORGETPASSWORD, str.ToString(), "بازیابی رمز عبور");
                    _context.Save();
                }

                return CreateSuccessResult(Enum_Message.SUCCESSFULL_FORGET_PASSWORD_EMAIL);
            }
        }

        public static ApiResult Put(UnitOfWork _context, string recoverValue)
        {
            if (string.IsNullOrEmpty(recoverValue))
                return CreateErrorResult(Enum_Message.REQUIRED_RECOVER_VALUE);
            AccountPasswordForget entity = _context.AccountPasswordForget.GetByMobileKey(recoverValue);
            if (entity == null)
                return CreateErrorResult(Enum_Message.INVALID_RECOVER_CODE);

            AccountLog log = _context.AccountLog.NewLog(entity.AccountId, true);
            _context.AccountLog.Insert(log);
            _context.Save();

            ViewAccount account = entity.Account.ToApi();
            account.Key = log.AccountKey;
            return CreateSuccessResult(account);
        }

        public static ApiResult Post_ChangePassword(UnitOfWork _context, AccountPasswordForget forget, string password, string confirm)
        {
            if (forget == null)
                return CreateErrorResult(Enum_Message.INVALID_DATA);
            if (string.IsNullOrEmpty(password) == true)
                return CreateErrorResult(Enum_Message.REQUIRED_PASSWORD);
            if (string.IsNullOrEmpty(confirm) == true)
                return CreateErrorResult(Enum_Message.REQUIRED_PASSWORD_CONFIRM);
            if (password != confirm)
                return CreateErrorResult(Enum_Message.INVALID_PASSWORD_CONFIRM);

            forget = _context.AccountPasswordForget.GetById(forget.ID);
            forget.IsUsed = true;

            Account account = forget.Account;
            account.Password = BaseSecurity.HashMd5(password);
            _context.Account.Update(account);
            _context.Save();

            return CreateSuccessResult(Enum_Message.SUCCESSFULL_SUBMIT, account);
        }
    }
}
