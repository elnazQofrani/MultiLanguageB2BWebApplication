﻿using DataLayer.Entities;
using DataLayer.Enumarables;
using DataLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Api.Model
{
    public class ApiPayment : ApiResponse
    {
        public static ApiResult Post(UnitOfWork _context, int? accountId, int? siteuserId, ViewPayment payment)
        {
            if (payment.PaymentSubject == null || payment.PaymentSubject.Label == null)
                return CreateErrorResult(Enum_Message.REQUIRED_PAYMENT_SUBJECT);

            int? merchantId = payment.Merchant == null ? default(int?) : payment.Merchant.Id;

            if (payment.PaymentSubject.Label == Enum_PaymentSubject.CREDIT.ToString())
            {
                Merchant merchant = merchantId == null ? _context.Merchant.FirstOrDefault() : new Merchant() { ID = merchantId.Value };
                if (merchant == null)
                    return CreateErrorResult(Enum_Message.REQUIRED_PAYMENT_MERCHANT);
                else
                    merchantId = merchant.ID;
            }

            PaymentSubject subjectObj = _context.PaymentSubject.GetByLabel(payment.PaymentSubject.Label);
            Payment paymentObj = _context.Payment.CreatePayment(accountId, siteuserId, subjectObj.ID, payment.Price, merchantId, payment.Description);
            if (subjectObj.Label == Enum_PaymentSubject.ORDER.ToString())
            {
                _context.PaymentProductOrder.Insert(new PaymentProductOrder()
                {
                    PaymentId = paymentObj.ID,
                    OrderId = payment.OrderId,
                });
                _context.Save();
            }
            ViewPayment output = paymentObj.ToApi();
            return output != null ? CreateSuccessResult(output) : CreateErrorResult(Enum_Message.INVALID_PAYMENT_OBJECT);       
        }
    }
}
