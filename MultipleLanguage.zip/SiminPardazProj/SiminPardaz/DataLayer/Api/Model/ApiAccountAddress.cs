﻿using DataLayer.Base;
using DataLayer.Entities;
using DataLayer.ViewModels;
using DataLayer.Enumarables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Api.Model
{
    public class ApiAccountAddress : ApiResponse
    {
        public static ApiResult Get(UnitOfWork _context, int accountId)
        {
            List<ViewAccountAddress> list = _context.AccountAddress.GetAllByAccount(accountId).ToApi();
            return CreateSuccessResult(list);
        }

        //public static ApiResult GetById(UnitOfWork _context, int accountId, int id)
        //{
        //    ViewAccountAddress address = _context.AccountAddress.GetByAccount(accountId, id).ToApi();
        //    return CreateSuccessResult(address);
        //}

        public static ApiResult Post(UnitOfWork _context, int accountId, ViewAccountAddress address)
        {
            try
            {
                if (string.IsNullOrEmpty(address.NameFamily))
                    return CreateErrorResult(Enum_Message.REQUIRED_ACCOUNT_ADDRESS_NAMEFAMILY);
                else if (string.IsNullOrEmpty(address.Mobile))
                    return CreateErrorResult(Enum_Message.REQUIRED_ACCOUNT_ADDRESS_MOBILE);
                else if (address.StateId != -1 && (address.StateId == null || address.StateId == 0))
                    return CreateErrorResult(Enum_Message.REQUIRED_ACCOUNT_ADDRESS_STATE);
                else if (address.CityId != -1 && (address.CityId == null || address.CityId == 0))
                    return CreateErrorResult(Enum_Message.REQUIRED_ACCOUNT_ADDRESS_CITY);
                if (string.IsNullOrEmpty(address.AddressValue))
                    return CreateErrorResult(Enum_Message.REQUIRED_ACCOUNT_ADDRESS_VALUE);

                AccountAddress entity = new AccountAddress();
                entity.AccountId = accountId;
                FillAddressEntity(entity, address);
                _context.AccountAddress.Insert(entity);
                _context.AccountAddress.Save();

                _context = new UnitOfWork();
                return Get(_context, accountId);
            }
            catch(Exception ex)
            {
                return CreateExceptionResult(ex);
            }
        }

        public static ApiResult Put(UnitOfWork _context, int accountId, ViewAccountAddress address)
        {
            AccountAddress entity = _context.AccountAddress.GetById(address.Id);
            if (entity.AccountId != accountId)
                return CreateInvalidKeyResult();

            FillAddressEntity(entity, address);
            _context.AccountAddress.Update(entity);
            _context.Save();

            _context = new UnitOfWork();
            return Get(_context, accountId);
        }

        public static ApiResult Delete(UnitOfWork _context, int accountId, int addressId)
        {
            AccountAddress entity = _context.AccountAddress.GetById(addressId);
            if (entity.AccountId != accountId)
                return CreateInvalidKeyResult();
            
            if (entity.AccountOrder.Count > 0)
            {
                entity.AccountId = null;
                _context.AccountAddress.Update(entity);
            }
            else
            {
                _context.AccountAddress.Delete(entity);
            }
            _context.Save();

            return Get(_context, accountId);
        }

        private static void FillAddressEntity(AccountAddress entity, ViewAccountAddress address)
        {
            entity.AddressValue = address.AddressValue;
            entity.CityName = address.CityName.GetEnglish();
            entity.Latitude = address.Latitude.GetEnglish();
            entity.Longitude = address.Longitude.GetEnglish();
            entity.Mobile = address.Mobile.GetEnglish();
            entity.NameFamily = address.NameFamily.GetEnglish();
            entity.Phone = address.Phone.GetEnglish();
            entity.PostalCode = address.PostalCode.GetEnglish();
            entity.StateId = address.StateId == 0 || address.StateId == -1 ? default(int?) : address.StateId;
            entity.CityId = address.CityId == 0 || address.CityId == -1 ? default(int?) : address.CityId;
        }
    }
}
