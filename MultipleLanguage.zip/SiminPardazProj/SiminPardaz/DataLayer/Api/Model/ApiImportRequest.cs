﻿using DataLayer.Base;
using DataLayer.Entities;
using DataLayer.ViewModels;
using DataLayer.Enumarables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Api.Model
{
    public class ApiImportRequest : ApiResponse
    {
        public static ApiResult Post(UnitOfWork _context, ViewImportRequest request)
        {
            if (request == null)
                return CreateErrorResult(Enum_Message.INVALID_DATA);

            if (string.IsNullOrEmpty(request.EmailAddress))
                return CreateErrorResult(Enum_Message.REQUIRED_IMPORTATION_EMAIL);

            if (BaseSecurity.IsValidInput(request.EmailAddress, Enum_Validation.EMAIL) == false)
                return CreateErrorResult(Enum_Message.INVALID_IMPORTATION_EMAIL);

            if (request.CommercialStatusId == 0)
                return CreateErrorResult(Enum_Message.INVALID_IMMPORTATION_COMMERCIAL_STATUS);

            if (request.StoreStatusId == 0)
                return CreateErrorResult(Enum_Message.INVALID_IMMPORTATION_STORE_STATUS);

            ImportRequest entity = new ImportRequest() { 
                Address = request.Address,
                CompanyName = request.CompanyName,
                DeliveryTime = request.DeliveryTime,
                EmailAddress = request.EmailAddress,
                Family = request.Family,
                Mobile = request.Mobile,
                MoreDetail = request.MoreDetail,
                Name = request.Name,
                Phone = request.Phone,
                ImportRequestDate = DateTime.Now,
                CommercialStatusId = request.CommercialStatusId,
                StoreStatusId = request.StoreStatusId,
                RequestStatusID = _context.Code.GetIdByLabel(Enum_Code.NEW_IMPORTREQUEST_STATUS)
            };

            _context.ImportRequest.Insert(entity);
            _context.Save();

            return ApiResponse.CreateSuccessResult();
        }
    }
}
