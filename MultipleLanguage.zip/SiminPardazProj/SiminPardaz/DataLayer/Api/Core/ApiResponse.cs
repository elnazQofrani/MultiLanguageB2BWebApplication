﻿using DataLayer.Base;
using DataLayer.Enumarables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Api
{
    public class ApiResponse
    {
        public static ApiResult CreateSuccessResult(Enum_Message msg, object obj = null)
        {
            ApiResult result = new ApiResult()
            {
                Code = ApiResult.ResponseCode.Success,
                Message = BaseMessage.GetMessage(msg).Body
            };
            if (obj != null)
                result.Value = obj;
            //result.Value = obj.ToJson();
            return result;
        }

        public static ApiResult CreateSuccessResult(object obj = null, int? index = null, int? pageSize = null, int? resultSize = null, int? totalCount = null, DateTime? maxDatetime = null)
        {
            ApiResult result = new ApiResult()
            {
                Code = ApiResult.ResponseCode.Success,
                Message = BaseMessage.GetMessage(Enum_Message.SUCCESSFULL_API).Body,
                PageIndex = index,
                PageSize = pageSize,
                ResultSize = resultSize,
                TotalCount = totalCount,
                LastDatetime = maxDatetime
            };
            if (obj != null)
                result.Value = obj;
            return result;
        }

        public static ApiResult CreateInvalidKeyResult()
        {
            ApiResult result = new ApiResult()
            {
                Code = ApiResult.ResponseCode.InvalidKey,
                Message = BaseMessage.GetMessage(Enum_Message.INVALID_API_KEY).Body
            };
            return result;
        }

        public static ApiResult CreateErrorResult(Enum_Message message)
        {
            ApiResult result = new ApiResult()
            {
                Code = ApiResult.ResponseCode.Error,
                Message = BaseMessage.GetMessage(message).Body
            };
            return result;
        }

        public static ApiResult CreateExceptionResult(Exception e)
        {
            Exception innerException = e.InnerException;
            ApiResult result = new ApiResult()
            {
                Code = ApiResult.ResponseCode.Exception,
                Message = e.Message + (innerException != null ? innerException.Message : "")
            };
            return result;
        }
    }
}
