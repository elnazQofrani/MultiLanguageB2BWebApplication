﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DataLayer.Api
{
    public class ApiResult
    {
        public enum ResponseCode : byte
        {
            Exception,
            Success,
            InvalidKey,
            Error
        }

        public ResponseCode Code { get; set; }
        public string Message { get; set; }
        public int? PageIndex { get; set; }
        public int? PageSize { get; set; }
        public int? ResultSize { get; set; }
        public int? TotalCount { get; set; }
        public DateTime? LastDatetime { get; set; }
        public Object Value { get; set; }
    }
}