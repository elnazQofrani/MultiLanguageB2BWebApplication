﻿using DataLayer.Base;
using DataLayer.Entities;
using DataLayer.Enumarables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace DataLayer.Api
{
    public class ApiValidation
    {
        public static bool WebValidate(UnitOfWork _context)
        {
            string host = BaseUrl.CurrentUrl;
            string api_type = Enum_Code.SYSTEM_TYPE_API.ToString();
            string web_token = HttpContext.Current.Request.Headers["WEB_TOKEN"];
            return _context.WebsiteDomain.HasAnyByWebsiteTypeAndDomain(api_type, host, web_token);
        }
        
        public static AccountLog Validate(UnitOfWork _context)
        {
            string UNIQUE_ID = HttpContext.Current.Request.Headers["UNIQUE_ID"];
            string UNIQUE_KEY = HttpContext.Current.Request.Headers["UNIQUE_KEY"];
            
            if (UNIQUE_ID.IsGuid() && UNIQUE_KEY.IsGuid())
            {
                return _context.AccountLog.GetByKeyAndAccountUniqueId(UNIQUE_KEY.GetGuid(), UNIQUE_ID.GetGuid());
            }
            return null;
        }

        public static SiteUser SiteUserValidate(UnitOfWork _context)
        {
            string UNIQUE_ID = HttpContext.Current.Request.Headers["UNIQUE_SITEUSER_ID"];
            string UNIQUE_KEY = HttpContext.Current.Request.Headers["UNIQUE_SITEUSER_KEY"];

            if (UNIQUE_ID.IsGuid() && UNIQUE_KEY.IsGuid())
            {
                return _context.SiteUser.GetByUniqueCode(UNIQUE_KEY.GetGuid(), UNIQUE_ID.GetInteger());
            }
            return null;
        }
    }
}
