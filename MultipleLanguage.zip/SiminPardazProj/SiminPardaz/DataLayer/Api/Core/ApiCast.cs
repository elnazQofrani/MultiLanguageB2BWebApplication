﻿using DataLayer.Base;
using DataLayer.Entities;
using DataLayer.ViewModels;
using DataLayer.Enumarables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Api
{
    public static class ApiCast
    {
        public static List<ViewProductType> ToApi(this IEnumerable<ProductType> list)
        {
            List<ViewProductType> Output = new List<ViewProductType>();
            foreach (ProductType item in list)
            {
                Output.Add(item.ToApi());
            }
            return Output;
        }

        public static ViewProductType ToApi(this ProductType productType)
        {
            ViewProductType entity = new ViewProductType()
            {
                CreateDatetime = null,
                UpdateDatetime = null,
                Id = productType.ID.ToString(),
                Name = productType.Name,
                //CustomFields = item.ProductCustomField.ToList().ToApi(),
                ProductCategories = productType.ProductCategory.ToApi()
            };
            if (productType.PictureId != null)
                entity.Picture = new ViewPicture(productType.Picture);
            return entity;
        }

        public static List<ViewAccountOrder> ToApi(this List<AccountOrder> list)
        {
            List<ViewAccountOrder> Output = new List<ViewAccountOrder>();
            foreach (AccountOrder item in list)
            {
                Output.Add(new ViewAccountOrder(item));
            }
            return Output;
        }

        public static ViewAccountOrder ToApi(this AccountOrder order)
        {
            ViewAccountOrder entity = new ViewAccountOrder() {
                Id = order.ID,
                Status = new ViewCode() {
                    Label = order.Code.Label,
                    Name = order.Code.Name
                },
                Account = new ViewAccount() {
                    FullName = order.Account.FullName,
                    Email = order.Account.Email,
                    Mobile = order.Account.Mobile
                },
                Datetime = order.Datetime,
                Price = order.Price,
                PaymentType = new ViewPaymentType() {
                    Name = order.PaymentType.Name,
                    Label = order.PaymentType.Label
                } 
            };
            return entity;
        }

        public static List<ViewProductCustomField> ToApi(this List<ProductCustomField> list)
        {
            List<ViewProductCustomField> Output = new List<ViewProductCustomField>();
            foreach (ProductCustomField item in list)
            {
                ViewProductCustomField entity = new ViewProductCustomField() {
                    Id = item.ID,
                    IsRequired = item.IsRequired,
                    Name = item.Name,
                    Type = new ViewCode(item.Code),
                    Items = item.ProductCustomItem.ToApi()
                };
                Output.Add(entity);
            }
            return Output;
        }

        public static List<ViewProductCustomItem> ToApi(this IEnumerable<ProductCustomItem> list)
        {
            List<ViewProductCustomItem> Output = new List<ViewProductCustomItem>();
            foreach (ProductCustomItem item in list)
            {
                ViewProductCustomItem entity = new ViewProductCustomItem()
                {
                    Id = item.ID,
                    Value = item.Value
                };
                Output.Add(entity);
            }
            return Output;
        }

        public static ViewProductCategory ToApi(this ProductCategory productCategory, bool hasChilds = true)
        {
            ViewProductCategory entity = new ViewProductCategory()
            {
                Id = productCategory.ID.ToString(),
                Name = productCategory.Name
            };
            if (productCategory.PictureId != null)
                entity.Picture = new ViewPicture(productCategory.Picture, Enum_Code.SYSTEM_TYPE_PANEL);
            if (hasChilds)
                entity.SubCategories = productCategory.ProductSubCategory.ToApi();
            return entity;
        }

        public static List<ViewProductCategory> ToApi(this IEnumerable<ProductCategory> list, bool hasChilds = true)
        {
            List<ViewProductCategory> Output = new List<ViewProductCategory>();
            foreach (ProductCategory item in list)
            {   
                Output.Add(item.ToApi(hasChilds));
            }
            return Output;
        }

        public static List<ViewProductSubCategory> ToApi(this IEnumerable<ProductSubCategory> list)
        {
            List<ViewProductSubCategory> Output = new List<ViewProductSubCategory>();
            foreach (ProductSubCategory item in list)
            {
                Output.Add(new ViewProductSubCategory(item));
            }
            return Output;
        }

        public static ViewProductSubCategory ToApi(this ProductSubCategory productSubCategory)
        {
            ViewProductSubCategory entity = new ViewProductSubCategory()
            {
                Id = productSubCategory.ID.ToString(),
                Name = productSubCategory.Name
            };
            if (productSubCategory.PictureId != null)
                entity.Picture = new ViewPicture(productSubCategory.Picture, Enum_Code.SYSTEM_TYPE_PANEL);
            return entity;
        }

        public static List<ViewProductBrand> ToApi(this IEnumerable<ProductBrand> list)
        {
            List<ViewProductBrand> Output = new List<ViewProductBrand>();
            foreach (ProductBrand item in list)
            {
                Output.Add(new ViewProductBrand(item));
            }
            return Output;
        }

        public static ViewProductBrand ToApi(this ProductBrand productBrand)
        {
            ViewProductBrand entity = new ViewProductBrand()
            {
                Id = productBrand.ID.ToString(),
                Name = productBrand.Name,
                Active = productBrand.Active,
                Description = productBrand.Description,
              //  IsPublic = productBrand.IsPublic,
                Label = productBrand.Label,
              //  ThemeColor = productBrand.ThemeColor,
                ShowNumber = productBrand.ShowNumber.GetValueOrDefault()
            };
            return entity;
        }

        public static List<ViewProductCustomValue> ToApi(this IEnumerable<ProductCustomValue> list)
        {
            List<ViewProductCustomValue> Output = new List<ViewProductCustomValue>();
            foreach (ProductCustomValue item in list)
            {
                ViewProductCustomValue entity = new ViewProductCustomValue()
                {
                    Id = item.ID,
                    Field = new ViewProductCustomField() {
                        Type = new ViewCode() {
                            Label = item.ProductCustomField.Code.Label
                        },
                        Name = item.ProductCustomField.Name,
                        Label = item.ProductCustomField.Label
                    },
                    Value = item.Value
                };

                if (item.ItemId != null)
                {
                    entity.Item = new ViewProductCustomItem()
                    {
                        Value = item.ProductCustomItem.Value
                    };
                    entity.Value = item.ProductCustomItem.Value;
                }
                Output.Add(entity);
            }
            return Output;
        }

        public static List<ViewProduct> ToApi(this IEnumerable<Product> list)
        {
            List<ViewProduct> Output = new List<ViewProduct>();
            foreach (Product item in list)
            {
                string SimpleDescription = BaseHtml.ConvertToSimpleText(item.Description);
                Discount discount = item.GetDiscountObject();
                ViewProduct entity = new ViewProduct()
                {
                    CreateDatetime = null,
                    UpdateDatetime = null,
                    Description = SimpleDescription,
                    Id = item.ID.ToString(),
                    //LastPrice = item.LastPrice,
                    MinOrder = item.MinOrder,
                    Name = item.Name,
                    Price = item.Price.GetValueOrDefault(),
                    DiscountPrice = discount != null ? item.Price.GetValueOrDefault() - item.GetDiscountPrice(discount) : item.Price.GetValueOrDefault(),
                    DiscountPercent = discount != null ? discount.PercentValue : 0,
                    Document = new ViewDocument(item.WebsiteDocument),
                    ProductType = new ViewProductType(item.ProductType),
                    ProductCategory = new ViewProductCategory(item.ProductCategory),
                    ProductSubCategory = new ViewProductSubCategory(item.ProductSubCategory),
                    Items = item.ProductCustomValue.ToApi(),
                    Status = new ViewCode(item.Code),
                    Quantity = item.Quantity.GetValueOrDefault(),
                    Link = item.GetLink()
                };
                if (item.PictureId != null)
                    entity.Picture = new ViewPicture(item.Picture);

                entity.Pictures = new List<ViewProductPicture>();
                Output.Add(entity);
            }
            return Output;
        }

        public static ViewProduct ToApi(this Product product)
        {
            string SimpleDescription = BaseHtml.ConvertToSimpleText(product.Description);
            Discount discount = product.GetDiscountObject();
            ViewProduct entity = new ViewProduct()
            {
                CreateDatetime = null,
                UpdateDatetime = null,
                Description = SimpleDescription,
                Id = product.ID.ToString(),
              //  LastPrice = product.LastPrice,
                MinOrder = product.MinOrder,
                Name = product.Name,
                Price = product.Price.GetValueOrDefault(),
                DiscountPrice = discount != null ? (product.Price.GetValueOrDefault() - product.GetDiscountPrice(discount)) : product.Price.GetValueOrDefault(),
                DiscountPercent = discount != null ? discount.PercentValue : 0,
                Document = product.DocId != null ? new ViewDocument(product.WebsiteDocument) : null,
                ProductBrand = product.BrandId != null ? new ViewProductBrand(product.ProductBrand) : null,
                ProductType = product.ProductTypeId != null ? new ViewProductType(product.ProductType) : null,
                ProductCategory = product.ProductCategoryId != null ? new ViewProductCategory(product.ProductCategory) : null,
                ProductSubCategory = product.ProductSubCategoryId != null ? new ViewProductSubCategory(product.ProductSubCategory) : null,
                Picture = product.PictureId != null ? new ViewPicture(product.Picture) : null,
                Status = new ViewCode(product.Code),
                Items = product.ProductCustomValue.ToApi(),
                Quantity = product.Quantity.GetValueOrDefault(),
                Link = product.GetLink(),
                CodeValue = product.CodeValue
            };
            
            List<ViewProductPicture> listPicture = new List<ViewProductPicture>();
            if (product.ProductPicture.Count > 0)
            {
                if (product.PictureId != null && product.ProductPicture.Count == 0)
                    listPicture.Add(new ViewProductPicture(product.Picture));

                foreach (ProductPicture pic in product.ProductPicture)
                {
                    listPicture.Add(new ViewProductPicture(pic.Picture, pic.ColorId));
                }
            }
            entity.Pictures = listPicture;

            List<ViewColor> listColor = new List<ViewColor>();
            foreach (ProductColor color in product.ProductColor.OrderBy(p => p.Color.Name))
            {
                listColor.Add(new ViewColor {
                    Hex = color.Color.HexValue,
                    Name = color.Color.Name,
                    Id = color.ColorId
                });
            }
            entity.Colors = listColor;

            List<ViewSize> listSize = new List<ViewSize>();
            foreach (ProductSize size in product.ProductSize.OrderBy(p => p.Size.Name))
            {
                listSize.Add(new ViewSize() {
                    Id = size.SizeId,
                    Name = size.Size.Name
                });
            }
            entity.Sizes = listSize;

            return entity;
        }

        public static List<ViewCategory> ToApi(this IEnumerable<Category> list)
        {
            List<ViewCategory> Output = new List<ViewCategory>();
            foreach (Category item in list)
            {
                ViewCategory entity = new ViewCategory()
                {
                    Id = item.ID,
                    Label = item.Label,
                    Name = item.Name
                };
                Output.Add(entity);
            }
            return Output;
        }
        
        public static ViewPost ToApi(this Post post)
        {
            string SimpleDescription = BaseHtml.ConvertToSimpleText(post.Body);
            ViewPost entity = new ViewPost()
            {
                Active = post.Active,
                Body = SimpleDescription,
                Category = new ViewCategory(post.Category),
                Id = post.ID,
                Keywords = post.Keywords,
                Name = post.Name,
                Picture = new ViewPicture(post.Picture, Enum_Code.SYSTEM_TYPE_PANEL),
                Summary = post.Summary
            };
            return entity;
        }

        public static ViewPayment ToApi(this Payment payment)
        {
            if (payment != null)
            {
                ViewPayment entity = new ViewPayment()
                {
                    Id = payment.ID,
                    Url = BaseWebsite.ShopUrl + "payment/start/" + payment.ID
                };
                return entity;
            }
            else
                return null;
        }

        public static ViewAccount ToApi(this Account account)
        {
            if (account != null)
            {
                ViewAccount entity = new ViewAccount()
                {
                    Id = account.ID,
                    Address = account.Address,
                    Agent = account.Agent,
                    AgentPhone = account.AgentPhone,
                    Company = account.Company,
                    CompanyNo = account.CompanyNo,
                    Email = account.Email,
                    Password = "-",
                    FullName = account.FullName,
                    IsMale = account.IsMale.GetValueOrDefault(),
                    Job = account.Job,
                    Mobile = account.Mobile,
                    NationalCode = account.NationalCode,
                    Phone = account.Phone,
                    ReagentName = account.ReagentName,
                    UniqueId = account.UniqueId,
                    Description = account.Description,
                    ReagentCode = account.ReagentCode,
                    TrackingCode = account.TrackingCode,
                    BirthDate = account.BirthDate == null ? "" : account.BirthDate.ToPersian(),
                };
                
                return entity;
            }
            else
                return null;
        }

        public static List<ViewPost> ToApi(this IEnumerable<Post> list)
        {
            List<ViewPost> Output = new List<ViewPost>();
            foreach (Post post in list)
            {
                string SimpleDescription = BaseHtml.ConvertToSimpleText(post.Body);
                ViewPost entity = new ViewPost()
                {
                    Active = post.Active,
                    Body = SimpleDescription,
                    Category = new ViewCategory(post.Category),
                    Id = post.ID,
                    Keywords = post.Keywords,
                    Name = post.Name,
                    Picture = new ViewPicture(post.Picture, Enum_Code.SYSTEM_TYPE_PANEL),
                    Summary = post.Summary
                };
                Output.Add(entity);
            }
            return Output;
        }

        public static List<ViewAccountBasket> ToApi(this IEnumerable<AccountBasket> list)
        {
            List<ViewAccountBasket> Output = new List<ViewAccountBasket>();
            foreach (AccountBasket basket in list)
            {
                ViewAccountBasket entity = basket.ToApi();
                Output.Add(entity);
            }
            return Output;
        }

        public static ViewAccountBasket ToApi(this AccountBasket basket)
        {
            ViewAccountBasket entity = new ViewAccountBasket()
            {
                Id = basket.ID,
                Account = new ViewAccount()
                {
                    Id = basket.AccountId.GetValueOrDefault()
                },
                Count = basket.Count,
                Datetime = basket.Datetime,
                Price = basket.Price,
                Discount = basket.ProductDiscount,
                Product = basket.Product.ToApi(),
                Weight = basket.Weight,
                Active = basket.Active,
                DeActivateResult = basket.DeActivateResult
            };
            entity.Product.DiscountPercent = basket.Product.GetDiscountPercent();
            entity.Product.Items = basket.Product.ProductCustomValue.ToApi();
            if (basket.Product != null && basket.Product.PictureId != null)
                entity.Product.Picture = new ViewPicture(basket.Product.Picture);
            if (basket.ProductColorId != null)
            {
                ProductPicture picture = basket.Product.ProductPicture.FirstOrDefault(p => p.ColorId == basket.ProductColorId);
                entity.Picture = picture != null ? new ViewPicture(picture.Picture) : null;
            }
            if (basket.Color != null && basket.ProductColorId != null)
            {
                entity.Color = new ViewColor()
                {
                    Id = basket.Color.ID,
                    Name = basket.Color.Name,
                    Hex = basket.Color.HexValue
                };
            }
            if (basket.Size != null && basket.ProductSizeId != null)
            {
                entity.Size = new ViewSize()
                {
                    Id = basket.Size.ID,
                    Name = basket.Size.Name
                };
            }
            return entity;
        }

        public static List<ViewCity> ToApi(this IEnumerable<City> list)
        {
            List<ViewCity> Output = new List<ViewCity>();
            foreach (City city in list)
            {
                ViewCity entity = new ViewCity()
                {
                    Id = city.ID,
                    Name = city.Name
                };
                Output.Add(entity);
            }
            return Output;
        }

        public static List<ViewState> ToApi(this IEnumerable<State> list)
        {
            List<ViewState> Output = new List<ViewState>();
            foreach (State state in list)
            {
                ViewState entity = new ViewState()
                {
                    Id = state.ID,
                    Name = state.Name
                };
                Output.Add(entity);
            }
            return Output;
        }

        public static List<ViewCountry> ToApi(this IEnumerable<Country> list)
        {
            List<ViewCountry> Output = new List<ViewCountry>();
            foreach (Country country in list)
            {
                ViewCountry entity = new ViewCountry()
                {
                    Id = country.ID,
                    Name = country.Name
                };
                Output.Add(entity);
            }
            return Output;
        }

        public static List<ViewAccountAddress> ToApi(this IEnumerable<AccountAddress> list)
        {
            List<ViewAccountAddress> Output = new List<ViewAccountAddress>();
            foreach (AccountAddress address in list)
            {
                ViewAccountAddress entity = new ViewAccountAddress()
                {
                    Id = address.ID,
                    AddressValue = address.AddressValue,
                    Latitude = address.Latitude,
                    Longitude = address.Longitude,
                    NameFamily = address.NameFamily,
                    Mobile = address.Mobile,
                    PostalCode = address.PostalCode,
                    Phone = address.Phone,
                    CityName = address.CityName,
                    StateId = address.StateId,
                    CityId = address.CityId
                };
                if (address.StateId != null)
                    entity.State = new ViewState(address.State);
                if (address.CityId != null)
                    entity.City = new ViewCity(address.City);
                Output.Add(entity);
            }
            return Output;
        }

        public static List<ViewMerchant> ToApi(this IEnumerable<Merchant> list)
        {
            string panel_url = BaseWebsite.PanelUrl;
            List<ViewMerchant> Output = new List<ViewMerchant>();
            foreach (Merchant merchant in list)
            {
                ViewMerchant entity = new ViewMerchant()
                {
                    Id = merchant.ID,
                    Active = merchant.Active,
                    Bank = new ViewBank() {
                        Id = merchant.Bank.ID,
                        Name = merchant.Bank.Name,
                        Label = merchant.Bank.Label,
                        PictureUrl = BaseWebsite.ShopUrl + merchant.Bank.PictureUrl
                    }
                };
                Output.Add(entity);
            }
            return Output;
        }

        public static List<ViewSlider> ToApi(this IEnumerable<Slider> list)
        {
            string panel_url = BaseWebsite.PanelUrl;
            List<ViewSlider> Output = new List<ViewSlider>();
            foreach (Slider slider in list)
            {
                ViewSlider entity = new ViewSlider()
                {
                    Id = slider.ID,
                    Name = slider.Name,
                    Picture = new ViewPicture(slider.Picture, Enum_Code.SYSTEM_TYPE_PANEL),
                    url = slider.Picture.Url.Replace(Enum_Code.SYSTEM_TYPE_PANEL.ToString(), panel_url)
                };
                Output.Add(entity);
            }
            return Output;
        }

        public static ViewMenu ToApi(this Menu menu)
        {
            ViewMenu entity = new ViewMenu() {
                Id = menu.ID,
                Name = menu.Name,
                Link = menu.Link,
                Picture = menu.PictureId == null ? null : new ViewPicture(menu.Picture, Enum_Code.SYSTEM_TYPE_PANEL),
                Type = new ViewCode()
                {
                    Label = menu.Code.Label,
                    Name = menu.Name
                }
            };
            return entity;
        }

        public static List<ViewMenu> ToApi(this IEnumerable<Menu> list, bool hasChilds)
        {
            List<ViewMenu> Output = new List<ViewMenu>();
            foreach (Menu menu in list)
            {
                ViewMenu entity = menu.ToApi();
                if (hasChilds == true)
                {
                    entity.Childs = menu.Menu1.ToApi(hasChilds);
                }
                Output.Add(entity);
            }
            return Output;
        }

        public static List<ViewBanner> ToApi(this IEnumerable<Banner> list)
        {
            string panel_url = BaseWebsite.PanelUrl;
            List<ViewBanner> Output = new List<ViewBanner>();
            foreach (Banner banner in list)
            {
                ViewBanner entity = new ViewBanner()
                {
                    Id = banner.ID,
                    Name = banner.Name,
                    Picture = new ViewPicture(banner.Picture, Enum_Code.SYSTEM_TYPE_PANEL),
                    Category = new ViewCategory(banner.Category),
                    ShowNumber = banner.ShowNumber.GetValueOrDefault(),
                    Summary = banner.Summary,
                    Url  = banner.Url                    
                };
                Output.Add(entity);
            }
            return Output;
        }

        public static List<ViewProductComment> ToApi(this IEnumerable<ProductComment> list)
        {
            string panel_url = BaseWebsite.PanelUrl;
            List<ViewProductComment> Output = new List<ViewProductComment>();
            foreach (ProductComment comment in list)
            {
                ViewProductComment entity = new ViewProductComment()
                {
                    Id = comment.ID,
                    Approved = comment.Approved,
                    Account = new ViewAccount() {
                        FullName = comment.Account.FullName
                    },
                    Body = comment.Body,
                    Datetime = comment.Datetime,
                    EmailAddress = comment.EmailAddress,
                    NameFamily = comment.NameFamily,
                    AnswerDatetime = comment.AnswerDatetime,
                    AnswerString = comment.AnswerString,
                    Product = new ViewProduct() {
                        Id = comment.ProductId.ToString()
                    }
                };
                Output.Add(entity);
            }
            return Output;
        }

        public static List<ViewSendType> ToApi(this IEnumerable<SendType> list)
        {
            List<ViewSendType> Output = new List<ViewSendType>();
            foreach (SendType sendType in list)
            {
                Output.Add(new ViewSendType(sendType));
            }
            return Output;
        }

        public static List<ViewProductLike> ToApi(this IEnumerable<ProductLike> list)
        {
            List<ViewProductLike> listOutput = new List<ViewProductLike>();
            foreach (ProductLike item in list)
            {
                Product product = item.Product;
                listOutput.Add(new ViewProductLike() {
                    Id = item.ID,
                    Product = item.Product.ToApi()
                });
            }
            return listOutput;
        }

        public static ViewCode ToApi(this Code code)
        {
            ViewCode entity = new ViewCode()
            {
                Id = code.ID,
                Name = code.Name,
                Label = code.Label
            };
            return entity;
        }

        public static ViewSiteUser ToApi(this SiteUser user)
        {
            return new ViewSiteUser(user);
        }
    }
}
