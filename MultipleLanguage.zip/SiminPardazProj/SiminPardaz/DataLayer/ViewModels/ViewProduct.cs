﻿using DataLayer.Base;
using DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.ViewModels
{
    public class ViewProduct
    {
        public string Id { get; set; }
        public string RowId { get; set; }
        public string Name { get; set; }
        public string CodeValue { get; set; }
        public string Summary { get; set; }
        public string Description { get; set; }
        public DateTime? CreateDatetime { get; set; }
        public DateTime? UpdateDatetime { get; set; }
        public ViewProductSubCategory ProductSubCategory { get; set; }
        public ViewProductCategory ProductCategory { get; set; }
        public ViewProductType ProductType { get; set; }
        public ViewProductBrand ProductBrand { get; set; }
        public List<ViewProductCustomValue> Items { get; set; }
        public int LikesCount { get; set; }
        public ViewCode Status { get; set; }
        public int? LastPrice { get; set; }
        public int Price { get; set; }
        public int? Weight { get; set; }
        public int Quantity { get; set; }
        public int DiscountPrice { get; set; }
        public int? DiscountPercent { get; set; }
        public int? MinOrder { get; set; }
        public ViewPicture Picture { get; set; }
        public ViewDocument Document { get; set; }
        public ViewUnit Unit { get; set; }
        public List<ViewProductPicture> Pictures { get; set; }
        public List<ViewColor> Colors { get; set; }
        public List<ViewSize> Sizes { get; set; }
        public bool Active { get; set; }
        public string Link { get; set; }

        public ViewProduct() { }

        public ViewProduct(Product product)
        {
            if (product != null)
            {
                this.Id = product.ID.ToString();
                this.Name = product.Name;
                this.Price = product.Price == null ? 0 : product.Price.Value;
                this.ProductType = new ViewProductType(product.ProductType);
                this.ProductBrand = new ViewProductBrand(product.ProductBrand);
                this.ProductCategory = new ViewProductCategory(product.ProductCategory);
                this.ProductSubCategory = new ViewProductSubCategory(product.ProductSubCategory);
                this.Picture = product.PictureId != null ? new ViewPicture(product.Picture) : null;
                this.Unit = product.UnitId != null ? new ViewUnit(product.Unit) : null;
                this.Link = product.GetLink();
                this.CodeValue = product.CodeValue;
            }
        }

        public ViewProduct(Product product, int index, string MaxZero)
        {
            this.Id = product.ID.ToString();
            this.RowId = Persia.Number.ConvertToPersian((index + 1).ToString(MaxZero));
            this.Name = product.Name;
            this.Status = new ViewCode(product.Code);
            this.ProductType = new ViewProductType(product.ProductType);
            this.ProductCategory = new ViewProductCategory(product.ProductCategory);
            this.ProductSubCategory = new ViewProductSubCategory(product.ProductSubCategory);
            this.LikesCount = product.ProductLike.Count;
        }
    }
}
