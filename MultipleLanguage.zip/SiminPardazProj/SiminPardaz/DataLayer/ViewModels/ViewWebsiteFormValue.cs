﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.ViewModels
{
    public class ViewWebsiteFormValue
    {
        public int? ColumnId { get; set; }
        public string ColumnName { get; set; }
        public string Value { get; set; }
    }
}
