﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.ViewModels
{
    public class ViewAccountBasket
    {
        public int Id { get; set; }
        public ViewAccount Account { get; set; }
        public ViewProduct Product { get; set; }
        public ViewColor Color { get; set; }
        public ViewSize Size { get; set; }
        public ViewPicture Picture { get; set; }
        public int? ColorId { get; set; }
        public int? SizeId { get; set; }
        public int Count { get; set; }
        public int Price { get; set; }
        public int Discount { get; set; }
        public DateTime Datetime { get; set; }
        public int? Weight { get; set; }
        public bool Active { get; set; }
        public string DeActivateResult { get; set; }
        public List<ViewAccountBasketDetail> Details { get; set; }

        public ViewAccountBasket() { }
    }
}
