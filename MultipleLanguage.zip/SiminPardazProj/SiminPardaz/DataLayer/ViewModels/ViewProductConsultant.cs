﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.ViewModels
{
    public class ViewProductConsultant
    {
        public int Id { get; set; }
        public ViewProduct Product { get; set; }
        public ViewAccount Account { get; set; }
        public string Body { get; set; }
        public string AnswerString { get; set; }
        public bool? Approved { get; set; }
        public DateTime AnswerDatetime { get; set; }
        public DateTime Datetime { get; set; }
    }
}
