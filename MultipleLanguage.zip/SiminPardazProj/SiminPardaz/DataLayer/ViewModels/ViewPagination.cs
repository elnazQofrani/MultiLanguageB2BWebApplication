﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.ViewModels
{
    public class ViewPagination<TEntity> where TEntity : class
    {
        public int PageIndex { get; set; }
        public int PageSize { get; set; }
        public int TotalCount { get; set; }
        public List<TEntity> Results { get; set; }

        public int StartIndex {
            get {
                return PageIndex > 4 ? PageIndex - 4 : 1;
            }
        }

        public int EndIndex {
            get
            {
                return (TotalCount / PageSize) + ((TotalCount % PageSize) > 0 ? 1 : 0);
            }
        }
    }
}



/*
int CurrentIndex = index.IsInteger() ? index.GetInteger() : 1;
int PageSize = pageSize.IsInteger() ? pageSize.GetInteger() : 10;
int StartIndex = CurrentIndex > 4 ? CurrentIndex - 4 : 1;
int EndIndex = (TotalCount / PageSize);
int Mod = (TotalCount % PageSize);
*/