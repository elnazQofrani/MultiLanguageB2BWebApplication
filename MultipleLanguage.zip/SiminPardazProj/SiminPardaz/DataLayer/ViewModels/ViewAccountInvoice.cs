﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.ViewModels
{
   public class ViewAccountInvoice
    {

        public int WholePrice { get; set; }
        public int WholeCount { get; set; }
        public int AccountID { get; set; }
        public List<ViewAccountInvoiceProduct> AccountInvoiceProduct { get; set; }

    }

   public class ViewAccountInvoiceProduct
    {

        public int ProductID { get; set; }
        public int Count { get; set; }
        public int ProductDiscount { get; set; }
        public int ProductPrice { get; set; }
        public int Price { get; set; }
    }
}
