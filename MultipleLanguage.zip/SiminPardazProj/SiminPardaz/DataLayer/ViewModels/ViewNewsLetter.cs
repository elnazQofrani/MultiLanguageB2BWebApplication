﻿using DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.ViewModels
{
   public class ViewNewsLetter
    {

        public int Id { get; set; }
        public string RowId { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public DateTime? DateTime { get; set; }


        public ViewNewsLetter()
        {

        }



        public ViewNewsLetter(Newsletter group, int index, string MaxZero)
        {
            if (group != null)
            {
                this.Id = group.ID;
                this.RowId = Persia.Number.ConvertToPersian((index + 1).ToString(MaxZero));
                this.Mobile = group.Mobile;
                this.Email = group.Email;
                this.DateTime = group.Datetime;
                // this.ItemCount = group.NewsletterItem.Count;
            }
        }

    }
}
