﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.ViewModels
{
    public class ViewProductQuestion
    {
        public int Id { get; set; }
        public ViewProduct Product { get; set; }
        public ViewAccount Account { get; set; }
        public string Body { get; set; }
        public bool? Approved { get; set; }
        public DateTime Datetime { get; set; }
    }
}
