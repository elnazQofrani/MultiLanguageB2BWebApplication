﻿using DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.ViewModels
{
    public class ViewAccountOrder
    {
        public int Id { get; set; }
        public string RowId { get; set; }
        public ViewAccount Account { get; set; }
        public ViewPaymentType PaymentType { get; set; }
        public ViewAccountAddress AccountAddress { get; set; }
        public ViewCode Status { get; set; }
        public ViewRebate Rebate { get; set; }
        public ViewSendType SendType { get; set; }
        public int? SendPrice { get; set; }
        public int Price { get; set; }
        public int ProductCount { get; set; }
        public int CommentCount { get; set; }
        public string PostalCode { get; set; }
        public string Description { get; set; }
        public string CustomerDescription { get; set; }
        public DateTime Datetime { get; set; }

        public ViewAccountOrder() { }

        public ViewAccountOrder(AccountOrder order)
        {
            this.Id = order.ID;
            this.Account = new ViewAccount(order.Account);
            this.PaymentType = new ViewPaymentType(order.PaymentType);
            this.AccountAddress = new ViewAccountAddress(order.AccountAddress);
            this.Status = new ViewCode(order.Code);
            this.Rebate = order.RebateId != null ? new ViewRebate(order.Rebate) : null;
            this.SendType = order.SendTypeId != null ? new ViewSendType(order.SendType) : null;
            this.Price = order.Price;
            this.Datetime = order.Datetime;
            this.PostalCode = order.PostalCode;
            this.Description = order.Description;
            this.CustomerDescription = order.CustomerDescription;
            this.ProductCount = order.AccountOrderProduct.Sum(s => s.Count);
            this.SendPrice = order.SendPrice;
        }

        public ViewAccountOrder(AccountOrder order, int index, string MaxZero)
        {
            this.Id = order.ID;
            this.RowId = Persia.Number.ConvertToPersian((index + 1).ToString(MaxZero));
            this.Account = new ViewAccount(order.Account);
            this.PaymentType = new ViewPaymentType(order.PaymentType);
            this.AccountAddress = new ViewAccountAddress(order.AccountAddress);
            this.Status = new ViewCode(order.Code);
            this.Price = order.Price;
            this.Datetime = order.Datetime;
            int ProductCount = 0;
            this.CommentCount = order.AccountOrderComment.Count;
            foreach (AccountOrderProduct item in order.AccountOrderProduct)
            {
                ProductCount = ProductCount + item.Count;
            }
            this.ProductCount = ProductCount;
            this.SendPrice = order.SendPrice;
        }
    }
}
