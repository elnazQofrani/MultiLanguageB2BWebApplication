﻿using DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.ViewModels
{
    public class ViewProductSubCategory
    {
        public string Id { get; set; }
        public string RowId { get; set; }
        public ViewProductCategory Category { get; set; }
        public string Name { get; set; }
        public ViewPicture Picture { get; set; }
        public DateTime? SyncDatetime { get; set; }
        public DateTime? CreateDatetime { get; set; }
        public DateTime? UpdateDatetime { get; set; }

        public ViewProductSubCategory() { }

        public ViewProductSubCategory(ProductSubCategory subcategory)
        {
            if (subcategory != null)
            {
                this.Id = subcategory.ID.ToString();
                this.Name = subcategory.Name;
                this.Category = new ViewProductCategory(subcategory.ProductCategory);
            }
        }

        public ViewProductSubCategory(ProductSubCategory subcategory, int index, string MaxZero)
        {
            this.Id = subcategory.ID.ToString();
            this.RowId = Persia.Number.ConvertToPersian((index + 1).ToString(MaxZero));
            this.Name = subcategory.Name;
            this.Category = new ViewProductCategory(subcategory.ProductCategory);
        }
    }
}
