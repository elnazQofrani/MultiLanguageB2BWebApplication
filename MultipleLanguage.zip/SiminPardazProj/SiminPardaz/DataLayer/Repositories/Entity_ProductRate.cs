﻿using DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Repositories
{
    public class Entity_ProductRate : BaseRepository<ProductRate>
    {
        private DatabaseEntities _context;
        public Entity_ProductRate(DatabaseEntities context) : base(context)
        {
            _context = context;
        }

        public void UpsertProductRating(int productId, int accountId, int rateValue)
        {
            ProductRate rate = _context.ProductRate.FirstOrDefault(p =>
                p.ProductId == productId &&
                p.AccountId == accountId
            );
            if (rate != null)
            {
                rate.RateValue = rateValue;
                rate.Datetime = DateTime.Now;
                Update(rate);
            }
            else
            {
                rate = new ProductRate()
                {
                    AccountId = accountId,
                    ProductId = productId,
                    RateValue = rateValue,
                    Datetime = DateTime.Now
                };
                Insert(rate);
            }
            Save();
        }
    }
}
