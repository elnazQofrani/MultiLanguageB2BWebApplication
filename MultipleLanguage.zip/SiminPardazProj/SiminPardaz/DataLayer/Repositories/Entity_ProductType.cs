﻿using Binbin.Linq;
using DataLayer.Base;
using DataLayer.Entities;
using DataLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Repositories
{
    public class Entity_ProductType : BaseRepository<ProductType>
    {
        private DatabaseEntities _context;
        public Entity_ProductType(DatabaseEntities context) : base(context)
        {
            _context = context;
        }

        public ProductType GetActiveById(int Id)
        {
            return _context.ProductType.FirstOrDefault(p => p.ID == Id && p.Active);
        }

        public List<ProductType> Search(
            string Id = null,
            int? notId = null, 
            int? index = 1, 
            int? pageSize = null, 
            string name = null)
        {
            pageSize = pageSize == null ? 10 : pageSize;
            index = index == null ? 1 : index;
            int skipValue = pageSize.Value * (index.Value - 1);
            int pageValue = pageSize.Value;
            var MyQuery = GetSearchQuery(Id: Id, notId: notId, name: name);

            List<ProductType> results = _context
                .ProductType
                .OrderBy(p => p.ShowNumber)
                .ThenBy(p => p.ID)
                .Where(MyQuery)
                .Skip(skipValue)
                .Take(pageValue)
                .ToList();

            return results;
        }

        public int SearchCount(string Id = null, int? shopId = null, int? notId = null, string name = null)
        {
            var MyQuery = GetSearchQuery(Id: Id, notId: notId, name: name);
            return _context.ProductType.Count(MyQuery);
        }
        
        private Expression<Func<ProductType, bool>> GetSearchQuery(string Id = null, int? notId = null, string name = null)
        {
            var MyQuery = PredicateBuilder.True<ProductType>();

            if (Id != null)
            {
                var QueryStr = PredicateBuilder.False<ProductType>();
                string[] Split = Id.Split('-');
                foreach (var item in Split)
                {
                    int itemId = item.GetInteger();
                    if (itemId != 0)
                    {
                        QueryStr = QueryStr.Or(p =>
                            p.ID == itemId
                        );
                    }
                }
                MyQuery = MyQuery.And(QueryStr);
            }
            
            if (notId != null)
                MyQuery = MyQuery.And(p => p.ID != notId);
            if (name != null)
                MyQuery = MyQuery.And(p => p.Name.Contains(name));

            MyQuery = MyQuery.And(p => p.Active);

            return MyQuery;
        }

        public ProductType GetByLabel(string label)
        {
            return _context.ProductType.FirstOrDefault(p => p.Label == label);
        }
    }
}
