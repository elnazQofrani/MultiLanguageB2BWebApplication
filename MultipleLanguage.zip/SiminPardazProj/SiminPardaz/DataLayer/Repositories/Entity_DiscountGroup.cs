﻿using Binbin.Linq;
using DataLayer.Entities;
using DataLayer.Enumarables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Repositories
{
    public class Entity_DiscountGroup : BaseRepository<DiscountGroup>
    {
        private DatabaseEntities _context;

        public Entity_DiscountGroup(DatabaseEntities context) : base(context)
        {
            _context = context;
        }

        public List<DiscountGroup> Search(
            Enum_Code type = Enum_Code.DISCOUNT_TYPE_NONE,
            string label = null,
            int? notId = null,
            int? index = null,
            int? pageSize = null)
        {
            var MyQuery = PredicateBuilder.True<DiscountGroup>();
            index = index == null ? 1 : index;
            pageSize = pageSize == null ? 10 : pageSize;

            int skipValue = pageSize.Value * (index.Value - 1);
            int pageValue = pageSize.Value;
            string typeString = type.ToString();

            if (notId != null && notId != 0)
                MyQuery = MyQuery.And(p => p.ID != notId);
            if (label != null)
                MyQuery = MyQuery.And(p => p.Label == label);
            if (type != Enum_Code.DISCOUNT_TYPE_NONE)
                MyQuery = MyQuery.And(p => p.Code.Label == typeString);

            return _context
                .DiscountGroup
                .OrderBy(p => p.ID)
                .Where(MyQuery)
                .Skip(skipValue)
                .Take(pageValue)
                .ToList();
        }

        public DiscountGroup GetByLabel(string label)
        {
            return _context.DiscountGroup.FirstOrDefault(p => p.Label == label);
        }
    }
}
