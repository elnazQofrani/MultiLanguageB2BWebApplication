﻿using DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Repositories
{
    public class Entity_WebsiteContactForm : BaseRepository<WebsiteContactForm>
    {
        private DatabaseEntities _context;
        public Entity_WebsiteContactForm(DatabaseEntities context) : base(context)
        {
            _context = context;
        }


        public List<WebsiteContactForm> GetAllByPaging(int pageSize = 10, int index = 1)
        {
            int skipValue = pageSize * (index - 1);
            int pageValue = pageSize;
            return _context
                    .WebsiteContactForm
                    .OrderBy(p => p.ID)
                    .Skip(skipValue)
                    .Take(pageValue)
                    .ToList();
        }
    }
}
