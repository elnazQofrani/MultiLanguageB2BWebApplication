﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer.Entities;

namespace DataLayer.Repositories
{
    public class Entity_NewsLetter : BaseRepository<Newsletter>
    {
        private DatabaseEntities _context;
        public Entity_NewsLetter(DatabaseEntities context) : base(context)
        {
            _context = context;
        }

        public List<Newsletter> GetByGroupId(int id)
        {
            return _context.Newsletter.Where(x => x.GroupId == id).ToList();
        }

        public bool IsRepeated(Newsletter newsletter)
        {
            return _context.Newsletter.Any(p => p.Email == newsletter.Email);
        }
    }
}
