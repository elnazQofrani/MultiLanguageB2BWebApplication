﻿using DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Repositories
{
  public  class Entity_CollaborationRequest: BaseRepository<CollaborationRequest>
    {

        private DatabaseEntities _context;
        public Entity_CollaborationRequest(DatabaseEntities context) : base(context)
        {
            _context = context;
        }


        public List<CollaborationRequest> GetAllByPaging(int pageSize = 10, int index = 1)
        {
    
            int skipValue = pageSize * (index - 1);
            int pageValue = pageSize;
            return _context
                    .CollaborationRequest
                    .OrderBy(p => p.ID)
                    
                    .Skip(skipValue)
                    .Take(pageValue)
                    .ToList();
        }

    }
}
