﻿using Binbin.Linq;
using DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Repositories
{
    public class Entity_SendType : BaseRepository<SendType>
    {
        private DatabaseEntities _context;
        public Entity_SendType(DatabaseEntities context) : base(context)
        {
            _context = context;
        }

        public List<SendType> GetAllActive()
        {
            return _context.SendType.Where(p =>
                p.Active == true
            ).ToList();
        }

        public List<SendType> Search(int? pageSize = 10, int? index = 1)
        {
            var MyQuery = PredicateBuilder.True<SendType>();
            MyQuery = MyQuery.And(p => p.Active);
            int skipValue = pageSize.Value * (index.Value - 1);
            int pageValue = pageSize.Value;

            return _context
                .SendType
                .OrderBy(p => p.ID)
                .Where(MyQuery)
                .Skip(skipValue)
                .Take(pageValue)
                .ToList();
        }

        public SendType GetByLabel(string label)
        {
            return _context.SendType.FirstOrDefault(p => p.Label == label && p.Active);
        }
    }
}
