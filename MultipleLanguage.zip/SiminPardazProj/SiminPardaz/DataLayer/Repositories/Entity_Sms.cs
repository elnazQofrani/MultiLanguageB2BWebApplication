﻿using DataLayer.Base;
using DataLayer.Entities;
using DataLayer.Enumarables;
using DataLayer.ServiceReference1;
using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Repositories
{
    public class Entity_Sms : BaseRepository<Sms>
    {
        private DatabaseEntities _context;

        public Entity_Sms(DatabaseEntities context) : base(context)
        {
            _context = context;
        }

        public void SaveNewSms(string receiver, Enum_SmsType type, string body, string token1 = "", string token2 = "", string token3 = "")
        {
            try
            {
                string typeString = type.ToString().ToUpper();
                SmsType smsType = _context.SmsType.FirstOrDefault(p => p.Label == typeString);
                int? smsTypeId = smsType == null ? default(int?) : smsType.ID;

                SmsNumber number = null;

                if (smsTypeId == null)
                {
                    number = _context.SmsNumber.FirstOrDefault();
                }
                else
                {
                    number = _context.SmsNumber.FirstOrDefault(p => p.SmsSetting.Any(s => s.SmsTypeId == smsTypeId));
                }

                Sms message = new Sms() {
                    Body = body,
                    TypeId = smsTypeId,
                    CreateDatetime = DateTime.Now,
                    LastSendDatetime = DateTime.Now,
                    Receive = receiver,
                    Sender = number?.Number,
                    Token1 = token1.Replace(" ", "_"),
                    Token2 = token2.Replace(" ", "_"),
                    Token3 = token3.Replace(" ", "_"),
                    IsSend = false,
                };
                Insert(message);
            }
            catch (Exception) { }
        }

        public void SendCenter()
        {
         List<Sms> list = _context.Sms.Where(p => p.IsSend == false).Take(100).ToList();
          
            if (list.Count > 0)
            {
                foreach (Sms item in list)
                {
                    item.IsSend = true;
                }
                _context.SaveChanges();
                foreach (var item in list)
                {
                    SendNiazPardaz(item);
                }
            }
        }

        private void SendNiazPardaz(Sms sms )
        {
            var client = new RestClient("https://login.niazpardaz.ir/SMSInOutBox/SendSms/");
            var request = new RestRequest("", Method.GET);
            request.Parameters.Clear();
            request.AddQueryParameter("userName", "c.09125434366");
            request.AddQueryParameter("password", "79701");
            request.AddQueryParameter("text", sms.Body);
            request.AddQueryParameter("from", "50005708623520");
            request.AddQueryParameter("to", sms.Receive);
            IRestResponse response = client.Execute(request);
            dynamic result = JsonConvert.DeserializeObject(response.Content);
            sms.StatusText = result.statustext;
            sms.Cost = result.cost;
            sms.MessageId = result.messageid;
            // var client = new RestClient("https://login.niazpardaz.ir/SMSInOutBox/SendSms?username=c.09125434366&password=79701&from=50005708623520&to=09013495028&text=%D8%B3%D9%84%D8%A7%D9%85");
        }

        private void SendSingleKavenegar(SmsProvider provider, SmsNumber number, SmsSetting setting, Sms sms)
        {
            try
            {
                var client = new RestClient(provider.ServiceUrl + number.ApiKey + "/sms/send.json");
                var request = new RestRequest("", Method.GET);
                request.Parameters.Clear();
                request.AddQueryParameter("receptor", sms.Receive.GetEnglish());
                request.AddQueryParameter("message", sms.Body);
                request.AddQueryParameter("sender", sms.Sender);
                request.AddQueryParameter("localid", sms.ID.ToString());
                IRestResponse response = client.Execute(request);
                dynamic result = JsonConvert.DeserializeObject(response.Content);
                sms.StatusText = result.statustext;
                sms.Cost = result.cost;
                sms.MessageId = result.messageid;
            }
            catch (Exception) { }
        }

        private void SendSingleKavenegarLookup(SmsProvider provider, SmsNumber number, SmsSetting setting, Sms sms)
        {
            try
            {
                string restClient = provider.ServiceUrl + number.ApiKey + "/verify/lookup.json";
                var client = new RestClient(restClient);
                string template = setting.SmsType.Label.Replace("_", "");
                var request = new RestRequest("", Method.GET);
                request.Parameters.Clear();
                request.AddQueryParameter("receptor", sms.Receive.GetEnglish());
                request.AddQueryParameter("template", template);
                request.AddQueryParameter("token", sms.Token1);
                request.AddQueryParameter("token2", sms.Token2);
                request.AddQueryParameter("token3", sms.Token3);
                IRestResponse response = client.Execute(request);
                dynamic result = JsonConvert.DeserializeObject(response.Content);
                sms.StatusText = result.statustext;
                sms.Cost = result.cost;
                sms.MessageId = result.messageid;
            }
            catch (Exception) { }
        }       
    }
}
