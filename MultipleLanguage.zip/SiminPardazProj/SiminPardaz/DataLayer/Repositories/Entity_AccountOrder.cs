﻿using Binbin.Linq;
using DataLayer.Entities;
using DataLayer.Enumarables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Repositories
{
    public class Entity_AccountOrder : BaseRepository<AccountOrder>
    {
        private DatabaseEntities _context;
        public Entity_AccountOrder(DatabaseEntities context) : base(context)
        {
            _context = context;
        }

        public int SearchCount(
            int? accountId = null,
            int? merchantId = null,
            string refId = null,
            int[] statusId = null,
            List<string> statusStr = null,
            string customer = null,
            string product = null,
            int? fromorderid = null,
            int? toorderid = null,
            DateTime? fromDatetime = null,
            DateTime? toDatetime = null,
            string rebate = null)
        {
            var MyQuery = GetSearchQuery(
                accountId: accountId,
                merchantId: merchantId,
                customer: customer,
                fromDatetime: fromDatetime,
                fromorderid: fromorderid,
                rebate: rebate,
                refId: refId,
                statusId: statusId,
                statusStr: statusStr,
                toDatetime: toDatetime,
                toorderid: toorderid);
            return _context.AccountOrder.Count(MyQuery);
        }

        public List<AccountOrder> Search(
            int? index = 1, 
            int? pageSize = null, 
            int? accountId = null, 
            int? merchantId = null,
            string refId = null, 
            int[] statusId = null,
            List<string> statusStr = null,
            string customer = null,
            string product = null,
            int? fromorderid = null,
            int? toorderid = null,
            DateTime? fromDatetime = null,
            DateTime? toDatetime = null,
            string rebate = null)
        {
            var MyQuery = GetSearchQuery(
                accountId: accountId,
                merchantId: merchantId,
                customer: customer,
                fromDatetime: fromDatetime,
                fromorderid: fromorderid,
                product: product,
                rebate: rebate,
                refId: refId,
                statusId: statusId,
                statusStr: statusStr,
                toDatetime: toDatetime,
                toorderid: toorderid);

            pageSize = pageSize == null ? 10 : pageSize;
            index = index == null ? 1 : index;
            int skipValue = pageSize.Value * (index.Value - 1);
            int pageValue = pageSize.Value;

            List<AccountOrder> results = _context
                .AccountOrder
                .OrderByDescending(p => p.ID)
                .Where(MyQuery)
                .Skip(skipValue)
                .Take(pageValue)
                .ToList();

            return results;
        }

        private Expression<Func<AccountOrder, bool>> GetSearchQuery(
            int? accountId = null,
            string refId = null,
            int[] statusId = null,
            List<string> statusStr = null,
            string customer = null,
            string product = null,
            int? fromorderid = null,
            int? toorderid = null,
            int? merchantId = null,
            DateTime? fromDatetime = null,
            DateTime? toDatetime = null,
            string rebate = null)
        {
            List<AccountOrder> results = new List<AccountOrder>();
            var MyQuery = PredicateBuilder.True<AccountOrder>();
            
            if (accountId != null)
                MyQuery = MyQuery.And(p => p.AccountId == accountId);

            if (string.IsNullOrEmpty(refId) == false)
                MyQuery = MyQuery.And(p => p.PaymentProductOrder.Any(s => s.Payment.RefNumber == refId));

            if (statusId != null)
            {
                var QueryStr = PredicateBuilder.False<AccountOrder>();
                foreach (var item in statusId)
                {
                    int itemId = item;
                    if (itemId != 0)
                    {
                        QueryStr = QueryStr.Or(p =>
                            p.StatusId == itemId
                        );
                    }
                }
                MyQuery = MyQuery.And(QueryStr);
            }

            if (statusStr != null)
            {
                var QueryStr = PredicateBuilder.False<AccountOrder>();
                foreach (var item in statusStr)
                {
                    if (string.IsNullOrEmpty(item) == false)
                    {
                        QueryStr = QueryStr.Or(p => p.Code.Label == item);
                    }
                }
                MyQuery = MyQuery.And(QueryStr);
            }

            if (fromorderid != null)
                MyQuery = MyQuery.And(p => p.ID >= fromorderid);

            if (toorderid != null)
                MyQuery = MyQuery.And(p => p.ID <= toorderid);

            if (rebate != null)
                MyQuery = MyQuery.And(p => p.Rebate.CodeValue == rebate);
            
            if (merchantId != null && merchantId != 0)
            {
                string payment_success_status = Enum_Code.PAYMENT_STATUS_SUCCESSFUL.ToString();
                string payment_service_failed_status = Enum_Code.PAYMENT_STATUS_SERVICE_FAILED.ToString();
                MyQuery = MyQuery.And(p => p.PaymentProductOrder.Any(q => 
                    q.Payment.MerchantId == merchantId &&
                    (
                        q.Payment.Code.Label == payment_success_status ||
                        q.Payment.Code.Label == payment_service_failed_status
                    )
                    ));
            }                

            if (string.IsNullOrEmpty(product) == false)
                MyQuery = MyQuery.And(p => 
                    p.AccountOrderProduct.Any(q => 
                        q.Product.Name.Contains(product) ||
                        q.Product.Summary.Contains(product) ||
                        q.Product.ProductType.Name.Contains(product) ||
                        q.Product.ProductCategory.Name.Contains(product) ||
                        q.Product.ProductSubCategory.Name.Contains(product)));

            if (string.IsNullOrEmpty(customer) == false)
            {
                var nameQuery = PredicateBuilder.True<AccountOrder>();
                string[] nameSplit = customer.Split(' ');
                foreach (var item in nameSplit)
                {
                    nameQuery = nameQuery.And(p =>
                        p.Account.FullName.Contains(item) ||
                        p.Account.Mobile.Contains(item) ||
                        p.Account.Email.Contains(item) ||
                        p.Account.NationalCode.Contains(item) ||
                        p.AccountAddress.NameFamily.Contains(item) ||
                        p.AccountAddress.CityName.Contains(item) ||
                        p.AccountAddress.State.Name.Contains(item) ||
                        p.AccountAddress.AddressValue.Contains(item) ||
                        p.AccountAddress.Mobile.Contains(item) ||
                        p.AccountAddress.Phone.Contains(item)
                    );
                }
                MyQuery = MyQuery.And(nameQuery);
            }

            if (fromDatetime != null && fromDatetime != default(DateTime))
                MyQuery = MyQuery.And(p => p.Datetime >= fromDatetime);

            if (toDatetime != null && toDatetime != default(DateTime))
            {
                DateTime toDatetimeTemp = toDatetime.Value.AddDays(1);
                MyQuery = MyQuery.And(p => p.Datetime <= toDatetimeTemp);
            }

            return MyQuery;
        }

        public List<AccountOrder> GetAllSuccessfullStatusByAccountId(int accountId)
        {
            string status_success = Enum_Code.ORDER_STATUS_SUCCESS.ToString();
            string status_process = Enum_Code.ORDER_STATUS_PROCESS.ToString();
            string status_store = Enum_Code.ORDER_STATUS_STORE.ToString();
            string status_post = Enum_Code.ORDER_STATUS_POST.ToString();
            string status_ready = Enum_Code.ORDER_STATUS_READY.ToString();

            return _context.AccountOrder.Where(p => 
                p.AccountId == accountId &&
                (
                    p.Code.Label == status_success ||
                    p.Code.Label == status_process ||
                    p.Code.Label == status_store ||
                    p.Code.Label == status_post ||
                    p.Code.Label == status_ready
                )
            )
            .OrderByDescending(p => p.Datetime)
            .ToList();
        }
    }
}
