﻿using Binbin.Linq;
using DataLayer.Entities;
using DataLayer.Enumarables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Repositories
{
    public class Entity_Post : BaseRepository<Post>
    {
        DatabaseEntities _context;
        public Entity_Post(DatabaseEntities context) : base(context)
        {
            _context = context;
        }

        public List<Post> Search(int? websiteId = null, int? notId = null, int? categoryId = null, string categoryLabel = null, int index = 1, int pageSize = 10, string name = null, Enum_PostOrder order = Enum_PostOrder.NONE)
        {
            var MyQuery = GetSearchQuery(websiteId: websiteId, notId: notId, categoryId: categoryId, categoryLabel: categoryLabel, name: name);
            int skipValue = pageSize * (index - 1);
            int pageValue = pageSize;
            
           if (order == Enum_PostOrder.NEW)
                return _context.Post.OrderByDescending(p => p.ID).Where(MyQuery).Skip(skipValue).Take(pageValue).ToList();
            else if (order == Enum_PostOrder.OLD)
                return _context.Post.OrderBy(p => p.ID).Where(MyQuery).Skip(skipValue).Take(pageValue).ToList();
            else if (order == Enum_PostOrder.MORE_VISIT)
                return _context.Post.OrderByDescending(p => p.VisitCount).Where(MyQuery).Skip(skipValue).Take(pageValue).ToList();
            else
                return _context.Post.OrderBy(p => p.ShowNumber).ThenBy(p => p.ID).Where(MyQuery).Skip(skipValue).Take(pageValue).ToList();
        }

        public int SearchCount(int? websiteId = null, int? notId = null, int? categoryId = null, string categoryLabel = null, string name = null)
        {
            var MyQuery = GetSearchQuery(websiteId: websiteId, notId: notId, categoryId: categoryId, categoryLabel: categoryLabel, name: name);
            return _context.Post.Count(MyQuery);
        }

        private Expression<Func<Post, bool>> GetSearchQuery(int? websiteId = null, int? notId = null, int? categoryId = null, string categoryLabel = null, string name = null)
        {
            var MyQuery = PredicateBuilder.True<Post>();
            if (notId != null && notId != 0)
                MyQuery = MyQuery.And(p => p.ID != notId);
            if (websiteId != null && websiteId != 0)
                MyQuery = MyQuery.And(p => p.WebsiteId == websiteId);
            if (categoryId != null && categoryId != 0)
                MyQuery = MyQuery.And(p => p.CategoryId == categoryId);
            if (categoryLabel != null)
                MyQuery = MyQuery.And(p => p.Category.Label == categoryLabel);
            if (name != null)
                MyQuery = MyQuery.And(p => p.Name.Contains(name));

            MyQuery = MyQuery.And(p => p.Active);
            return MyQuery;
        }
    }
}
