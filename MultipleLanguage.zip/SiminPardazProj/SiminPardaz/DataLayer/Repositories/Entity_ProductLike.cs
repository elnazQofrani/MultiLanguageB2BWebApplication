﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer.Entities;

namespace DataLayer.Repositories
{
    public class Entity_ProductLike : BaseRepository<ProductLike>
    {
        private DatabaseEntities _context;
        public Entity_ProductLike(DatabaseEntities context) : base(context)
        {
            _context = context;
        }

        public bool IsAny(int ProductId, int AccountId)
        {
            return _context.ProductLike.Any(P => P.AccountId == AccountId && P.ProductId == ProductId);
        }

        public ProductLike GetByProductIdAndAccountId(int ProductId, int AccountId)
        {
            return _context.ProductLike.FirstOrDefault(p => 
                p.AccountId == AccountId &&
                p.ProductId == ProductId
            );
        }

        public List<ProductLike> GetAllByProductId(int productId)
        {
            return _context.ProductLike.Where(p =>
                p.ProductId == productId
            ).ToList();
        }
        public List<ProductLike> GetAllByAccountId(int accountId)
        {
            return _context.ProductLike.Where(p =>
                p.AccountId == accountId
            ).ToList();
        }

        public void DeleteByProductId(int productId)
        {
            List<ProductLike> list = GetAllByProductId(productId);
            for (int i = 0; i < list.Count; i++)
            {
                Delete(list[i]);
            }
        }
    }
}
