﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer.Entities;
using Binbin.Linq;
using DataLayer.Base;
using DataLayer.ViewModels;
using System.Linq.Expressions;
using System.Web;


namespace DataLayer.Repositories
{
    public class Entity_WebsiteLanguage : BaseRepository<WebsiteLanguage>
    {
        DatabaseEntities _context;
        public Entity_WebsiteLanguage(DatabaseEntities context) : base(context)
        {
            _context = context;
        }

        public List<WebsiteLanguage> GetAllByWebsiteId(int WebsiteId)
        {
            return _context.WebsiteLanguage.Where(p => p.WebsiteId == WebsiteId).ToList();
        }

    }
}
