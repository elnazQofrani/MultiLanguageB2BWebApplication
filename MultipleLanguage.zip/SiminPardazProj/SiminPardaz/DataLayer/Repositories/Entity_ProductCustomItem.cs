﻿using Binbin.Linq;
using DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Repositories
{
    public class Entity_ProductCustomItem : BaseRepository<ProductCustomItem>
    {
        private DatabaseEntities _context;
        public Entity_ProductCustomItem(DatabaseEntities context) : base(context)
        {
            _context = context;
        }

        public List<ProductCustomItem> Search(
            int? typeId = null,
            int? categoryId = null,
            int? subcategoryId = null,
            int? fieldId = null,
            int? notId = null,
            string fieldName = null,
            int? brandId = null,
            string value = null,
            bool? hasLabel = null,
            int? index = 1,
            int? pageSize = null)
        {
            List<ProductCustomItem> results = new List<ProductCustomItem>();
            pageSize = pageSize == null ? 10 : pageSize;
            index = index == null ? 1 : index;
            int skipValue = pageSize.Value * (index.Value - 1);
            int pageValue = pageSize.Value;

            var MyQuery = GetSearchQuery(typeId: typeId, categoryId: categoryId, subcategoryId: subcategoryId, fieldId: fieldId, notId: notId, fieldName: fieldName, brandId: brandId, value: value, hasLabel: hasLabel);

            results = _context
                .ProductCustomItem
                .OrderBy(p => p.ID)
                .Where(MyQuery)
                .Skip(skipValue)
                .Take(pageValue)
                .ToList();

            return results;
        }

        public int SearchCount(
            int? typeId = null,
            int? categoryId = null,
            int? subcategoryId = null,
            int? fieldId = null,
            int? notId = null,
            string fieldName = null,
            int? brandId = null,
            string value = null,
            bool? hasLabel = null)
        {
            var MyQuery = GetSearchQuery(typeId: typeId, categoryId: categoryId, subcategoryId: subcategoryId, fieldId: fieldId, notId: notId, fieldName: fieldName, brandId: brandId, value: value, hasLabel: hasLabel);

            return _context
                .ProductCustomItem
                .OrderBy(p => p.ID)
                .Count(MyQuery);
        }

        private Expression<Func<ProductCustomItem, bool>> GetSearchQuery(
            int? typeId = null,
            int? categoryId = null,
            int? subcategoryId = null,
            int? fieldId = null,
            int? notId = null,
            string fieldName = null,
            int? brandId = null,
            string value = null,
            bool? hasLabel = null)
        {
            var MyQuery = PredicateBuilder.True<ProductCustomItem>();
            if (typeId != null)
                MyQuery = MyQuery.And(p => p.ProductCustomField.ProductTypeId == typeId);
            if (fieldId != null)
                MyQuery = MyQuery.And(p => p.FieldId == fieldId);
            if (fieldName != null)
                MyQuery = MyQuery.And(p => p.ProductCustomField.Label == fieldName);
            if (notId != null)
                MyQuery = MyQuery.And(p => p.ID != notId);
            if (value != null)
                MyQuery = MyQuery.And(p => p.Value.Contains(value));
            if (brandId != null)
                MyQuery = MyQuery.And(p => p.ProductCustomValue.Any(s => s.Product.BrandId == brandId));
            if (categoryId != null)
                MyQuery = MyQuery.And(p => p.ProductCustomValue.Any(s => s.Product.ProductCategoryId == categoryId));
            if (subcategoryId != null)
                MyQuery = MyQuery.And(p => p.ProductCustomValue.Any(s => s.Product.ProductSubCategoryId == subcategoryId));
            if (hasLabel == true)
                MyQuery = MyQuery.And(p => p.Label != null && p.Label != "");
            return MyQuery;
        }

        public ProductCustomItem GetByLabel(string label)
        {
            return _context.ProductCustomItem.FirstOrDefault(p => p.Label == label);
        }
    }
}
