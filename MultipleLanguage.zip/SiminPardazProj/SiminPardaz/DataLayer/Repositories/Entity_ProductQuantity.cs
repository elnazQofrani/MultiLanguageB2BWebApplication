﻿using DataLayer.Entities;
using DataLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Repositories
{
    public class Entity_ProductQuantity : BaseRepository<ProductQuantity>
    {
        private DatabaseEntities _context;
        public Entity_ProductQuantity(DatabaseEntities context) : base(context)
        {
            _context = context;
        }

        public void DeleteByProductId(int productId)
        {
            List<ProductQuantity> list = GetAllByProductId(productId);
            for (int i = 0; i < list.Count; i++)
            {
                Delete(list[i]);
            }
        }

        public List<ProductQuantity> GetAllByProductId(int productId)
        {
            return _context.ProductQuantity.Where(p => p.ProductId == productId)
                .OrderBy(p => p.ColorId)
                .ThenBy(p => p.SizeId)
                .ToList();
        }
    }
}
