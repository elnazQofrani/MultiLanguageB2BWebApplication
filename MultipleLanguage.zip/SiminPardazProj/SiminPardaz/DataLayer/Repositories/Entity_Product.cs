﻿using Binbin.Linq;
using DataLayer.Entities;
using DataLayer.Enumarables;
using DataLayer.Base;
using DataLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Web;

namespace DataLayer.Repositories
{
    public class Entity_Product : BaseRepository<Product>
    {
        private DatabaseEntities _context;
        public Entity_Product(DatabaseEntities context) : base(context)
        {
            _context = context;
        }

        public int SearchCount(string Id = null, int? notId = null, string typeId = null, string categoryId = null, int? userId = null, string subCategoryId = null, string brandId = null, string name = null, string discount = null, int? pricefrom = null, int? priceto = null, int? heightfrom = null,
            int? heightto = null,
            int? internalfrom = null,
            int? internalto = null,
            int? externalfrom = null,
            int? externalto = null, string custom = null, string customlabel = null, string colorId = null, string sizeId = null, string active = "true", bool? showHome = null, string status = null, string codeValue = null, string categorylabel = null)
        {
            var MyQuery = GetSearchQuery(Id: Id,
                notId: notId,
                categoryId: categoryId,
                discount: discount,
                name: name,
                pricefrom: pricefrom,
                brandId: brandId,
                priceto: priceto,
                heightfrom: heightfrom,
                heightto: heightto,
                internalfrom: internalfrom,
                internalto: internalto,
                externalfrom: externalfrom,
                externalto: externalto,
                subCategoryId: subCategoryId,
                typeId: typeId,
                custom: custom,
                customlabel: customlabel,
                colorId: colorId,
                sizeId: sizeId,
                active: active,
                showHome: showHome,
                status: status,
                codeValue: codeValue,
                categorylabel: categorylabel);
            return _context.Product.Count(MyQuery);
        }

        public List<Product> Search(
            string Id = null, 
            int? notId = null, 
            string typeId = null, 
            string categoryId = null, 
            string subCategoryId = null, 
            string brandId = null, 
            int index = 1, 
            int pageSize = 10, 
            string name = null, 
            string title = null, 
            string discount = null, 
            Enum_ProductOrder order = Enum_ProductOrder.NONE, 
            int? pricefrom = null, 
            int? priceto = null,
            int? heightfrom = null,
            int? heightto = null,
            int? internalfrom = null,
            int? internalto = null,
            int? externalfrom = null,
            int? externalto = null,
            string custom = null, 
            string customlabel = null, 
            string colorId = null, 
            string sizeId = null, 
            string status = null, 
            string active = "true", 
            bool? showHome = null, 
            DateTime? updateDatetime = null, 
            string codeValue = null, 
            string categorylabel = null)
        {
            List<Product> results = new List<Product>();
            int skipValue = pageSize * (index - 1);
            int pageValue = pageSize;

            var MyQuery = GetSearchQuery(
                                    Id: Id,
                                    notId: notId,
                                    categoryId: categoryId,
                                    discount: discount,
                                    name: name,
                                    pricefrom: pricefrom,
                                    priceto: priceto,
                                    heightfrom: heightfrom,
                                    heightto: heightto,
                                    internalfrom: internalfrom,
                                    internalto: internalto,
                                    externalfrom: externalfrom,
                                    externalto: externalto,
                                    brandId: brandId,
                                    subCategoryId: subCategoryId,
                                    typeId: typeId,
                                    custom: custom,
                                    customlabel: customlabel,
                                    colorId: colorId,
                                    sizeId: sizeId,
                                    active: active,
                                    showHome: showHome,
                                    status: status,
                                    updateDatetime: updateDatetime,
                                    codeValue: codeValue,
                                    categorylabel: categorylabel);

            string order_status_post = Enum_Code.ORDER_STATUS_POST.ToString();
            string order_status_process = Enum_Code.ORDER_STATUS_PROCESS.ToString();
            string order_status_store = Enum_Code.ORDER_STATUS_STORE.ToString();
            string order_status_ready = Enum_Code.ORDER_STATUS_READY.ToString();
            string order_status_success = Enum_Code.ORDER_STATUS_SUCCESS.ToString();

            if (order == Enum_ProductOrder.NONE)
                results = _context.Product.Where(MyQuery)
                    .OrderBy(p => p.Code.Value)
                    .ThenBy(p => p.ID)
                    .Skip(skipValue)
                    .Take(pageValue)
                    .ToList();
            else if (order == Enum_ProductOrder.NEW)
                results = _context.Product.Where(MyQuery)
                    .OrderBy(p => p.Code.Value)
                    //.OrderByDescending(p => p.CreateDatetime)
                    .ThenByDescending(p => p.ID)
                    .Skip(skipValue)
                    .Take(pageValue)
                    .ToList();
            else if (order == Enum_ProductOrder.UPDATE)
                results = _context.Product.Where(MyQuery)
                    //.OrderBy(p => p.Code.Value)
                    //.ThenBy(p => p.UpdateDatetime)
                    .OrderBy(p => p.UpdateDatetime)
                    .Skip(skipValue)
                    .Take(pageValue)
                    .ToList();
            else if (order == Enum_ProductOrder.UPDATE_DESC)
                results = _context.Product.Where(MyQuery)
                    .OrderBy(p => p.Code.Value)
                    .ThenByDescending(p => p.UpdateDatetime)
                    .Skip(skipValue)
                    .Take(pageValue)
                    .ToList();
            else if (order == Enum_ProductOrder.OLD)
                results = _context.Product.Where(MyQuery)
                    .OrderBy(p => p.Code.Value)
                    .ThenBy(p => p.CreateDatetime)
                    .ThenBy(p => p.ID)
                    .Skip(skipValue)
                    .Take(pageValue)
                    .ToList();
            else if (order == Enum_ProductOrder.RANDOM)
                results = _context.Product.Where(MyQuery)
                    .OrderBy(p => p.Code.Value)
                    .ThenBy(p => Guid.NewGuid())
                    .Skip(skipValue)
                    .Take(pageValue)
                    .ToList();
            else if (order == Enum_ProductOrder.PRICE_MAX_TO_MIN)
                results = _context.Product.Where(MyQuery)
                    .OrderBy(p => p.Code.Value)
                    .ThenByDescending(p => p.Price)
                    .Skip(skipValue)
                    .Take(pageValue)
                    .ToList();
            else if (order == Enum_ProductOrder.MORE_RATING)
                results = _context.Product.Where(MyQuery)
                    .OrderBy(p => p.Code.Value)
                    .ThenByDescending(p => p.ProductRate.Sum(s => s.RateValue))
                    .Skip(skipValue)
                    .Take(pageValue)
                    .ToList();
            else if (order == Enum_ProductOrder.PRICE_MIN_TO_MAX)
                results = _context.Product.Where(MyQuery)
                    .OrderBy(p => p.Code.Value)
                    .ThenBy(p => p.Price)
                    .Skip(skipValue)
                    .Take(pageValue)
                    .ToList();
            else if (order == Enum_ProductOrder.MORE_SELL)
                results = _context.Product.Where(MyQuery)
                    .OrderBy(p => p.Code.Value)
                    .ThenByDescending(p => p.AccountOrderProduct.Count(q =>
                        q.AccountOrder.Code.Label == order_status_post ||
                        q.AccountOrder.Code.Label == order_status_process ||
                        q.AccountOrder.Code.Label == order_status_store ||
                        q.AccountOrder.Code.Label == order_status_ready ||
                        q.AccountOrder.Code.Label == order_status_success))
                    .Skip(skipValue)
                    .Take(pageValue)
                    .ToList();
            else if (order == Enum_ProductOrder.SHOWNUMBER)
                results = _context.Product.Where(MyQuery)
                    .OrderBy(p => p.Code.Value)
                    .ThenBy(p => p.ShowNumber)
                    .Skip(skipValue)
                    .Take(pageValue)
                    .ToList();
            else if (order == Enum_ProductOrder.SHOWNUMBER_DESC)
                results = _context.Product.Where(MyQuery)
                    .OrderBy(p => p.Code.Value)
                    .ThenByDescending(p => p.ShowNumber)
                    .Skip(skipValue)
                    .Take(pageValue)
                    .ToList();
            else if (order == Enum_ProductOrder.MORE_VISIT)
                results = _context.Product.Where(MyQuery)
                    .OrderBy(p => p.Code.Value)
                    .ThenByDescending(p => p.VisitCount)
                    .Skip(skipValue)
                    .Take(pageValue)
                    .ToList();
            else if (order == Enum_ProductOrder.MORE_LIKE)
                results = _context.Product.Where(MyQuery)
                    .OrderBy(p => p.Code.Value)
                    .ThenByDescending(p => p.ProductLike.Count)
                    .Skip(skipValue)
                    .Take(pageValue)
                    .ToList();
            else if (order == Enum_ProductOrder.ID)
                results = _context.Product.Where(MyQuery)
                    .OrderBy(p => p.ID)
                    .Skip(skipValue)
                    .Take(pageValue)
                    .ToList();
            else if (order == Enum_ProductOrder.ID_DESC)
                results = _context.Product.Where(MyQuery)
                    .OrderByDescending(p => p.ID)
                    .Skip(skipValue)
                    .Take(pageValue)
                    .ToList();

            return results;
        }

        public Product GetByCodeValue(string codeValue)
        {
            return _context.Product.FirstOrDefault(s => s.CodeValue == codeValue);
        }

        public Expression<Func<Product, object>> GetOrder(Enum_ProductOrder order = Enum_ProductOrder.NONE)
        {
            Expression<Func<Product, object>> orderByFunc = null;
            if (order == Enum_ProductOrder.NEW)
                orderByFunc = (p => p.ID);
            return orderByFunc;
        }

        private Expression<Func<Product, bool>> GetSearchQuery(
            string Id = null,
            int? notId = null,
            string typeId = null,
            int? userId = null,
            string categoryId = null,
            string subCategoryId = null,
            int? pricefrom = null,
            int? priceto = null,
            int? heightfrom = null,
            int? heightto = null,
            int? internalfrom = null,
            int? internalto = null,
            int? externalfrom = null,
            int? externalto = null,
            string brandId = null,
            string name = null,
            string discount = null,
            string custom = null,
            string customlabel = null,
            string colorId = null,
            string sizeId = null,
            string active = "true",
            string status = null,
            bool? showHome = null,
            string codeValue = null,
            DateTime? updateDatetime = null,
            string categorylabel = null)
        {
            active = string.IsNullOrEmpty(active) ? "true" : active.ToUpper();

            bool? isActive = null;
            if (active == "TRUE")
                isActive = true;
            else if (active == "FALSE")
                isActive = false;

            var MyQuery = PredicateBuilder.True<Product>();

            if (string.IsNullOrEmpty(Id) == false)
            {
                var QueryStr = PredicateBuilder.False<Product>();
                string[] Split = Id.Split('-');
                foreach (var item in Split)
                {
                    int itemId = item.GetInteger();
                    if (itemId != 0)
                    {
                        QueryStr = QueryStr.Or(p =>
                            p.ID == itemId
                        );
                    }
                }
                MyQuery = MyQuery.And(QueryStr);
            }

            if (string.IsNullOrEmpty(codeValue) == false)
                MyQuery = MyQuery.And(p => p.CodeValue.Contains(codeValue));
            if (notId != null && notId != 0)
                MyQuery = MyQuery.And(p => p.ID != notId);
            if (pricefrom != null)
                MyQuery = MyQuery.And(p => p.Price >= pricefrom);
            if (priceto != null)
                MyQuery = MyQuery.And(p => p.Price <= priceto);

            if (heightfrom != null)
                MyQuery = MyQuery.And(p => p.Height >= heightfrom || p.Height == null);
            if (heightto != null)
                MyQuery = MyQuery.And(p => p.Height <= heightto || p.Height == null);

            if (internalfrom != null)
                MyQuery = MyQuery.And(p => p.InternalDiameter >= internalfrom || p.InternalDiameter == null);
            if (internalto != null)
                MyQuery = MyQuery.And(p => p.InternalDiameter <= internalto || p.InternalDiameter == null);

            if (externalfrom != null)
                MyQuery = MyQuery.And(p => p.ExternalDiameter >= externalfrom || p.ExternalDiameter == null);
            if (externalto != null)
                MyQuery = MyQuery.And(p => p.ExternalDiameter <= externalto || p.ExternalDiameter == null);

            if (isActive != null)
                MyQuery = MyQuery.And(p => p.Active == isActive);
            if (showHome != null)
                MyQuery = MyQuery.And(p => p.ShowHomePage == showHome);
            if (string.IsNullOrEmpty(status) != true)
                MyQuery = MyQuery.And(p => p.Code.Label == status);
            if (userId != null)
                MyQuery = MyQuery.And(p => p.UserId == userId);
            if (updateDatetime != null)
                MyQuery = MyQuery.And(p => p.UpdateDatetime > updateDatetime);
            if (string.IsNullOrEmpty(categorylabel) == false)
            {
                MyQuery = MyQuery.And(p =>
                    p.ProductType.Label == categorylabel ||
                    p.ProductCategory.Label == categorylabel ||
                    p.ProductSubCategory.Label == categorylabel);
            }
            if (IsNullOrEmptyId(discount) == false)
            {
                DateTime now = DateTime.Now;
                string type_shop = Enum_Code.DISCOUNT_TYPE_SHOP.ToString();
                string type_producttype = Enum_Code.DISCOUNT_TYPE_PRODUCTTYPE.ToString();
                string type_productcategory = Enum_Code.DISCOUNT_TYPE_CATEGORY.ToString();
                string type_productsubcategory = Enum_Code.DISCOUNT_TYPE_SUBCATEGORY.ToString();
                string type_productbrand = Enum_Code.DISCOUNT_TYPE_BRAND.ToString();
                string type_product = Enum_Code.DISCOUNT_TYPE_PRODUCT.ToString();
                MyQuery = MyQuery.And(s =>
                    s.Discount.Any(p =>
                    (
                        (p.Code.Label == type_shop) ||
                        (p.Code.Label == type_product && p.ProductId == s.ID) ||
                        (p.Code.Label == type_producttype && p.ProductTypeId == s.ProductTypeId && s.ProductType.Active) ||
                        (p.Code.Label == type_productcategory && p.ProductCategoryId == s.ProductCategoryId && s.ProductCategory.Active) ||
                        (p.Code.Label == type_productbrand && p.ProductBrandId == s.ProductSubCategoryId && s.ProductSubCategory.Active) ||
                        (p.Code.Label == type_productsubcategory && p.ProductBrandId == s.BrandId)
                    ) &&
                    (p.Active == true) &&
                    (p.StartDatetime == null || (p.StartDatetime != null && p.StartDatetime <= now)) &&
                    (p.EndDatetime == null || (p.EndDatetime != null && p.EndDatetime >= now)) &&
                    (p.DiscountGroup.Label == discount)
                ));
            }

            if (IsNullOrEmptyId(typeId) == false)
            {
                var QueryStr = PredicateBuilder.False<Product>();
                string[] Split = typeId.Split('-');
                foreach (var item in Split)
                {
                    int itemId = item.GetInteger();
                    if (itemId != 0)
                    {
                        QueryStr = QueryStr.Or(p =>
                            p.ProductTypeId == itemId &&
                            p.ProductType.Active
                        );
                    }
                }
                MyQuery = MyQuery.And(QueryStr);
            }
            else
            {
                MyQuery = MyQuery.And(p =>
                    p.ProductTypeId == null ||
                    (p.ProductTypeId != null && p.ProductType.Active)
                );
            }

            if (IsNullOrEmptyId(categoryId) == false)
            {
                var QueryStr = PredicateBuilder.False<Product>();
                string[] Split = categoryId.Split('-');
                foreach (var item in Split)
                {
                    int itemId = item.GetInteger();
                    if (itemId != 0)
                    {
                        QueryStr = QueryStr.Or(p =>
                            p.ProductCategoryId == itemId &&
                            p.ProductCategory.Active
                        );
                    }
                }
                MyQuery = MyQuery.And(QueryStr);
            }
            else
            {
                MyQuery = MyQuery.And(p =>
                    p.ProductCategoryId == null ||
                    (p.ProductCategoryId != null && p.ProductCategory.Active)
                );
            }

            if (IsNullOrEmptyId(subCategoryId) == false)
            {
                var QueryStr = PredicateBuilder.False<Product>();
                string[] Split = subCategoryId.Split('-');
                foreach (var item in Split)
                {
                    int itemId = item.GetInteger();
                    if (itemId != 0)
                    {
                        QueryStr = QueryStr.Or(p =>
                            p.ProductSubCategoryId == itemId &&
                            p.ProductSubCategory.Active
                        );
                    }
                }
                MyQuery = MyQuery.And(QueryStr);
            }
            else
            {
                MyQuery = MyQuery.And(p =>
                    p.ProductSubCategoryId == null ||
                    (p.ProductSubCategoryId != null && p.ProductSubCategory.Active)
                );
            }

            if (IsNullOrEmptyId(brandId) == false)
            {
                var QueryStr = PredicateBuilder.False<Product>();
                string[] Split = brandId.Split('-');
                foreach (var item in Split)
                {
                    if (string.IsNullOrEmpty(item) == false)
                    {
                        int itemId = item.GetInteger();
                        if (itemId != 0)
                        {
                            QueryStr = QueryStr.Or(p =>
                                p.BrandId == itemId &&
                                p.ProductBrand.Active
                            );
                        }
                        else
                        {
                            QueryStr = QueryStr.Or(p =>
                                p.ProductBrand.Label == item &&
                                p.ProductBrand.Active
                            );
                        }
                    }
                }
                MyQuery = MyQuery.And(QueryStr);
            }
            else
            {
                MyQuery = MyQuery.And(p =>
                    p.BrandId == null ||
                    (p.BrandId != null && p.ProductBrand.Active)
                );
            }

            if (IsNullOrEmptyId(colorId) == false)
            {
                var QueryStr = PredicateBuilder.False<Product>();
                string[] Split = colorId.Split('-');
                foreach (var item in Split)
                {
                    int itemId = item.GetInteger();
                    if (itemId != 0)
                    {
                        QueryStr = QueryStr.Or(p =>
                            p.ProductColor.Any
                            (q =>
                                q.ColorId == itemId &&
                                (
                                    (q.Product.ProductQuantity.Any(z => z.ColorId == q.ColorId && z.Count > 0))
                                )
                            )
                        );
                    }
                }
                MyQuery = MyQuery.And(QueryStr);
            }

            if (IsNullOrEmptyId(sizeId) == false)
            {
                var QueryStr = PredicateBuilder.False<Product>();
                string[] Split = sizeId.Split('-');
                foreach (var item in Split)
                {
                    int itemId = item.GetInteger();
                    if (itemId != 0)
                    {
                        QueryStr = QueryStr.Or(p =>
                            p.ProductSize.Any(q => q.SizeId == itemId)
                        );
                    }
                }
                MyQuery = MyQuery.And(QueryStr);
            }

            if (IsNullOrEmptyId(name) == false)
            {
                var nameQuery = PredicateBuilder.True<Product>();
                string[] nameSplit = name.Split(' ');
                foreach (var item in nameSplit)
                {
                    nameQuery = nameQuery.And(p =>
                    p.Name.Contains(item) ||
                    p.CodeValue.Contains(item) ||
                    //p.ProductCustomValue.Any(s => s.Value.Contains(item)) ||
                    //p.ProductCustomValue.Any(s => s.ProductCustomItem.Value.Contains(item)) ||
                    (p.ProductSubCategoryId != null && p.ProductSubCategory.Name.Contains(item)) ||
                    (p.ProductCategoryId != null && p.ProductCategory.Name.Contains(item)) ||
                    (p.ProductTypeId != null && p.ProductType.Name.Contains(item)) ||
                    p.ProductBrand.Name.Contains(item));
                }
                MyQuery = MyQuery.And(nameQuery);
            }

            if (IsNullOrEmptyId(custom) == false)
            {
                var itemQuery = PredicateBuilder.True<Product>();
                string[] searchParts = custom.Split('*');
                foreach (string oneItem in searchParts)
                {
                    string[] splitedOne = oneItem.Split('@');
                    int fieldId = splitedOne[0].GetInteger();
                    string dropdown_type = Enum_Code.FIELD_TYPE_DROPDOWN.ToString();
                    if (splitedOne[1].IsInteger())
                    {
                        int itemId = splitedOne[1].GetInteger();
                        string itemIdString = splitedOne[1];
                        MyQuery = MyQuery.And(s =>
                            s.ProductCustomValue.Any(p =>
                                    p.FieldId == fieldId &
                                    (
                                        (
                                            p.ProductCustomField.Code.Label == dropdown_type &&
                                            p.ItemId == itemId
                                        )
                                        ||
                                        (
                                            p.ProductCustomField.Code.Label != dropdown_type &&
                                            p.Value == itemIdString
                                        )
                                    )
                                )
                            );
                    }
                    else if (splitedOne[1].Contains("-"))
                    {
                        var QueryStr = PredicateBuilder.False<Product>();
                        string[] Split = splitedOne[1].Split('-');
                        foreach (var item in Split)
                        {
                            int itemId = item.GetInteger();
                            if (itemId != 0)
                            {
                                QueryStr = QueryStr.Or(s =>
                                    s.ProductCustomValue.Any(p =>
                                    p.FieldId == fieldId &
                                    (
                                        (
                                            p.ProductCustomField.Code.Label == dropdown_type &&
                                            p.ItemId == itemId
                                        )
                                        ||
                                        (
                                            p.ProductCustomField.Code.Label != dropdown_type &&
                                            p.Value == item
                                        )
                                    )
                                )
                                );
                            }
                        }
                        MyQuery = MyQuery.And(QueryStr);
                    }
                }
                MyQuery = MyQuery.And(itemQuery);
            }

            if (IsNullOrEmptyId(customlabel) == false)
            {
                MyQuery = MyQuery.And(p => p.ProductCustomValue.Any(s => s.ProductCustomItem.Label == customlabel));
            }

            return MyQuery;
        }

        public void AddTrackingCookie(Product product)
        {
            string trackingValue = "";
            HttpCookie productCookie = HttpContext.Current.Request.Cookies["TRACKING"];
            if (productCookie == null)
            {
                productCookie = new HttpCookie("TRACKING") { Value = "" };
            }

            if (productCookie.Value.Contains(product.ID + "-") == false)
            {
                trackingValue = trackingValue + product.ID + "-" + productCookie.Value;
            }
            else
            {
                trackingValue = productCookie.Value;
            }

            if (trackingValue.Count(p => p == '-') > 10)
            {
                List<string> splitedValue = trackingValue.Split('-').ToList();
                splitedValue = splitedValue.Take(10).ToList();
                trackingValue = string.Join("-", splitedValue) + "-";
            }

            productCookie.Value = trackingValue;
            productCookie.Expires = DateTime.Now.AddMonths(1);
            HttpContext.Current.Response.Cookies.Add(productCookie);
        }

        public bool DeleteProductPictureDirectly(int productId)
        {
            string query = "UPDATE [Product] SET PictureId = NULL WHERE ID = " + productId;
            int result = _context.Database.ExecuteSqlCommand(query);
            return result > 0 ? true : false;
        }

        public bool UpdateProductPictureDirectly(int productId, int pictureId)
        {
            string query = "UPDATE [Product] SET PictureId = " + pictureId + " WHERE ID = " + productId;
            int result = _context.Database.ExecuteSqlCommand(query);
            return result > 0 ? true : false;
        }

        public bool UpdateProductSyncDatetime(int productId, DateTime? syncDatetime)
        {
            string query = "UPDATE [Product] SET SyncDatetime = '" + syncDatetime + "' WHERE ID = " + productId;
            int result = _context.Database.ExecuteSqlCommand(query);
            return result > 0 ? true : false;
        }
    }
}
