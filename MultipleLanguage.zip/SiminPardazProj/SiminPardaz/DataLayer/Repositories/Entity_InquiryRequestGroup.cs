﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Binbin.Linq;
using DataLayer.Entities;

namespace DataLayer.Repositories
{
  public  class Entity_InquiryRequestGroup : BaseRepository<InquiryRequestGroup>
    {
        DatabaseEntities _context;
        public Entity_InquiryRequestGroup(DatabaseEntities context) : base(context)
        {
            _context = context;
        }


        public List<InquiryRequestGroup> Search(int pageSize = 10, int index = 1, string CustomerCodeValue = null, string ProductCodeValue = null)
        {
            int skipValue = pageSize * (index - 1);
            int pageValue = pageSize;
            var MyQuery = GetSearchQuery(CustomerCodeValue, ProductCodeValue);
  
            return _context
                    .InquiryRequestGroup
                    .Where(MyQuery)
                    .OrderBy(p => p.ID)
                    .Skip(skipValue)
                    .Take(pageValue)
                    .ToList();
        }


        public int SearchCount(string CustomerCodeValue = null, string ProductCodeValue = null)
        {
            var MyQuery = GetSearchQuery(CustomerCodeValue, ProductCodeValue);
            return _context.InquiryRequestGroup.Count(MyQuery);
        }



        private Expression<Func<InquiryRequestGroup, bool>> GetSearchQuery(string CustomerCodeValue = null, string ProductCodeValue = null)
        {
            var MyQuery = PredicateBuilder.True<InquiryRequestGroup>();
            if (string.IsNullOrEmpty(ProductCodeValue) == false)
                MyQuery = MyQuery.And(p => p.InquiryRequest.Any(s=>s.Product.CodeValue== ProductCodeValue));

            if (string.IsNullOrEmpty(CustomerCodeValue) == false)
                MyQuery = MyQuery.And(p => p.Account.TrackingCode.Contains(CustomerCodeValue));
            return MyQuery;
        }



    }


}
