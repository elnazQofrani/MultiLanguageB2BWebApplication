﻿using DataLayer.Entities;
using DataLayer.Enumarables;
using DataLayer.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer.ViewModels;

namespace DataLayer.Repositories
{
    public class Entity_Payment : BaseRepository<Payment>
    {
        private DatabaseEntities _context;
        public Entity_Payment(DatabaseEntities context) : base(context)
        {
            _context = context;
        }

        public Payment GetByReferenceNumber(string refNumber)
        {
            return _context.Payment.FirstOrDefault(p => p.RefNumber == refNumber);
        }

        public Payment CreatePayment(int? accountId, int? userId, int subjectId, int price, int? merchantId, string description = null)
        {
            string payment_insert = Enum_Code.PAYMENT_STATUS_INSERTED.ToString();
            Payment payment = new Payment()
            {
                StatusId = _context.Code.FirstOrDefault(p => p.Label == payment_insert).ID,
                MerchantId = merchantId,
                SubjectId = subjectId,
                Amount = price,
                IpAddress = BaseSecurity.GetClientIPAddress(),
                Datetime = DateTime.Now,
                Description = description
            };
            if (accountId != null)
                payment.AccountId = accountId.GetValueOrDefault();
            if (userId != null)
                payment.SiteUserId = userId.GetValueOrDefault();
            Insert(payment);
            Save();
            return payment;
        }

        public void DoPaymentServices(UnitOfWork mainContext, Payment payment)
        {
            if (payment.PaymentSubject.Label == Enum_PaymentSubject.ORDER.ToString())
            {
                PaymentProductOrder productOrder = payment.PaymentProductOrder.FirstOrDefault();
                AccountOrder order = null;
                Account account = null;
                if (productOrder != null)
                {
                    order = productOrder.AccountOrder;
                    account = order.Account;
                    if (order.PaymentType.Label == Enum_PaymentType.ONLINE.ToString())
                    {
                        if (order.Price == payment.Amount)
                        {
                            DoOrderPaymentServices(mainContext, payment, order);
                        }
                        else if (order.Price < payment.Amount)
                        {
                            //DoCreditPaymentServices(mainContext, payment);
                        }
                        else
                        {
                            int DiffPrice = payment.Amount - order.Price;
                            DoOrderPaymentServices(mainContext, payment, order);
                            //DoCreditPaymentServices(mainContext, payment, DiffPrice);
                        }
                    }
                    else if (order.PaymentType.Label == Enum_PaymentType.PLACE.ToString())
                    {
                        DoOrderPaymentServices(mainContext, payment, order);
                    }
                }                
            }
            else if (payment.PaymentSubject.Label == Enum_PaymentSubject.CREDIT.ToString())
            {
                //DoCreditPaymentServices(mainContext, payment);
            }
        }

        private void DoOrderPaymentServices(UnitOfWork mainContext, Payment payment, AccountOrder order)
        {
            int orderId = 0;
            int price = 0;
            order.StatusId = mainContext.Code.GetIdByLabel(Enum_Code.ORDER_STATUS_SUCCESS);
            order.Datetime = DateTime.Now;
            orderId = order.ID;
            price = order.Price;
            Save();

            mainContext.AccountBasket.ClearBasket(payment.AccountId.Value);

            foreach (AccountOrderProduct orderProduct in order.AccountOrderProduct)
            {
                ProductQuantity quantity = 
                    mainContext.ProductQuantity.FirstOrDefault(p =>
                        p.ProductId == orderProduct.ProductId &&
                        p.ColorId == orderProduct.ColorId &&
                        p.SizeId == orderProduct.SizeId);

                if (quantity != null)
                {
                    quantity.Count = quantity.Count - orderProduct.Count;
                    mainContext.ProductQuantity.Update(quantity);
                    mainContext.ProductQuantity.Save();

                    bool hasQuantity = mainContext.ProductQuantity.Any(p =>
                        p.ProductId == orderProduct.ProductId &&
                        p.Count > 0);

                    if (hasQuantity == false)
                    {
                        Product product = mainContext.Product.GetById(orderProduct.ProductId);
                        product.StatusId = mainContext.Code.GetIdByLabel(Enum_Code.PRODUCT_STATUS_NOT_AVAILABLE);
                        mainContext.Product.Update(product);
                    }
                }
                else
                {
                    Product product = mainContext.Product.GetById(orderProduct.ProductId);
                    if (product.Quantity != null)
                    {
                        product.Quantity = product.Quantity - orderProduct.Count;
                        if (product.Quantity <= 0)
                        {
                            product.StatusId = mainContext.Code.GetIdByLabel(Enum_Code.PRODUCT_STATUS_NOT_AVAILABLE);
                            mainContext.Product.Update(product);
                        }
                    }
                }
            }
            Save();

            ViewWebsite website = BaseWebsite.ShopWebsite;
            string emailBody = getOrderEmail(order);
            try
            {
                StringBuilder str_1 = new StringBuilder();
                string token_1 = payment.RefNumber;
                string token_2 = "";
                string token_3 = "";
                str_1.AppendLine("پرداخت شما در سایت " + website.Title + " با موفقیت انجام شد");
                str_1.AppendLine("کد رهگیری پرداخت: " + token_1);
                mainContext.Sms.SaveNewSms(payment.Account.Mobile, Enum_SmsType.PAYMENT_SUCCESS, str_1.ToString(), token_1, token_2, token_3);
                mainContext.Email.SaveNewEmail(payment.Account.Email, Enum_EmailType.PAYMENT_SUCCESS, emailBody, "پرداخت موفقیت آمیز");
                Save();
            }
            catch (Exception) { }

            try
            {
                StringBuilder str_2 = new StringBuilder();
                string token_1 = orderId.ToPersian();
                string token_2 = price.GetCurrencyFormat().ToPersian();
                string token_3 = "";
                str_2.AppendLine("سفارش جدید با کد " + token_1 + " مبلغ " + token_2 + " تومان در سایت " + website.Title + " ثبت شد");
                List<SiteUser> listUser = mainContext.SiteUser.GetAll();
                foreach (SiteUser item in listUser.Where(p => p.Mobile != null))
                {
                    mainContext.Sms.SaveNewSms(item.Mobile, Enum_SmsType.PAYMENT_SUCCESS_ADMIN, str_2.ToString(), token_1, token_2, token_3);
                    mainContext.Email.SaveNewEmail(item.Email, Enum_EmailType.PAYMENT_SUCCESS_ADMIN, emailBody, "خرید موفقیت آمیز");
                }
            }
            catch (Exception) { }

            Save();
        }

        private string getOrderEmail(AccountOrder order)
        {
            StringBuilder html = new StringBuilder();
            try
            {
                html.Append("<b>شماره فاکتور: </b>" + order.ID + "<br />");
                html.Append("<b>تاریخ فاکتور: </b>" + order.Datetime.ToPersianComplete() + order.Datetime.ToString("HH:mm") + "<br />");
                html.Append("<b>وضعیت فاکتور: </b>" + order.Code.Name + "<br />");
                html.Append("<hr />");

                html.Append("<b>خریدار: </b>" + order.Account.FullName + "&nbsp;&nbsp;&nbsp;");
                html.Append("<b>شماره تماس: </b>" + order.Account.Mobile + "&nbsp;&nbsp;&nbsp;");
                html.Append("<b>آدرس: </b>" + order.AccountAddress.AddressValue + "<br />");
                html.Append("<b>شماره تلفن: </b>" + order.AccountAddress.Phone + "&nbsp;&nbsp;&nbsp;");
                html.Append("<b>تلفن همراه: </b>" + order.AccountAddress.Mobile + "&nbsp;&nbsp;&nbsp;");
                html.Append("<b>کدپستی: </b>" + order.AccountAddress.PostalCode + "&nbsp;&nbsp;&nbsp;");
                html.Append("<b>نام تحویل گیرنده: </b>" + order.AccountAddress.NameFamily);
                html.Append("<hr />");

                string payment_status = Enum_Code.PAYMENT_STATUS_SUCCESSFUL.ToString();
                PaymentProductOrder paymentOrder = order.PaymentProductOrder.FirstOrDefault(p =>
                    p.Payment.Code.Label == payment_status
                );
                if (paymentOrder != null)
                {
                    Payment payment = paymentOrder.Payment;
                    html.Append("<b>وضعیت پرداخت: </b>" + payment.Code.Name + "&nbsp;&nbsp;&nbsp;");
                    html.Append("<b>بانک مرجع: </b>" + payment.Merchant.Bank.Name + "&nbsp;&nbsp;&nbsp;");
                    html.Append("<b>کد رهگیری پرداخت: </b>" + payment.RefNumber);
                    html.Append("<hr />");
                }

                html.Append("<table cellpadding='5' cellspacing='1' style='width: 100%; border:1px solid black; text-align: center; font-family:\'b nazanin\''>");
                html.Append("<thead>");
                html.Append("<tr>");
                html.Append("<th style='border: 1px solid black;'>#</th>");
                html.Append("<th style='border: 1px solid black;'>نام کالا</th>");
                html.Append("<th style='border: 1px solid black;'>تعداد</th>");
                html.Append("<th style='border: 1px solid black;'>مبلغ واحد (تومان)</th>");
                html.Append("<th style='border: 1px solid black;'>درصد تخفیف</th>");
                html.Append("<th style='border: 1px solid black;'>مبلغ با تخفیف</th>");
                html.Append("<th style='border: 1px solid black;'>مبلغ نهایی (تومان)</th>");
                html.Append("</tr>");
                html.Append("</thead>");

                html.Append("<tbody>");

                int index = 1;
                foreach (AccountOrderProduct product in order.AccountOrderProduct)
                {
                    html.Append("<tr>");
                    html.Append("<td style='border: 1px solid black;'>" + index.ToPersian() + "</td>");
                    html.Append("<td style='border: 1px solid black;'>");
                    html.Append(product.Product.Name);
                    if (product.ColorId != null)
                        html.Append("<br /><span>رنگ: </span>" + product.Color.Name);
                    if (product.SizeId != null)
                        html.Append("<br /><span>سایز: </span>" + product.Size.Name);
                    html.Append("</td>");
                    html.Append("<td style='border: 1px solid black;'>" + product.Count.ToPersian() + " </td>");
                    html.Append("<td style='border: 1px solid black;'>" + product.ProductPrice.GetCurrencyFormat().ToPersian() + " تومان</td>");

                    if (product.ProductDiscount != 0)
                    {
                        html.Append("<td style='border: 1px solid black;'>" + ((product.ProductDiscount * 100) / product.ProductPrice).ToPersian() + "%</td>");
                    }
                    else
                    {
                        html.Append("<td style='border: 1px solid black;'>-</td>");
                    }

                    html.Append("<td style='border: 1px solid black;'>" + ((product.ProductPrice - product.ProductDiscount).GetCurrencyFormat().ToPersian()) + "تومان</td>");
                    html.Append("<td style='border: 1px solid black;'>" + ((product.Price).GetCurrencyFormat().ToPersian()) + "تومان </td>");
                    html.Append("<tr>");
                    index++;
                }
                html.Append("</tbody>");
                html.Append("<tfoot>");
                if (order.SendTypeId != null)
                {
                    html.Append("<tr>");
                    html.Append("<td style='border: 1px solid black;' colspan='6'>هزینه ارسال و بسته بندی (" + order.SendType.Name + ")</td>");
                    html.Append("<td style='border: 1px solid black;'>" + order.SendPrice.GetCurrencyFormat().ToPersian() + " تومان</td>");
                    html.Append("</tr>");
                }
                if (order.DiscountPrice != 0)
                {
                    html.Append("<tr>");
                    html.Append("<td style='border: 1px solid black;' colspan='6'>میزان تخفیف سایت</td>");
                    html.Append("<td style='border: 1px solid black;'>" + order.DiscountPrice.GetCurrencyFormat().ToPersian() + " تومان</td>");
                    html.Append("</tr>");
                }
                if (order.RebateId != null)
                {
                    html.Append("<tr>");
                    html.Append("<td style='border: 1px solid black;' colspan='6'>کد تخفیف (" + order.Rebate.Name + ")</td>");
                    html.Append("<td style='border: 1px solid black;'>" + (order.RebatePrice.GetCurrencyFormat().ToPersian()) + " تومان</td>");
                    html.Append("</tr>");
                }
                html.Append("<tr>");
                html.Append("<td style='border: 1px solid black;' colspan='6'>جمع</td>");
                html.Append("<td style='border: 1px solid black;'>" + order.Price.GetCurrencyFormat().ToPersian() + " تومان</td>");
                html.Append("</tr>");
                html.Append("</tfoot>");
                html.Append("</table>");
            }
            catch (Exception) { }
            return html.ToString();
        }
    }
}

