﻿using DataLayer.Entities;
using DataLayer.Enumarables;
using DataLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Repositories
{
    public class Entity_WebsiteDomain : BaseRepository<WebsiteDomain>
    {
        DatabaseEntities _context;
        public Entity_WebsiteDomain(DatabaseEntities context) : base(context)
        {
            _context = context;
        }

        public List<WebsiteDomain> GetAllByWebsiteType(Enum_Code type)
        {
            string type_string = type.ToString();
            return _context.WebsiteDomain.Where(p => p.Website.Code.Label == type_string).ToList();
        }

        public bool HasAnyByWebsiteTypeAndDomain(string type, string domain, string key)
        {
            return _context.WebsiteDomain.Any(p => 
                p.Website.Code.Label == type &&
                p.Domain == domain &&
                p.ActivationKey == key);
        }

        public List<WebsiteDomain> GetAllByWebsiteId(int WebsiteId)
        {
            return _context.WebsiteDomain.Where(p => p.WebsiteId == WebsiteId).ToList();
        }

        public WebsiteDomain GetByUrl(Uri url)
        {
            string label = url.Host == "localhost" ? url.Host + ":" + url.Port : url.Host;
            string system_type_shop = Enum_Code.SYSTEM_TYPE_SHOP.ToString();
            string system_type_cms = Enum_Code.SYSTEM_TYPE_CMS.ToString();
            string system_type_website = Enum_Code.SYSTEM_TYPE_WEBSITE.ToString();
            return  _context
                    .WebsiteDomain
                    .FirstOrDefault(p =>
                        (
                            p.Domain == "http://" + label + "/" ||
                            p.Domain == "http://" + label ||
                            p.Domain == "https://" + label + "/" ||
                            p.Domain == "https://" + label
                        ) &&
                        (
                            p.Website.Code.Label == system_type_shop ||
                            p.Website.Code.Label == system_type_cms ||
                            p.Website.Code.Label == system_type_website
                        ));
        }
    }
}
