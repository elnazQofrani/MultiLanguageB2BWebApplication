﻿using Binbin.Linq;
using DataLayer.Base;
using DataLayer.Entities;
using DataLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Repositories
{
    public class Entity_ProductCategory : BaseRepository<ProductCategory>
    {
        private DatabaseEntities _context;
        public Entity_ProductCategory(DatabaseEntities context) : base(context)
        {
            _context = context;
        }

        public ProductCategory GetActiveById(int Id)
        {
            return _context.ProductCategory.FirstOrDefault(p => p.ID == Id && p.Active);
        }
        
        public List<ProductCategory> Search(
            string notId = null, 
            int? typeId = 0, 
            int? pageSize = 10, 
            int? index = 1, 
            string name = null,
            bool? active = true,
            string productTypeLabel = null

            )
        {
            var MyQuery = GetSearchQuery(notId: notId, typeId: typeId, name: name, active: active , productTypeLabel : productTypeLabel);
            int skipValue = pageSize.Value * (index.Value - 1);
            int pageValue = pageSize.Value;
            
            return _context
                .ProductCategory
                .OrderBy(p => p.ShowNumber)
                .ThenBy(p => p.ID)
                .Where(MyQuery)
                .Skip(skipValue)
                .Take(pageValue)
                .ToList();
        }

        public int SearchCount(string notId = null, int? typeId = 0, string name = null, bool? active = true , string productTypeLabel = null)
        {
            var MyQuery = GetSearchQuery(notId: notId, typeId: typeId, name: name, active: active , productTypeLabel : productTypeLabel);
            return _context.ProductCategory.Count(MyQuery);
        }

        private Expression<Func<ProductCategory, bool>> GetSearchQuery(string notId = null, int? typeId = 0, string name = null, bool? active = true ,string productTypeLabel = null)
        {
            var MyQuery = PredicateBuilder.True<ProductCategory>();

            if (notId != null && notId != "0" && notId != "")
            {
                var QueryStr = PredicateBuilder.True<ProductCategory>();
                string[] Split = notId.Split('-');
                foreach (var item in Split)
                {
                    int itemId = item.GetInteger();
                    if (itemId != 0)
                    {
                        QueryStr = QueryStr.And(p =>
                            p.ID != itemId
                        );
                    }
                }
                MyQuery = MyQuery.And(QueryStr);
            }

            if (typeId != null && typeId != 0)
                MyQuery = MyQuery.And(p => p.TypeId == typeId);
            if (productTypeLabel != null)
                MyQuery = MyQuery.And(p => p.ProductType.Label == productTypeLabel);

            if (name != null)
                MyQuery = MyQuery.And(p => p.Name.Contains(name));
            if (active != null)
                MyQuery = MyQuery.And(p => p.Active == active);
            return MyQuery;
        }
        
        public ProductCategory GetByLabel(string label)
        {
            return _context.ProductCategory.FirstOrDefault(p => p.Label == label);
        }
    }
}
