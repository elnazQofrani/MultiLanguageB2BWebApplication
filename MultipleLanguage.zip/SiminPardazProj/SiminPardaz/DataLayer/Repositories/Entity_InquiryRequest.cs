﻿using Binbin.Linq;
using DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Repositories
{
   public class Entity_InquiryRequest : BaseRepository<InquiryRequest>
    {
        private DatabaseEntities _context;
        public Entity_InquiryRequest(DatabaseEntities context) : base(context)
        {
            _context = context;
        }
        public List<InquiryRequest> Search(int idGroup)
        {
       
            var MyQuery = GetSearchQuery(idGroup);
            return _context
                    .InquiryRequest
                    .Where(MyQuery)
                    .OrderBy(p => p.ID)
                    .ToList();
        }

        //public int SearchCount(string CustomerCodeValue = null, string ProductCodeValue = null)
        //{
        //    var MyQuery = GetSearchQuery(CustomerCodeValue, ProductCodeValue);
        //    return _context.InquiryRequest.Count(MyQuery);
        //}

        private Expression<Func<InquiryRequest, bool>> GetSearchQuery(int? idGroup)
        {
            var MyQuery = PredicateBuilder.True<InquiryRequest>();

            if (idGroup != null)
                MyQuery = MyQuery.And(p =>p.InquiryRequestGroupId == idGroup);
                       

            return MyQuery;
        }

        public List<InquiryRequest> GetAllByAccountId(int accountId)
        {
            return _context.InquiryRequest
                .Where(s => s.InquiryRequestGroup.AccountId == accountId)
                .OrderByDescending(s => s.ID)
                .ToList();
        }



        public List<InquiryRequest> GetAllByGroupId(int groupId)
        {
            return _context.InquiryRequest
                .Where(s => s.InquiryRequestGroupId == groupId)
                .OrderByDescending(s => s.ID)
                .ToList();
        }
    }
}
