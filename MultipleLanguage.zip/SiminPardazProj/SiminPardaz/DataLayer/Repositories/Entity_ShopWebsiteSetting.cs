﻿using DataLayer.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Repositories
{
    public class Entity_ShopWebsiteSetting : BaseRepository<ShopWebsiteSetting>
    {
        private DatabaseEntities _context;
        public Entity_ShopWebsiteSetting(DatabaseEntities context) : base(context)
        {
            _context = context;
        }

        public ShopWebsiteSetting GetSettingByWebsiteId(int websiteId)
        {
            return _context.ShopWebsiteSetting.FirstOrDefault(p =>
                p.WebsiteId == websiteId
            );
        }

        public ShopWebsiteSetting GetDefaultValues()
        {
            return new ShopWebsiteSetting()
            {
                HasBrand = false,
                HasColor = false,
                HasCustomFields = true,
                HasDescription = false,
                HasGarranty = false,
                HasLastPrice = false,
                HasMinOrder = false,
                HasPicture = true,
                HasPrice = true,
                HasProductCategory = true,
                HasProductSubCategory = false,
                HasProductType = true,
                HasShop = false,
                HasSize = false,
                HasStatus = true,
                HasSummary = false,
                HasShowHomePage = false,
                HasShowNumber = false,
                MaxShopProductCount = 10000,
                HasDocument = false,
                HasQuantity = false,
                HasQuantityColor = false,
                HasCodeValue = false,
                HasUnit = false,
                HasActive = false,
                HasBasePrice = false,
                HasWeight = false,
                HasTag = false,
                HasPack = false,
                HasExpireDate = false,
                HasName = true,
                HasTitle = false
            };
        }
    }
}
