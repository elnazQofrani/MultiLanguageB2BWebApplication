﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Binbin.Linq;
using DataLayer.Base;
using DataLayer.Entities;
using DataLayer.ViewModels;
using System.Linq.Expressions;
using System.Web;

namespace DataLayer.Repositories
{
   public class Entity_MenuLanguage: BaseRepository<MenuLanguage>
    {

        DatabaseEntities _context;
        public Entity_MenuLanguage(DatabaseEntities context) : base(context)
        {
            _context = context;
        }

    }
}
