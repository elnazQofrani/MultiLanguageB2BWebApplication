﻿using DataLayer.Entities;
using DataLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Repositories
{
    public class Entity_ProductCustomValue : BaseRepository<ProductCustomValue>
    {
        private DatabaseEntities _context;
        public Entity_ProductCustomValue(DatabaseEntities context) : base(context)
        {
            _context = context;
        }

        public List<ProductCustomValue> GetAllByProductId(int productId, bool? editable = null)
        {
            return _context.ProductCustomValue.Where(p =>
                (editable == null || p.ProductCustomField.IsEditable == editable) &&
                p.ProductId == productId
            ).ToList();
        }

        public void DeleteByProductId(int productId, bool? editable = null)
        {
            List<ProductCustomValue> list = GetAllByProductId(productId, editable);
            for (int i = 0; i < list.Count; i++)
            {
                Delete(list[i]);
            }
        }
    }
}
