﻿using DataLayer.Entities;
using DataLayer.Repositories;
using System;
using System.Collections.Generic;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace DataLayer.Entities
{
    public class UnitOfWork : IDisposable
    {
        DatabaseEntities db = new DatabaseEntities();

        private Entity_Account _account;
        private Entity_AccountAddress _accountaddress;
        private Entity_AccountLog _accountlog;
        private Entity_AccountBasket _accountbasket;
        private Entity_AccountPasswordForget _accountpasswordforget;
        private Entity_AccountOrder _order;
        private Entity_AccountOrderProduct _orderproduct;
        private Entity_AccountOrderComment _ordercomment;
        private Entity_WebsiteLanguage _WebsiteLanguage;
        private Entity_Language _Language;
        private Entity_Category _category;
        private Entity_Gallery _gallery;
        private Entity_GalleryPicture _gallerypicture;
        private Entity_GalleryVideo _galleryvideo;

        private Entity_Permission _permission;
        private Entity_Picture _picture;
        private Entity_Post _post;
        private Entity_Banner _banner;
        private Entity_Menu _menu;
        private Entity_CodeGroup _codegroups;
        private Entity_Code _codes;

        private Entity_InquiryRequestGroup _InquiryRequestGroup;
        private Entity_Email _email;
        private Entity_EmailHost _emailhost;
        private Entity_EmailAddress _emailaddress;

        private Entity_EmailType _emailType;
        private Entity_Module _module;

        private Entity_SmsProvider _smsprovider;
        private Entity_SmsSetting _smssetting;
        private Entity_SmsNumber _smsnumber;
        private Entity_SmsType _smstype;
        private Entity_Sms _sms;

        private Entity_Website _website;

        private Entity_Product _product;
        private Entity_ProductType _producttype;
        private Entity_ProductCategory _productcategory;
        private Entity_ProductSubCategory _productsubcategory;
        private Entity_ProductComment _productcomment;
        private Entity_ProductQuantity _productquantity;
        private Entity_ProductCustomField _productcustomfield;
        private Entity_ProductCustomItem _productcustomitem;
        private Entity_ProductCustomValue _productcustomvalue;
        private Entity_ProductColor _productcolor;
        private Entity_ProductSize _productsize;
        private Entity_ProductBrand _productbrand;
        private Entity_ProductLike _productlike;
        private Entity_ProductRate productRate;

        private Entity_Color _color;
        private Entity_Size _size;
        private Entity_Template _template;
        private Entity_ProductPicture _productpicture;
        private Entity_Slider _slider;
        private Entity_Country _country;
        private Entity_State _state;
        private Entity_City _city;
        private Entity_Rebate _rebate;

        private Entity_NewsLetter _newsletter;
        private Entity_NewsletterGroup _newslettergroup;


        private Entity_SiteUser _siteuser;
        private Entity_UserGroup _usergroup;
        private Entity_UserGroupPermission _usergrouppermission;
        private Entity_SiteUserUserGroup _siteuserusergroup;

        private Entity_Discount _discount;
        private Entity_DiscountGroup _discountgroup;
        private Entity_PaymentType _paymenttype;

        private Entity_Unit _unit;
        private Entity_ShopWebsiteSetting _shopwebsitesetting;

        private Entity_SendType _sendtype;
        private Entity_Merchant _merchant;
        private Entity_Bank _bank;
        private Entity_Payment _payment;
        private Entity_PaymentProductOrder _paymentproductorder;
        private Entity_PaymentSubject _paymentsubject;

        private Entity_WebsiteView _websiteview;
        private Entity_WebsiteDomain _websitedomain;
        private Entity_WebsiteDocument _websitedocument;
        private Entity_WebsiteForm _websiteform;
        private Entity_WebsiteFormAccount _WebsiteFormAccount;
        private Entity_WebsiteFormField _WebsiteFormField;
        private Entity_WebsiteContactForm _websitecontactform;

        private Entity_Dashboard _dashboard;
        private Entity_UserGroupDashboard _usergroupdashboard;


        private Entity_CollaborationRequest _CollaborationRequest;


        private Entity_ImportRequest _ImportRequest;

        private Entity_InquiryRequest _InquiryRequest;

        private Entity_AccountInvoice _AccountInvoice;

        private Entity_AccountInvoiceProduct _AccountInvoiceProduct;

        private Entity_AccountViewed _AccountViewed;

        private Entity_MenuLanguage _MenuLanguage;

        private Entity_PostLanguage _PostLanguage;

        public Entity_InquiryRequestGroup InquiryRequestGroup { get { if (_InquiryRequestGroup == null) { _InquiryRequestGroup = new Entity_InquiryRequestGroup(db); } return _InquiryRequestGroup; } }
        public Entity_WebsiteLanguage WebsiteLanguage { get { if (_WebsiteLanguage == null) { _WebsiteLanguage = new Entity_WebsiteLanguage(db); } return _WebsiteLanguage; } }
        public Entity_MenuLanguage MenuLanguage { get { if (_MenuLanguage == null) { _MenuLanguage = new Entity_MenuLanguage(db); } return _MenuLanguage; } }
        public Entity_PostLanguage PostLanguage { get { if (_PostLanguage == null) { _PostLanguage = new Entity_PostLanguage(db); } return _PostLanguage; } }


        

        public Entity_Language Language { get { if (_account == null) { _Language = new Entity_Language(db); } return _Language; } }

        public Entity_Account Account { get { if (_account == null) { _account = new Entity_Account(db); } return _account; } }
        public Entity_EmailType EmailType { get { if (_emailType == null) { _emailType = new Entity_EmailType(db); } return _emailType; } }
        public Entity_AccountAddress AccountAddress { get { if (_accountaddress == null) { _accountaddress = new Entity_AccountAddress(db); } return _accountaddress; } }
        public Entity_AccountLog AccountLog { get { if (_accountlog == null) { _accountlog = new Entity_AccountLog(db); } return _accountlog; } }
        public Entity_AccountPasswordForget AccountPasswordForget { get { if (_accountpasswordforget == null) { _accountpasswordforget = new Entity_AccountPasswordForget(db); } return _accountpasswordforget; } }
        public Entity_AccountOrderComment AccountOrderComment { get { if (_ordercomment == null) { _ordercomment = new Entity_AccountOrderComment(db); } return _ordercomment; } }
        public Entity_Category Category { get { if (_category == null) { _category = new Entity_Category(db); } return _category; } }
        public Entity_Gallery Gallery { get { if (_gallery == null) { _gallery = new Entity_Gallery(db); } return _gallery; } }
        public Entity_GalleryPicture GalleryPicture { get { if (_gallerypicture == null) { _gallerypicture = new Entity_GalleryPicture(db); } return _gallerypicture; } }
        public Entity_GalleryVideo GalleryVideo { get { if (_galleryvideo == null) { _galleryvideo = new Entity_GalleryVideo(db); } return _galleryvideo; } }
        public Entity_Permission Permission { get { if (_permission == null) { _permission = new Entity_Permission(db); } return _permission; } }
        public Entity_Picture Picture { get { if (_picture == null) { _picture = new Entity_Picture(db); } return _picture; } }
        public Entity_Post Post { get { if (_post == null) { _post = new Entity_Post(db); } return _post; } }
        public Entity_Banner Banner { get { if (_banner == null) { _banner = new Entity_Banner(db); } return _banner; } }
        public Entity_Rebate Rebate { get { if (_rebate == null) { _rebate = new Entity_Rebate(db); } return _rebate; } }
        public Entity_SiteUser SiteUser { get { if (_siteuser == null) { _siteuser = new Entity_SiteUser(db); } return _siteuser; } }
        public Entity_UserGroup UserGroup { get { if (_usergroup == null) { _usergroup = new Entity_UserGroup(db); } return _usergroup; } }
        public Entity_UserGroupPermission UserGroupPermission { get { if (_usergrouppermission == null) { _usergrouppermission = new Entity_UserGroupPermission(db); } return _usergrouppermission; } }
        public Entity_SiteUserUserGroup SiteUserUserGroup { get { if (_siteuserusergroup == null) { _siteuserusergroup = new Entity_SiteUserUserGroup(db); } return _siteuserusergroup; } }
        public Entity_Menu Menu { get { if (_menu == null) { _menu = new Entity_Menu(db); } return _menu; } }
        public Entity_CodeGroup CodeGroup { get { if (_codegroups == null) { _codegroups = new Entity_CodeGroup(db); } return _codegroups; } }
        public Entity_Code Code { get { if (_codes == null) { _codes = new Entity_Code(db); } return _codes; } }
        public Entity_EmailAddress EmailAddress { get { if (_emailaddress == null) { _emailaddress = new Entity_EmailAddress(db); } return _emailaddress; } }
        public Entity_EmailHost EmailHost { get { if (_emailhost == null) { _emailhost = new Entity_EmailHost(db); } return _emailhost; } }
        public Entity_Email Email { get { if (_email == null) { _email = new Entity_Email(db); } return _email; } }
        public Entity_WebsiteDomain WebsiteDomain { get { if (_websitedomain == null) { _websitedomain = new Entity_WebsiteDomain(db); } return _websitedomain; } }
        public Entity_Module Module { get { if (_module == null) { _module = new Entity_Module(db); } return _module; } }

        public Entity_Sms Sms { get { if (_sms == null) { _sms = new Entity_Sms(db); } return _sms; } }
        public Entity_SmsNumber SmsNumber { get { if (_smsnumber == null) { _smsnumber = new Entity_SmsNumber(db); } return _smsnumber; } }
        public Entity_SmsProvider SmsProvider { get { if (_smsprovider == null) { _smsprovider = new Entity_SmsProvider(db); } return _smsprovider; } }
        public Entity_SmsSetting SmsSetting { get { if (_smssetting == null) { _smssetting = new Entity_SmsSetting(db); } return _smssetting; } }
        public Entity_SmsType SmsType { get { if (_smstype == null) { _smstype = new Entity_SmsType(db); } return _smstype; } }
        public Entity_Website Website { get { if (_website == null) { _website = new Entity_Website(db); } return _website; } }
        public Entity_Unit Unit { get { if (_unit == null) { _unit = new Entity_Unit(db); } return _unit; } }
        public Entity_Product Product { get { if (_product == null) { _product = new Entity_Product(db); } return _product; } }
        public Entity_ProductComment ProductComment { get { if (_productcomment == null) { _productcomment = new Entity_ProductComment(db); } return _productcomment; } }
        public Entity_ProductQuantity ProductQuantity { get { if (_productquantity == null) { _productquantity = new Entity_ProductQuantity(db); } return _productquantity; } }
        public Entity_ProductType ProductType { get { if (_producttype == null) { _producttype = new Entity_ProductType(db); } return _producttype; } }
        public Entity_ProductCategory ProductCategory { get { if (_productcategory == null) { _productcategory = new Entity_ProductCategory(db); } return _productcategory; } }
        public Entity_ProductSubCategory ProductSubCategory { get { if (_productsubcategory == null) { _productsubcategory = new Entity_ProductSubCategory(db); } return _productsubcategory; } }
        public Entity_ProductCustomField ProductCustomField { get { if (_productcustomfield == null) { _productcustomfield = new Entity_ProductCustomField(db); } return _productcustomfield; } }
        public Entity_ProductCustomItem ProductCustomItem { get { if (_productcustomitem == null) { _productcustomitem = new Entity_ProductCustomItem(db); } return _productcustomitem; } }
        public Entity_ProductCustomValue ProductCustomValue { get { if (_productcustomvalue == null) { _productcustomvalue = new Entity_ProductCustomValue(db); } return _productcustomvalue; } }
        public Entity_ProductBrand ProductBrand { get { if (_productbrand == null) { _productbrand = new Entity_ProductBrand(db); } return _productbrand; } }
        public Entity_SendType SendType { get { if (_sendtype == null) { _sendtype = new Entity_SendType(db); } return _sendtype; } }
        public Entity_ProductColor ProductColor { get { if (_productcolor == null) { _productcolor = new Entity_ProductColor(db); } return _productcolor; } }
        public Entity_ProductSize ProductSize { get { if (_productsize == null) { _productsize = new Entity_ProductSize(db); } return _productsize; } }
        public Entity_Color Color { get { if (_color == null) { _color = new Entity_Color(db); } return _color; } }
        public Entity_Size Size { get { if (_size == null) { _size = new Entity_Size(db); } return _size; } }
        public Entity_Template Template { get { if (_template == null) { _template = new Entity_Template(db); } return _template; } }
        public Entity_ProductPicture ProductPicture { get { if (_productpicture == null) { _productpicture = new Entity_ProductPicture(db); } return _productpicture; } }
        public Entity_Slider Slider { get { if (_slider == null) { _slider = new Entity_Slider(db); } return _slider; } }
        public Entity_Country Country { get { if (_country == null) { _country = new Entity_Country(db); } return _country; } }
        public Entity_State State { get { if (_state == null) { _state = new Entity_State(db); } return _state; } }
        public Entity_City City { get { if (_city == null) { _city = new Entity_City(db); } return _city; } }
        public Entity_ProductLike ProductLike { get { if (_productlike == null) { _productlike = new Entity_ProductLike(db); } return _productlike; } }
        public Entity_ProductRate ProductRate { get { if (productRate == null) { productRate = new Entity_ProductRate(db); } return productRate; } }
        public Entity_NewsLetter NewsLetter { get { if (_newsletter == null) { _newsletter = new Entity_NewsLetter(db); } return _newsletter; } }
        public Entity_NewsletterGroup NewsletterGroup { get { if (_newslettergroup == null) { _newslettergroup = new Entity_NewsletterGroup(db); } return _newslettergroup; } }
        public Entity_DiscountGroup DiscountGroup { get { if (_discountgroup == null) { _discountgroup = new Entity_DiscountGroup(db); } return _discountgroup; } }
        public Entity_Discount Discount { get { if (_discount == null) { _discount = new Entity_Discount(db); } return _discount; } }
        public Entity_PaymentType PaymentType { get { if (_paymenttype == null) { _paymenttype = new Entity_PaymentType(db); } return _paymenttype; } }
        public Entity_ShopWebsiteSetting ShopWebsiteSetting { get { if (_shopwebsitesetting == null) { _shopwebsitesetting = new Entity_ShopWebsiteSetting(db); } return _shopwebsitesetting; } }
        public Entity_AccountBasket AccountBasket { get { if (_accountbasket == null) { _accountbasket = new Entity_AccountBasket(db); } return _accountbasket; } }
        public Entity_AccountOrder AccountOrder { get { if (_order == null) { _order = new Entity_AccountOrder(db); } return _order; } }
        public Entity_AccountOrderProduct AccountOrderProduct { get { if (_orderproduct == null) { _orderproduct = new Entity_AccountOrderProduct(db); } return _orderproduct; } }
        public Entity_Merchant Merchant { get { if (_merchant == null) { _merchant = new Entity_Merchant(db); } return _merchant; } }
        public Entity_Bank Bank { get { if (_bank == null) { _bank = new Entity_Bank(db); } return _bank; } }
        public Entity_Payment Payment { get { if (_payment == null) { _payment = new Entity_Payment(db); } return _payment; } }
        public Entity_PaymentProductOrder PaymentProductOrder { get { if (_paymentproductorder == null) { _paymentproductorder = new Entity_PaymentProductOrder(db); } return _paymentproductorder; } }
        public Entity_PaymentSubject PaymentSubject { get { if (_paymentsubject == null) { _paymentsubject = new Entity_PaymentSubject(db); } return _paymentsubject; } }
        public Entity_WebsiteView WebsiteView { get { if (_websiteview == null) { _websiteview = new Entity_WebsiteView(db); } return _websiteview; } }
        public Entity_WebsiteDocument WebsiteDocument { get { if (_websitedocument == null) { _websitedocument = new Entity_WebsiteDocument(db); } return _websitedocument; } }
        public Entity_WebsiteForm WebsiteForm { get { if (_websiteform == null) { _websiteform = new Entity_WebsiteForm(db); } return _websiteform; } }
        public Entity_WebsiteFormAccount WebsiteFormAccount { get { if (_WebsiteFormAccount == null) { _WebsiteFormAccount = new Entity_WebsiteFormAccount(db); } return _WebsiteFormAccount; } }
        public Entity_WebsiteFormField WebsiteFormField { get { if (_WebsiteFormField == null) { _WebsiteFormField = new Entity_WebsiteFormField(db); } return _WebsiteFormField; } }
        public Entity_WebsiteContactForm WebsiteContactForm { get { if (_websitecontactform == null) { _websitecontactform = new Entity_WebsiteContactForm(db); } return _websitecontactform; } }

        public Entity_Dashboard Dashboard { get { if (_dashboard == null) { _dashboard = new Entity_Dashboard(db); } return _dashboard; } }
        public Entity_UserGroupDashboard UserGroupDashboard { get { if (_usergroupdashboard == null) { _usergroupdashboard = new Entity_UserGroupDashboard(db); } return _usergroupdashboard; } }

        public Entity_CollaborationRequest CollaborationRequest { get { if (_CollaborationRequest == null) { _CollaborationRequest = new Entity_CollaborationRequest(db); } return _CollaborationRequest; } }

        public Entity_ImportRequest ImportRequest { get { if (_ImportRequest == null) { _ImportRequest = new Entity_ImportRequest(db); } return _ImportRequest; } }


        public Entity_InquiryRequest InquiryRequest { get { if (_InquiryRequest == null) { _InquiryRequest = new Entity_InquiryRequest(db); } return _InquiryRequest; } }


        public Entity_AccountInvoice AccountInvoice { get { if (_AccountInvoice == null) { _AccountInvoice = new Entity_AccountInvoice(db); } return _AccountInvoice; } }

        public Entity_AccountInvoiceProduct AccountInvoiceProduct { get { if (_AccountInvoiceProduct == null) { _AccountInvoiceProduct = new Entity_AccountInvoiceProduct(db); } return _AccountInvoiceProduct; } }

        public Entity_AccountViewed AccountViewed { get { if (_AccountViewed == null) { _AccountViewed = new Entity_AccountViewed(db); } return _AccountViewed; } }

        public bool Save()
        {
            try
            {
                int result = db.SaveChanges();
                return true;
            }
            catch (DbEntityValidationException ex)
            {
                string error = ex.Message;
                HttpContext.Current.Response.Redirect("~/error/index/502");
                return false;
            }
            catch (DbUpdateException ex)
            {
                string error = ex.Message;
                //HttpContext.Current.Response.Redirect("~/error/index/501");
                return false;
            }
            catch (SqlException ex)
            {
                HttpContext.Current.Response.Redirect("~/error/index/" + ex.ErrorCode);
                return false;
            }
        }
        public void Dispose() { db.Dispose(); }
    }
}
