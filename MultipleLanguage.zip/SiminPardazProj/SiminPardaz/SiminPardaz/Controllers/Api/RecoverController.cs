﻿using DataLayer.Api;
using DataLayer.Api.Model;
using DataLayer.Entities;
using DataLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Cms.Controllers.Api
{
    public class RecoverController : ApiController
    {
        UnitOfWork _context = new UnitOfWork();

        [HttpPost]
        public ApiResult Post(Account account)
        {
            return ApiAccountPasswordForget.Post(_context, account);
        }

        [HttpPut]
        public ApiResult Put(string recoverValue)
        {
            ApiResult result = ApiAccountPasswordForget.Put(_context, recoverValue);
            if (result.Code == ApiResult.ResponseCode.Success)
                _context.Account.SetCurrentAccount((ViewAccount)result.Value, "", false);
            return result;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _context.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
