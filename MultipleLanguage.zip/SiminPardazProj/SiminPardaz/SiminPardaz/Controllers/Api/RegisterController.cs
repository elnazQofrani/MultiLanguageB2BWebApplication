﻿using DataLayer.Api;
using DataLayer.Api.Model;
using DataLayer.Base;
using DataLayer.Entities;
using DataLayer.Enumarables;
using DataLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;

namespace Cms.Controllers.Api
{
    public class RegisterController : ApiController
    {
        UnitOfWork _context = new UnitOfWork();

        [HttpPost]
        public ApiResult Post(Account account, bool remember = false, string confirm = "")
        {
            string password = account.Password;
            ApiResult result = ApiAccount.Post_DoRegister(_context, account, true, confirm);
            if (result.Code == ApiResult.ResponseCode.Success)
            {
                _context.Account.SetCurrentAccount((ViewAccount)result.Value, password, remember);
            }
            return result;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _context.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
