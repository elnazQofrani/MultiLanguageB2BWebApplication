﻿using DataLayer.Api;
using DataLayer.Api.Model;
using DataLayer.Entities;
using DataLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Cms.Controllers.Api
{
    public class AccountController : ApiController
    {
        UnitOfWork _context = new UnitOfWork();

        [HttpPut]
        public ApiResult Put(ViewAccount account)
        {
            ApiResult result = new ApiResult();
            ViewAccount currentAccount = _context.Account.GetCurrentAccount();
            if (currentAccount == null)
                return ApiResponse.CreateInvalidKeyResult();
            account.Id = currentAccount.Id;
            result = ApiAccount.Put_Account(_context, account, account.Id);
            if (result.Code == ApiResult.ResponseCode.Success)
                _context.Account.SetCurrentAccount((ViewAccount)result.Value, currentAccount.Password, true);
            return result;
        }

        [HttpGet]
        public ApiResult Get()
        {
            ViewAccount currentAccount = _context.Account.GetCurrentAccount();
            if (currentAccount == null)
                return ApiResponse.CreateInvalidKeyResult();
            return ApiResponse.CreateSuccessResult(currentAccount);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _context.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
