﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net;
using DataLayer.Repositories;
using DataLayer.Base;
using DataLayer.Entities;
using DataLayer.Enumarables;
using System.Text.RegularExpressions;
using System.Text;
using System.Web.Configuration;
using System.Dynamic;

namespace SiminPardaz.Controllers
{
    public class HomeController : Controller
    {
        private UnitOfWork _context = new UnitOfWork();
        
        public ActionResult Index()
        {
            string fullUrl = Request.Url.Host;
            string wildcardDomain = BaseWebsite.WildCardDomain;
            if (wildcardDomain != null && wildcardDomain != "")
            {
                string[] domains = fullUrl.Split(new char[] { '.' });
                if (domains.Length > 1)
                {
                    string subDomain = domains[0];
                    Uri newUrl = new Uri(wildcardDomain.Replace("*", subDomain));
                    if (newUrl.Host == fullUrl)
                    {
                       ProductBrand brand = _context.ProductBrand.GetByLabel(subDomain);
                       if (brand != null)
                       {
                            return PartialView("~/Views/" + BaseWebsite.WebsiteLabel + "/ProductBrand/Index.cshtml", brand);
                       }
                    }
                }
            }
            return PartialView(BaseController.GetView(this));
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _context.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}