﻿using DataLayer.Entities;
using DataLayer.Enumarables;
using DataLayer.ViewModels;
using DataLayer.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using DataLayer.Api;

namespace SiminPardaz.Controllers
{
    public class ProductController : Controller
    {
        UnitOfWork _context = new UnitOfWork();

        public ActionResult Index(int? prid, string pridname = "")
        {
            Product product = _context.Product.GetById(prid);
            if (product == null || product.Active == false)
                return Redirect("/error/404");
            else if (product.ProductTypeId != null && product.ProductType.Active == false)
                return Redirect("/error/404");
            else if (product.ProductCategoryId != null && product.ProductCategory.Active == false)
                return Redirect("/error/404");
            else if (product.ProductSubCategoryId != null && product.ProductSubCategory.Active == false)
                return Redirect("/error/404");
            else if (product.Name.StandardUrl() != pridname)
                return Redirect(product.GetLink());
            product.VisitCount = product.VisitCount + 1;
            _context.Product.Update(product);
            _context.Save();

            _context.Product.AddTrackingCookie(product);
                
            ViewAccount CurrentAccount = _context.Account.GetCurrentAccount();
            ViewBag.CurrentAccount = CurrentAccount;
            ViewBag.IndexProductTypeId = product.ProductTypeId;

            return BaseController.GetView(this, Enum_ResultType.RESULT_TYPE_VIEWNAME, null, product);
        }

        public ActionResult Search(
            string prIds = null,
            int? prnotId = null,
            string prtypeId = null,
            string prcategoryId = null,
            string prsubCategoryId = null,
            int? prindex = null,
            int? prpageSize = null,
            int? prpricefrom = null,
            int? prpriceto = null,
            int? prheightfrom = null,
            int? prheightto = null,
            int? printernalfrom = null,
            int? printernalto = null,
            int? prexternalfrom = null,
            int? prexternalto = null,
            string prbrandId = null,
            string prname = null,
            string prtitle = null,
            string prdiscount = null,
            string prviewName = null, 
            string prcustom = null,
            string prcustomlabel = null,
            string prcolor = null,
            string prsize = null,
            string practive = "true",
            string prstatus = null,
            bool? prshowhome = null,
            string prcategorylabel = null,
            bool customRoute = false,
            Enum_ProductOrder prorder = Enum_ProductOrder.NONE,
            Enum_ProductOutput proutput = Enum_ProductOutput.ENTITY,
            Enum_ResultType prresultType = Enum_ResultType.RESULT_TYPE_VIEWNAME)
        {
            prpageSize = prpageSize == null ? 10 : prpageSize;
            prindex = prindex == null ? 1 : prindex;
            prviewName = prviewName == null ? "Search" : prviewName;
            prname = prname == null ? null : prname.GetEnglish();
            List<Product> results = _context.Product.Search(
                Id: prIds,
                notId: prnotId,
                typeId: prtypeId,
                categoryId: prcategoryId,
                subCategoryId: prsubCategoryId,
                brandId: prbrandId,
                index: prindex.Value,
                pageSize: prpageSize.Value,
                title: prtitle,
                name: prname,
                order: prorder,
                discount: prdiscount,
                pricefrom: prpricefrom,
                priceto: prpriceto,
                heightfrom: prheightfrom,
                heightto: prheightto,
                internalfrom: printernalfrom,
                internalto: printernalto,
                externalfrom: prexternalfrom,
                externalto: prexternalto,
                custom: prcustom,
                customlabel: prcustomlabel,
                sizeId: prsize,
                colorId: prcolor,
                active: practive,
                status: prstatus,
                showHome: prshowhome,
                categorylabel: prcategorylabel);

            object model = null;
            if (proutput == Enum_ProductOutput.SEARCH || proutput == Enum_ProductOutput.COLOR)
            {
                ViewBag.CurrentAccount = _context.Account.GetCurrentAccount();
                ViewSearchProduct search = new ViewSearchProduct()
                {
                    TotalCount = _context.Product.SearchCount(
                        Id: prIds,
                        notId: prnotId,
                        typeId: prtypeId,
                        categoryId: prcategoryId,
                        subCategoryId: prsubCategoryId,
                        brandId: prbrandId,
                        name: prname,
                        discount: prdiscount,
                        pricefrom: prpricefrom,
                        priceto: prpriceto,
                        heightfrom: prheightfrom,
                        heightto: prheightto,
                        internalfrom: printernalfrom,
                        internalto: printernalto,
                        externalfrom: prexternalfrom,
                        externalto: prexternalto,
                        custom: prcustom,
                        customlabel: prcustomlabel,
                        categorylabel: prcategorylabel,
                        colorId: prcolor,
                        sizeId: prsize,
                        active: practive,
                        status: prstatus),
                    PageIndex = prindex.Value,
                    PageSize = prpageSize.Value
                };

                if (proutput == Enum_ProductOutput.SEARCH)
                {
                    search.Results = results;
                }
                else if (proutput == Enum_ProductOutput.COLOR)
                {
                    search.ColorResults = results.ToViewSearchColor();
                }

                prtypeId = prtypeId != null && prtypeId.EndsWith("-") ? prtypeId.Substring(0, prtypeId.Length - 1) : prtypeId;
                prcategoryId = prcategoryId != null && prcategoryId.EndsWith("-") ? prcategoryId.Substring(0, prcategoryId.Length - 1) : prcategoryId;
                prsubCategoryId = prsubCategoryId != null && prsubCategoryId.EndsWith("-") ? prsubCategoryId.Substring(0, prsubCategoryId.Length - 1) : prsubCategoryId;
                prbrandId = prbrandId != null && prbrandId.EndsWith("-") ? prbrandId.Substring(0, prbrandId.Length - 1) : prbrandId;

                if (IsNullOrEmpty(prname) == false)
                {
                    search.Type = Enum_SearchType.NAME;
                    search.Name = prname;
                }
                if (IsNullOrEmpty(prtypeId) == false)
                {
                    search.Type = Enum_SearchType.PRODUCTTYPE;
                    if (prtypeId.Contains("-") == false)
                    {
                        search.ProductType = _context.ProductType.GetActiveById(prtypeId.GetInteger());
                        if (search.ProductType == null)
                            return Redirect("/error/404");
                    }
                }
                if (IsNullOrEmpty(prbrandId) == false)
                {
                    search.Type = Enum_SearchType.PRODUCTBRAND;
                    if (prbrandId.Contains("-") == false)
                    {
                        if (prbrandId.IsInteger())
                            search.ProductBrand = _context.ProductBrand.GetActiveById(prbrandId.GetInteger());
                        else
                            search.ProductBrand = _context.ProductBrand.GetActiveByLabel(prbrandId);
                        if (search.ProductBrand == null)
                            return Redirect("/error/404");
                    }
                }
                if (IsNullOrEmpty(prcategoryId) == false)
                {
                    search.Type = Enum_SearchType.PRODUCTCATEGORY;
                    if (prcategoryId.Contains("-") == false)
                    {
                        search.ProductCategory = _context.ProductCategory.GetActiveById(prcategoryId.GetInteger());
                        if (search.ProductCategory == null)
                            return Redirect("/error/404");
                    }
                }
                if (IsNullOrEmpty(prsubCategoryId) == false)
                {
                    search.Type = Enum_SearchType.PRODUCTSUBCATEGORY;
                    if (prsubCategoryId.Contains("-") == false)
                    {
                        search.ProductSubCategory = _context.ProductSubCategory.GetActiveById(prsubCategoryId.GetInteger());
                        if (search.ProductSubCategory == null)
                            return Redirect("/error/404");
                    }
                }
                if (IsNullOrEmpty(prcustomlabel) == false)
                {
                    search.Type = Enum_SearchType.PRODUCTCUSTOMITEM;
                    search.ProductCustomItem = _context.ProductCustomItem.GetByLabel(prcustomlabel);
                    if (search.ProductCustomItem == null)
                        return Redirect("/error/404");
                }

                if (string.IsNullOrEmpty(prcategorylabel) == false && 
                    search.ProductType == null &&
                    search.ProductCategory == null &&
                    search.ProductSubCategory == null)
                {
                    ProductType productType = _context.ProductType.GetByLabel(prcategorylabel);
                    if (productType != null)
                    {
                        search.Type = Enum_SearchType.PRODUCTTYPE;
                        search.ProductType = productType;
                    }
                    else
                    {
                        ProductCategory productCategory = _context.ProductCategory.GetByLabel(prcategorylabel);
                        if (productCategory != null)
                        {
                            search.Type = Enum_SearchType.PRODUCTCATEGORY;
                            search.ProductCategory = productCategory;
                        }
                        else
                        {
                            ProductSubCategory productSubCategory = _context.ProductSubCategory.GetByLabel(prcategorylabel);
                            if (productSubCategory != null)
                            {
                                search.Type = Enum_SearchType.PRODUCTSUBCATEGORY;
                                search.ProductSubCategory = productSubCategory;
                            }
                        }
                    }                    
                }

                model = search;
            }
            else if (proutput == Enum_ProductOutput.ENTITY)
            {
                model = results;
            }
            else if (proutput == Enum_ProductOutput.VIEWMODEL)
            {
                model = results.ToView();
            }
            else if (proutput == Enum_ProductOutput.JSON)
            {
                model = results.ToView();
                return new JsonResult() {
                    Data = model,
                    JsonRequestBehavior = JsonRequestBehavior.AllowGet
                };
            }

            return BaseController.GetView(this, prresultType, prviewName, model);
        }

        private bool IsNullOrEmpty(string value)
        {
            bool result = false;
            if (value == null)
                result = true;
            else if (value == "0")
                result = true;
            else if (value == "")
                result = true;
            else if (value == "null")
                result = true;
            return result;
        }

        public ActionResult Like(int ProductId, string Function)
        {
            Product product = _context.Product.GetById(ProductId);
            ViewAccount CurrentUser = _context.Account.GetCurrentAccount();
            if (CurrentUser != null)
            {
                if (Function == "ADD")
                {
                    ProductLike like = new ProductLike() {
                        AccountId = CurrentUser.Id,
                        ProductId = ProductId,
                        Datetime = DateTime.Now
                    };
                    _context.ProductLike.Insert(like);
                }
                else
                {
                    ProductLike like = _context.ProductLike.GetByProductIdAndAccountId(ProductId, CurrentUser.Id);
                    _context.ProductLike.Delete(like);
                }
                _context.Save();

                return RedirectToAction("index", new { prid = ProductId, prname = BaseUrl.StandardUrl(product.Name) });
            }
            else
            {
                return RedirectToAction("login", "Account", new { back = product.GetLink() });
            }
        }

        [Route("compare/{productid_1?}/{productid_2?}/{productid_3?}/{productid_4?}/{productid_5?}/{productid_6?}")]
        public ActionResult Compare(int? productid_1 = null, int? productid_2 = null, int? productid_3 = null, int? productid_4 = null, int? productid_5 = null, int? productid_6 = null)
        {
            List<Product> list = new List<Product>();
            if (productid_1 != null)
                list.Add(_context.Product.GetById(productid_1));
            if (productid_2 != null)
                list.Add(_context.Product.GetById(productid_2));
            if (productid_3 != null)
                list.Add(_context.Product.GetById(productid_3));
            if (productid_4 != null)
                list.Add(_context.Product.GetById(productid_4));
            if (productid_5 != null)
                list.Add(_context.Product.GetById(productid_5));
            if (productid_6 != null)
                list.Add(_context.Product.GetById(productid_6));

            List<ProductCustomField> listField = new List<ProductCustomField>();
            if (list.Any())
            {
                Product firstProduct = list.FirstOrDefault();
                listField = _context.ProductCustomField.Search(
                    typeId: firstProduct.ProductTypeId, 
                    categoryId: firstProduct.ProductCategoryId,
                    subcategoryId: firstProduct.ProductSubCategoryId,
                    brandId: firstProduct.BrandId,
                    pageSize: 100);
            }

            ViewCompare entity = new ViewCompare()
            {
                Products = list,
                Fields = listField
            };

            return BaseController.GetView(this, Enum_ResultType.RESULT_TYPE_VIEWNAME, null, entity);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _context.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}