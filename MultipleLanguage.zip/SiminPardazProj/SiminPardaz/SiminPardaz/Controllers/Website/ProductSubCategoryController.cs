﻿using DataLayer.Entities;
using DataLayer.Enumarables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SiminPardaz.Controllers
{
    public class ProductSubCategoryController : Controller
    {
        UnitOfWork _context = new UnitOfWork();

        public ActionResult Search(
            string pscategoryId = null, 
            int? psnotId = null, 
            int? psindex = null, 
            int? pspageSize = null, 
            string psname = null, 
            string psviewName = null)
        {
            List<ProductSubCategory> results = new List<ProductSubCategory>();
            pspageSize = pspageSize == null ? 10 : pspageSize;
            psindex = psindex == null ? 1 : psindex;

            results = _context
                .ProductSubCategory.Search(
                    categoryId: pscategoryId, 
                    notId: psnotId, 
                    name: psname, 
                    index: psindex, 
                    pageSize: pspageSize);

            return BaseController.GetView(this, Enum_ResultType.RESULT_TYPE_VIEWNAME, psviewName, results);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _context.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}