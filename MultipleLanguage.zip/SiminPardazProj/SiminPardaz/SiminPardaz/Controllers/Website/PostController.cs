﻿using DataLayer.Entities;
using DataLayer.Enumarables;
using DataLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SiminPardaz.Controllers
{
    public class PostController : Controller
    {
        UnitOfWork _context = new UnitOfWork();

        public ActionResult Index(int? poid, string poidname = "")
        {
            Post post = _context.Post.GetById(poid);
            post.VisitCount = post.VisitCount + 1;
            _context.Post.Update(post);
            _context.Save();
            ViewBag.CurrentAccount = _context.Account.GetCurrentAccount();
            return PartialView(BaseController.GetView(this), post);
        }

        public ActionResult SearchCategory(
            int? ponotId = null,
            string poidlabel = null, 
            string poviewName = null, 
            int? poIndex = null, 
            int? poSize = null)
        {
            poIndex = poIndex != null ? poIndex.Value : 1;
            poSize = poSize != null ? poSize.Value : 10;
            poviewName = poviewName == null ? "SearchCategory" : poviewName;

            List<Post> results = _context.Post.Search(
                notId: ponotId,
                categoryLabel: poidlabel,
                index: poIndex.Value,
                pageSize: poSize.Value,
                order: Enum_PostOrder.NEW);

            ViewSearchPost search = new ViewSearchPost()
            {
                TotalCount = _context.Post.SearchCount(categoryLabel: poidlabel),
                Category = _context.Category.FirstOrDefault(p => p.Label == poidlabel),
                PageIndex = poIndex.Value,
                PageSize = poSize.Value,
                Results = results
            };

            return BaseController.GetView(this, Enum_ResultType.RESULT_TYPE_VIEWNAME, poidlabel, search);
        }

        public ActionResult Search(
            int? ponotId = null,
            int? websiteId = null,
            string pocategory = null,
            int? pocategoryId = null, 
            int? poIndex = null, 
            int? poSize = null, 
            string poviewName = null,
            Enum_PostOrder poorder = Enum_PostOrder.NONE,
            Enum_PostOutput pooutput = Enum_PostOutput.ENTITY)
        {
            poIndex = poIndex != null ? poIndex.Value : 1;
            poSize = poSize != null ? poSize.Value : 10;
            poviewName = poviewName == null ? "Search" : poviewName;
            List<Post> results = _context.Post.Search(
                notId: ponotId,
                websiteId: websiteId,
                categoryId: pocategoryId,
                categoryLabel: pocategory,
                index: poIndex.Value,
                pageSize: poSize.Value,
                order: poorder);
            
            return BaseController.GetView(this, Enum_ResultType.RESULT_TYPE_VIEWNAME, poviewName, results);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _context.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}