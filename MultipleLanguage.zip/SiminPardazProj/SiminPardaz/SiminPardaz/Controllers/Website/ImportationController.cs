﻿using DataLayer.Entities;
using DataLayer.ViewModels;
using DataLayer.Enumarables;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SiminPardaz.Controllers.Website
{
    public class ImportationController : Controller
    {
        UnitOfWork _context = new UnitOfWork();

        public ActionResult Index()
        {   
            ViewBag.CommercialStatus = _context.Code.GetAllByCodeGroup(Enum_CodeGroup.COMMERCIAL_STATUS);
            ViewBag.StoreStatus = _context.Code.GetAllByCodeGroup(Enum_CodeGroup.STORE_STATUS);
            return PartialView(BaseController.GetView(this));
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _context.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}