﻿using DataLayer.Base;
using DataLayer.Entities;
using DataLayer.Enumarables;
using DataLayer.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SiminPardaz.Controllers
{
    public class InquiryController : Controller
    {
        UnitOfWork _context = new UnitOfWork();

        public ActionResult Index(string id = null)
        {
            ViewAccount currentAccount = _context.Account.GetCurrentAccount();
            if (currentAccount == null)
                return RedirectToAction("login", "account", new { back = "/inquiry/index/" + id });
            if (string.IsNullOrEmpty(id) == false)
            {
                Product product = _context.Product.GetById(id.GetInteger());
                if (product != null)
                {
                    ViewBag.CodeValue = product.CodeValue;
                }
            }

            ViewBag.StoreStatus = _context.Code.GetAllByCodeGroup(Enum_CodeGroup.STORE_STATUS);

            return PartialView(BaseController.GetView(this));
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _context.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}