﻿using DataLayer.Base;
using DataLayer.Api;
using DataLayer.Api.Model;
using DataLayer.Entities;
using DataLayer.Enumarables;
using DataLayer.ViewModels;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SiminPardaz.Controllers
{
    public class BasketController : Controller
    {
        private UnitOfWork _context = new UnitOfWork();

        public ActionResult Index()
        {
            ViewAccount account = _context.Account.GetCurrentAccount();
            List<AccountBasket> list = new List<AccountBasket>();
            ViewBag.SendType = _context.SendType.GetAllActive();

            if (account != null)
                list = _context.AccountBasket.GetAllByAccount(account.Id);
            else
                list = _context.AccountBasket.GetAllFromCookie();

            return PartialView(BaseController.GetView(this), list);
        }

        public ActionResult Search(string bsviewname = null)
        {
            ViewAccount account = _context.Account.GetCurrentAccount();
            List<AccountBasket> listBasket = new List<AccountBasket>();
            if (account != null)
                listBasket = _context.AccountBasket.GetAllByAccount(account.Id);
            else
                listBasket = _context.AccountBasket.GetAllFromCookie();
            return PartialView(BaseController.GetView(this, bsviewname), listBasket);
        }

        public ActionResult Address(int id)
        {
            ViewAccount account = _context.Account.GetCurrentAccount();
            if (account == null)
                return RedirectToAction("login", new { controller = "account", back = "basket/address/" + id });

            ViewBag.SendType = _context.SendType.GetAllActive();
            ViewBag.StateId = _context.State.GetAll();
            AccountOrder order = _context.AccountOrder.GetById(id);
            if (order.AccountId != account.Id)
                return Redirect("/");

            ViewBag.OrderId = order.ID;
            return PartialView(BaseController.GetView(this), order);
        }
        
        [HttpPost]
        public ActionResult SaveAddress(int orderId, int? addressId = null, int? sendTypeId = null, string nextLevel = "")
        {
            ViewAccount account = _context.Account.GetCurrentAccount();
            if (account == null)
                return RedirectToAction("login", new { controller = "account", back = "basket/address/" + orderId });
            else if (addressId == 0 || addressId == null)
                return RedirectToAction("address", new { controller = "basket", id = orderId, error = "required" });

            AccountOrder order = _context.AccountOrder.GetById(orderId);
            order.AddressId = addressId;
            order.StatusId = _context.Code.GetIdByLabel(Enum_Code.ORDER_STATUS_ADDRESS);
            if (sendTypeId != null)
            {
                SendType sendType = null;
                int sendPrice = 0;
                if (sendTypeId != null)
                {
                    sendType = _context.SendType.GetById(sendTypeId);
                    sendPrice = sendType.GetPrice(order);
                }
                order.SendTypeId = sendTypeId;
                order.SendPrice = sendPrice;
                order.Price = order.AccountOrderProduct.Sum(p => p.Price) + sendPrice;
            }
            _context.AccountOrder.Update(order);
            _context.Save();
            return RedirectToAction(nextLevel, new { id = order.ID });
        }

        public ActionResult Confirm(int id)
        {
            ViewAccount account = _context.Account.GetCurrentAccount();
            if (account == null)
                return RedirectToAction("login", new { controller = "account", back = "basket/confirm/" + id });
            AccountOrder order = _context.AccountOrder.GetById(id);
            if (account.Id != order.AccountId)
                return Redirect("/");

            ViewBag.OrderId = order.ID;
            ViewBag.Merchant = _context.Merchant.GetAllActive();
            ViewBag.PaymentType = _context.PaymentType.GetAllActive();
            return PartialView(BaseController.GetView(this), order);
        }
        
        [HttpPost]
        public ActionResult Add(int productId, string backurl = null)
        {
            ViewAccount account = _context.Account.GetCurrentAccount();
            if (account == null)
            {
                return RedirectToAction("login", "account", new { back = backurl });
            }
            else
            {
                ApiBasket.Post(_context, account.Id, productId);
                return Redirect(backurl);
            }
        }

        [HttpPost]
        public ActionResult StartPayment(int orderId, int? merchantId, int? paymentPrice = null, int? paymentTypeId = null, decimal? creditUsed = null)
        {
            ViewAccount account = _context.Account.GetCurrentAccount();
            if (account == null)
                return RedirectToAction("login", new { controller = "account" });
            else
            {
                if (merchantId == null)
                {
                    Merchant merchant = _context.Merchant.FirstOrDefault(p => p.Active);
                    merchantId = merchant != null ? merchant.ID : merchantId;
                }

                AccountOrder order = _context.AccountOrder.GetById(orderId);
                PaymentType paymentType = null;
                
                if (paymentTypeId != null)
                {
                    order.PaymentTypeId = paymentTypeId;
                    _context.Save();
                }
                else
                {
                    paymentType = _context.PaymentType.GetByLabel(Enum_PaymentType.ONLINE);
                }
                
                ViewPayment payment = new ViewPayment()
                {
                    Description = "پرداخت سفارش با کد " + orderId,
                    OrderId = orderId,
                    PaymentSubject = new ViewPaymentSubject()
                    {
                        Label = Enum_PaymentSubject.ORDER.ToString()
                    }
                };

                if (merchantId != null)
                {
                    payment.Merchant = new ViewMerchant()
                    {
                        Id = merchantId.GetValueOrDefault()
                    };
                }

                if (paymentType.Label == Enum_PaymentType.ACCOUNT.ToString())
                    payment.Price = paymentPrice != null ? paymentPrice.GetValueOrDefault() : order.Price;
                else if (paymentType.Label == Enum_PaymentType.ONLINE.ToString())
                    payment.Price = order.Price;
                else if (paymentType.Label == Enum_PaymentType.PLACE.ToString())
                    payment.Price = 0;

                ApiResult result = ApiPayment.Post(_context, account.Id, null, payment);
                ViewPayment tempPayment = (ViewPayment)result.Value;

                if (paymentType.Label == Enum_PaymentType.PLACE.ToString())
                {
                    Payment tempObject = _context.Payment.GetById(tempPayment.Id);
                    tempObject.StatusId = _context.Code.GetIdByLabel(Enum_Code.PAYMENT_STATUS_SUCCESSFUL);
                    _context.Payment.DoPaymentServices(_context, tempObject);
                    _context.Save();

                    return RedirectToAction("callback", new { controller = "payment", id = tempPayment.Id });
                }
                else
                    return RedirectToAction("start", new { controller = "payment", id = tempPayment.Id });

            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _context.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}