﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using DataLayer.Enumarables;

namespace SiminPardaz
{
    public class RouteConfig
    {
        //public static void RegisterRoutes(RouteCollection routes)
        //{
        //    routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

        //    routes.MapRoute(
        //        name: "Default",
        //        url: "{controller}/{action}/{id}",
        //        defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
        //    );
        //}


        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            CreateStaticRoutes(routes);
        }

        private static void CreateStaticRoutes(RouteCollection routes)
        {
            routes.MapRoute("IpPhp", "ip.php", new { controller = "IP", action = "Index", apiId = UrlParameter.Optional });

            routes.MapRoute("SeoRobots", "robots.txt", new { controller = "Seo", action = "Robots", apiId = UrlParameter.Optional });
            routes.MapRoute("SeoSitemapInfo", "sitemap-{sitemap}-{pageindex}.xml", new { controller = "Seo", action = "SitemapInfo" });
            routes.MapRoute("SeoSitemapListXml", "sitemap.xml", new { controller = "Seo", action = "SitemapList" });
            routes.MapRoute("SeoSitemapList", "sitemap", new { controller = "Seo", action = "SitemapList" });
            //routes.MapRoute("GoogleWebmasters", "google{webmasterId}.html", new { controller = "Seo", action = "GoogleWebmaster" });

            routes.MapRoute("City_Page", "ci/{ciid}/{ciidname}", new { controller = "City", action = "Index", apiId = UrlParameter.Optional });
            routes.MapRoute("Product_Page", "pr/{prid}/{pridname}", new { controller = "Product", action = "Index", apiId = UrlParameter.Optional });
            routes.MapRoute("Reseller_Page", "rs/{rsid}/{rsidname}", new { controller = "ShopReseller", action = "Index", apiId = UrlParameter.Optional });
            routes.MapRoute("ProductBrand_Page", "pb/{pbid}/{pbidname}", new { controller = "ProductBrand", action = "Index", apiId = UrlParameter.Optional });
            routes.MapRoute("Product_Search_Name", "pn/{prindex}/{prname}", new { controller = "Product", action = "Search", apiId = UrlParameter.Optional, proutput = Enum_ProductOutput.SEARCH });
            routes.MapRoute("Logout", "logout", new { controller = "Account", action = "Logout" });
            routes.MapRoute("Basket", "basket", new { controller = "Basket", action = "Index" });
            routes.MapRoute("Login", "login", new { controller = "Account", action = "Login" });
            routes.MapRoute("RegisterReagent", "register/{reid}", new { controller = "Account", action = "Register", apiId = UrlParameter.Optional });
            routes.MapRoute("ApplicationPage", "app/{appid}", new { controller = "App", action = "Index", apiId = UrlParameter.Optional });
            routes.MapRoute("Register", "register", new { controller = "Account", action = "Register" });
            routes.MapRoute("Forget", "forget", new { controller = "Account", action = "Forget" });
            routes.MapRoute("Recover", "recover", new { controller = "Account", action = "Recover" });
            routes.MapRoute("MessageShop", "profile/messageshop/{id}", new { controller = "Account", action = "MessageShop", apiId = UrlParameter.Optional });
            routes.MapRoute("Message", "profile/message", new { controller = "Account", action = "Message" });
            routes.MapRoute("Follow", "profile/follow", new { controller = "Account", action = "Follow" });
            routes.MapRoute("Favorite", "favorite", new { controller = "Account", action = "Favorite" });
            routes.MapRoute("Profile", "profile", new { controller = "Account", action = "Profile" });
            routes.MapRoute("Tracking", "tracking", new { controller = "Account", action = "Tracking" });
            routes.MapRoute("Credit", "profile/credit", new { controller = "Account", action = "Credit" });

            routes.MapRoute("Post_Category", "po/{poidlabel}", new { controller = "Post", action = "SearchCategory", apiId = UrlParameter.Optional });
            routes.MapRoute("DiscountGroup_Index", "dg/{dgLabel}", new { controller = "DiscountGroup", action = "Index", apiId = UrlParameter.Optional });
            routes.MapRoute("Post_Index", "po/{poid}/{poidname}", new { controller = "Post", action = "Index", apiId = UrlParameter.Optional });
            routes.MapRoute("Mall_Index", "ma/{maid}/{maidname}", new { controller = "Mall", action = "Index", apiId = UrlParameter.Optional });
            routes.MapRoute("Banner_Index", "ba/{baid}/{baidname}", new { controller = "Banner", action = "Index", apiId = UrlParameter.Optional });
            routes.MapRoute("Gallery_Index", "ga/{gaid}/{gaidname}", new { controller = "Gallery", action = "Index", apiId = UrlParameter.Optional });
            routes.MapRoute("Shop_Index", "shop/{shid}/{shidname}", new { controller = "Shop", action = "Index", apiId = UrlParameter.Optional });
            routes.MapRoute("Shop_Profile", "shop/profile/{shid}/{shidname}", new { controller = "Shop", action = "Profile", apiId = UrlParameter.Optional });
            routes.MapRoute("Shop_Contact", "shop/contact/{shid}/{shidname}", new { controller = "Shop", action = "Contact", apiId = UrlParameter.Optional });
            routes.MapRoute("Error_Index", "error/{id}", new { controller = "Error", action = "Index", apiId = UrlParameter.Optional });
            routes.MapRoute("StaticPage_Index", "st/{id}", new { controller = "StaticPage", action = "Index", apiId = UrlParameter.Optional });
            routes.MapRoute("Shop_Search", "ss/{index}/{name}", new { controller = "Shop", action = "SearchWithProduct", apiId = UrlParameter.Optional });
            routes.MapRoute("Form_Create", "form/{frlabel}/{frname}", new { controller = "WebsiteForm", action = "Index", apiId = UrlParameter.Optional });
            routes.MapRoute("Default", "{controller}/{action}/{id}", new { controller = "Home", action = "Index", id = UrlParameter.Optional });
            routes.MapRoute("Product_Search_SubCategory", "ps/{prsubcategoryId}/{prindex}/{prtitle}", new { controller = "Product", action = "Search", apiId = UrlParameter.Optional, proutput = Enum_ProductOutput.SEARCH });
            routes.MapRoute("Product_Search_Category", "pc/{prcategoryId}/{prindex}/{prtitle}", new { controller = "Product", action = "Search", apiId = UrlParameter.Optional, proutput = Enum_ProductOutput.SEARCH });
            routes.MapRoute("Product_Search_Type", "pt/{prtypeId}/{prindex}/{prtitle}", new { controller = "Product", action = "Search", apiId = UrlParameter.Optional, proutput = Enum_ProductOutput.SEARCH });
        }
    }
}
