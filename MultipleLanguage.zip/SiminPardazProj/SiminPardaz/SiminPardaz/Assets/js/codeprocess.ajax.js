﻿var viewModel = new (function () {
    this.NewsLetter = new function () {
        this.Phone = ko.observable();
        this.Email = ko.observable();
    }; 
    this.Basket = new function () {
        this.AddCount = ko.observable(1);
        this.Items = ko.observableArray([]);
        this.Count = ko.computed(function () {
            var basketCount = 0;
			for (var i = 0; i < this.Items().length; i++) {
				basketCount += + this.Items()[i].Count;
			}
			return basketCount;
        }, this);
        this.Price = ko.computed(function () {
			var basketPrice = 0;
			for (var i = 0; i < this.Items().length; i++) {
				basketPrice += this.Items()[i].Price;
            }
			return basketPrice;
        }, this);
        this.Discount = ko.computed(function () {
            var basketDiscount = 0;
            for (var i = 0; i < this.Items().length; i++) {
                basketDiscount += this.Items()[i].Discount * this.Items()[i].Count;
            }
            return basketDiscount;
        }, this);
        this.PriceWithoutDiscount = ko.computed(function () {
            var basketPrice = 0;
            for (var i = 0; i < this.Items().length; i++) {
                basketPrice += (this.Items()[i].Product.Price * this.Items()[i].Count);
            }
            return basketPrice;
        }, this);
    };
    this.Order = new function () {
        this.Address = ko.observable();
        this.Rebate = ko.observable();
        this.Price = ko.observable();
        this.PriceWithoutDiscount = ko.observable();
        this.Discount = ko.observable();
        this.PaymentType = ko.observable();
    };
    this.Account = new function() {
        this.FullName = ko.observable();
        this.Mobile = ko.observable();
        this.Email = ko.observable();
        this.Phone = ko.observable();
        this.NationalCode = ko.observable();
        this.BirthDate = ko.observable();
        this.Job = ko.observable();
        this.Company = ko.observable();
        this.Address = ko.observable();
        this.Password = ko.observable();
        this.CompanyNo = ko.observable();
        this.IsMale = ko.observable(true);
        this.Agent = ko.observable();
        this.AgentPhone = ko.observable();
        this.ReagentCode = ko.observable();
        this.TrackingCode = ko.observable();
        this.ReagentName = ko.observable();
        this.Favorites = ko.observableArray([]);
        this.Addresses = new (function () {
            this.Item = new (function () {
                this.Id = ko.observable(0);
                this.NameFamily = ko.observable();
                this.Mobile = ko.observable();
                this.Phone = ko.observable();
                this.PostalCode = ko.observable();
                this.AddressValue = ko.observable();
                this.StateId = ko.observable(-1);
                this.State = new (function () {
                    this.Id = ko.observable();
                    this.Name = ko.observable();
                });
                this.City = new (function () {
                    this.Id = ko.observable();
                    this.Name = ko.observable();
                });
                this.CityName = ko.observable();
                this.CityId = ko.observable(-1);
            });
            this.List = ko.observableArray([]);
        });
        this.IsOnline = ko.observable(false);
        this.Grade = new (function () {
            this.Id = ko.observable(0);
            this.Name = ko.observable();
            this.MinScore = ko.observable();
            this.DiscountPercent = ko.observable();
            this.CreditPercent = ko.observable();
        });
        this.CreditAmount = ko.observable();
        this.IsRecover = ko.observable(false);
        this.Items = ko.observable();
    };
    this.Product = new (function () {
        this.Id = ko.observable();
        this.Name = ko.observable();
        this.CodeValue = ko.observable();
        this.Summary = ko.observable();
        this.Description = ko.observable();
        this.ProductBrand = ko.observable();
        this.Items = ko.observable();
        this.LikesCount = ko.observable();
        this.Status = new (function () {
            this.Name = ko.observable();
            this.Label = ko.observable();
        });
        this.ProductType = new (function () {
            this.Id = ko.observable();
            this.Name = ko.observable();
        });
        this.ProductCategory = new (function () {
            this.Id = ko.observable();
            this.Name = ko.observable();
        });
        this.ProductSubCategory = new (function () {
            this.Id = ko.observable();
            this.Name = ko.observable();
        });
        this.ProductQuantity = ko.observableArray();
        this.LastPrice = ko.observable();
        this.Price = ko.observable();
        this.DiscountPrice = ko.observable();
        this.Picture = new (function () {
            this.Id = ko.observable();
            this.Url = ko.observable();
        });
        this.Document = ko.observable();
        this.Pictures = ko.observableArray();
        this.Colors = ko.observableArray();
        this.Sizes = ko.observableArray();
        this.Active = ko.observable();
        this.GetLink = ko.computed(function () {
            return "/pr/" + this.Id() + "/" + this.Name();
        }, this);
    });
    this.ImportRequest = new function () {
        this.Name = ko.observable();
        this.Family = ko.observable();
        this.CompanyName = ko.observable();
        this.EmailAddress = ko.observable();
        this.Address = ko.observable();
        this.Phone = ko.observable();
        this.Mobile = ko.observable();
        this.CommercialStatusId = ko.observable();
        this.StoreStatusId = ko.observable();
        this.MoreDetail = ko.observable();
        this.DeliveryTime = ko.observable();
    };
    this.Cooperation = new function () {
        this.Name = ko.observable();
        this.Family = ko.observable();
        this.CompanyName = ko.observable();
        this.EmailAddress = ko.observable();
        this.Address = ko.observable();
        this.Phone = ko.observable();
        this.Mobile = ko.observable();
        this.DegreeEducation = ko.observable();
        this.DegreeAndUniversity = ko.observable();
        this.SectionRequested = ko.observable();
        this.CareerBackground = ko.observable();
        this.SummaryCourses = ko.observable();
        this.SellBAckground = ko.observable();
    }
    this.ContactForm = new function () {
        this.FullName = ko.observable();
        this.Mobile = ko.observable();
        this.Email = ko.observable();
        this.Body = ko.observable();
    };
    this.ShopReseller = new (function() {
		this.Id = ko.observable(0);
        this.Name = ko.observable();
        this.Website = ko.observable();
        this.PictureId = ko.observable();
        this.Picture = new (function () {
            this.Id = ko.observable();
            this.Url = ko.observable();
        });
        this.ShopResellerProducts = ko.observableArray([]);
        this.ShopResellerGalleries = ko.observableArray([]);
        this.ShopResellerGalleryItem = new (function () {
            this.Id = ko.observable(0);
            this.FileId = ko.observable();
            this.Name = ko.observable();
            this.Description = ko.observable();
            this.PictureId = ko.observable();
        });
        this.ShopResellerCollections = ko.observableArray([]);
        this.ShopResellerCollectionItem = new (function () {
            this.Name = ko.observable();
            this.Description = ko.observable();
            this.Picture1 = new (function () {
                this.Id = ko.observable();
                this.Url = ko.observable();
            });;
            this.Picture2 = new (function () {
                this.Id = ko.observable();
                this.Url = ko.observable();
            });
            this.Picture3 = new (function () {
                this.Id = ko.observable();
                this.Url = ko.observable();
            });
            this.Products = ko.observableArray();
        });
        this.ShopResellerStories = ko.observableArray([]);
        this.ShopResellerProductTypeReport = ko.observableArray([]);
		this.GetLink = ko.computed(function () {
            return "/rs/" + this.Id() + "/" + this.Name();
        }, this);
    });
    this.SearchResult = new (function () {
        this.Name = ko.observable("");
        this.ProductType = ko.observable(null);
        this.ProductBrand = ko.observable(null);
        this.ProductCategory = ko.observable(null);
        this.ProductSubCategory = ko.observable(null);
        this.PageSize = ko.observable(10);
        this.PageIndex = ko.observable(1);
        this.Results = ko.observableArray();
        this.CustomResult = ko.observableArray();
    });
    this.Compare = new function () {
        this.ProductName = ko.observable();
        this.Results = ko.observableArray();
        this.Filters = new function () {
            this.NotId = ko.observable(null);
            this.Name = ko.observable(null);
            this.ProductType = ko.observable(null);
            this.ProductBrand = ko.observable(null);
            this.ProductCategory = ko.observable(null);
            this.ProductSubCategory = ko.observable(null);
            this.PageSize = ko.observable(10);
            this.PageIndex = ko.observable(1);
        };
    };
    this.ProductBrands = new (function () {
        this.ProductType = ko.observable(null);
        this.PageSize = ko.observable(10);
        this.PageIndex = ko.observable(1);
        this.Results = ko.observableArray();
    });
    this.StateList = ko.observableArray();
    this.CityList = ko.observableArray();
    this.toCurrency = function (amount) {
        return toCurrency(ko.toJSON(amount));
    };
    this.toPersian = function (numberValue) {
        return toPersian(ko.toJSON(numberValue));
    };
})();

ko.applyBindings(viewModel);

var codeprocess = {
    function: "codeprocess-action",
    change: "codeprocess-change",
    callback: {
        name: "codeprocess-callback",
        clear: {
            form: "clear-form"
        },
        close: {
            modal: "close-modal"
        }
    },
    field: {
        attrName: "codeprocess-field",
        nameFamily: "namefamily",
        body: "body",
        questionBody: "question-body",
        questionAnswer: "question-answer",
        questionConsultant: "question-consultant",
        productId: "product-id",
        basketId: "basket-id",
        basketCount: "basket-count",
        orderId: "orderId",
        rebateValue: "rebate-value",
        rebateMobile: "rebate-mobile",
        newPassword: "new-password",
        confirmPassword: "confirm-password",
        actionType: {
            name: "action-type",
            add: "add",
            remove: "remove",
            update: "update"
        },
        account: {
            fullname: "account-fullname",
            email: "account-email",
            password: "account-password",
            nationalCode: "account-nationalcode",
            mobile: "account-mobile",
            phone: "account-phone",
            address: "account-address",
            confirm: "account-confirm",
            reagent: "account-reagent",
            loginMobile: "account-login-mobile",
            loginPassword: "account-login-password",
            recoverValue: "recover-value"
        },
        order: {
            tracking: {
                code: "tracking-code",
                result: "tracking-result"
            }
        },
        google: {
            recaptcha: "g-recaptcha-response"
        },
        reagent: {
            mobile: "reagent-mobile",
            email: "reagent-email",
            fullName: "reagent-fullname"
        },
        contactform: {
            websiteId: "contactform-websiteId",
            fullname: "contactform-fullname",
            email: "contactform-email",
            mobile: "contactform-mobile",
            body: "contactform-body",
            website: "contactform-website",
            subject: "contactform-subject"
        },
        websiteform: {
            formId: "website-form-id"
        }
    },
    target: {
        button: 'button',
        input: 'input',
        modal: 'modal',
        form: 'form'
    },
    api: {
        account: {
            name: "account",
            edit: "account-edit",
            changepassword: "account-changepassword"
        },
        login: {
            name: "login"
        },
        register: {
            name: "register"
        },
        logout: {
            name: "logout"
        },
        recover: {
            name: "recover",
            done: "recover-done"
        },
        changepassword: {
            name: "changepassword",
            siteuser: "changepasswordsiteuser",
        },
        basket: {
            name: "accountbasket",
            get: "basket-get",
            add: "basket-add",
            edit: "basket-edit",
            remove: "basket-remove",
            update: "basket-update"
        },
        shopfollow: {
            name: "shopfollow",
            follow: "shop-follow",
            unfollow: "shop-unfollow"
        },
        address: {
            name: "accountaddress",
            add: "address-add",
            edit: "address-edit",
            remove: "address-remove"
        },
        newsletter: {
            name: "newsletter",
            add: "newsletter-add"
        },
        product: {
            name: "product"
        },
        productbrand: {
            name: "productbrand"
        },
        productlike: {
            name: "productlike",
            add: "productlike-add",
            remove: "productlike-remove"
        },
        productnotify: {
            name: "productnotify",
            remove: "productnotify-remove"
        },
        productnotifydiscount: {
            name: "productnotifydiscount"
        },
        productcomment: {
            name: "productcomment",
            add: "comment-add"
        },
        productcommentlike: {
            name: "productcommentlike",
            add: "productcommentlike-add",
            remove: "productcommentlike-remove"
        },
        productconsultant: {
            name: "productconsultant",
            add: "consultant-add"
        },
        productquestion: {
            name: "productquestion",
            add: "question-add"
        },
        productquestionanswer: {
            name: "productquestionanswer",
            add: "questionanswer-add"
        },
        productrate: {
            name: "productrate"
        },
        rebate: {
            name: "rebate",
            remove: "rebate-remove",
            sms: "rebate-sms"
        },
        reagent: {
            name: "accountreagent"
        },
        contactform: {
            name: "contactform"
        },
        credit: {
            name: "credit"
        },
        payment: {
            name: "payment"
        },
        order: {
            name: "order",
            tracking: "tracking"
        },
        siteuser: {
            name: "siteuser",
            changepassword: "siteuser-changepassword"
        },
        shopreseller: {
            name: "shopreseller"
        },
        shopresellercollection: {
            name: "shopresellercollection"
        },
        shopresellergallery: {
            name: "shopresellergallery",
            remove: "shopresellergallery-remove"
        },
        shopresellerproduct: {
            name: "shopresellerproduct"
        },
        shopresellerstory: {
            name: "shopresellerstory"
        },
        shopresellerproducttypereport: {
            name: "shopresellerproducttypereport"
        },
        shopresellerfollow: {
            name: "shopresellerfollow",
            add: "shopresellerfollow-add",
            remove: "shopresellerfollow-remove"
        },
        websiteform: {
            name: "websiteform"
        },
        state: {
            name: "state"
        },
        city: {
            name: "city"
        },
        inquiry: {
            "name": "inquiryrequest",
            "form": "inquiryrequestform"
        },
        importrequest: {
            name: "importrequest"
        },
        cooperation: {
            name: "cooperation"
        }
    },
    map: "codeprocess-map",
    mapApi: {
        marker: "map-marker"
    }
};

var apirequest = {
    type: {
        Post: "POST",
        Get: "GET",
        Put: "PUT",
        Delete: "DELETE"
    },
    status: {
        Exception: 0,
        Success: 1,
        InvalidKey: 2,
        Error: 3
    }
};

function createMessage(type, msg) {
    var title = "";
    if (type === "error") {
        title = "خطا";
    } else if (type === "success") {
        title = "موفقیت آمیز";
    } else if (type === "warning") {
        title = "هشدار";
    } else if (type === "info") {
        title = "اطلاع رسانی";
    }

    if (msg !== "" && msg !== undefined) {
        Command: toastr[type](msg, title)
        toastr.options = {
            "closeButton": true,
            "debug": false,
            "newestOnTop": false,
            "progressBar": false,
            "positionClass": "toast-top-right",
            "preventDuplicates": false,
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "1000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        }
    }    
}

$(document).ready(function () {
    $("[" + codeprocess.function + "]").click(function () {
        var btn = $(this);
        var callFunction = $(this).attr(codeprocess.callback.name);
        var request = createRequest(callFunction);
        var functionName = $(btn).attr(codeprocess.function);
        
        if (functionName === codeprocess.api.shopfollow.follow) {
            doShopFollow(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.shopfollow.unfollow) {
            doShopUnFollow(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.basket.get) {
            doGetBasket(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.basket.add) {
            doAddBasket(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.basket.remove) {
            doRemoveBasket(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.basket.edit) {
            doEditBasket(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.address.add) {
            doAddAddress(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.address.remove) {
            doRemoveAddress(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.newsletter.add) {
            doAddNewsletter(request, btn, callFunction);
        }
        else if (
            functionName === codeprocess.api.productlike.add ||
            functionName === codeprocess.api.productlike.remove) {
            doProductLike(request, btn, callFunction);
        }
        else if (
            functionName === codeprocess.api.productcommentlike.add ||
            functionName === codeprocess.api.productcommentlike.remove) {
            doProductCommentLike(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.productnotify.name) {
            doProductNotify(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.productnotify.remove) {
            doProductNotifyRemove(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.productnotifydiscount.name) {
            doProductNotifyDiscount(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.productrate.name) {
            doProductRate(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.productcomment.add) {
            doProductComment(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.productconsultant.add) {
            doProductConsultant(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.productquestion.add) {
            doProductQuestion(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.productquestionanswer.add) {
            doProductQuestionAnswer(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.login.name) {
            doAccountLogin(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.register.name) {
            doAccountRegister(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.logout.name) {
            doAccountLogout(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.recover.name) {
            doAccountRecoverPassword(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.recover.done) {
            doAccountRecoverPasswordDone(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.rebate.name) {
            doOrderRebate(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.rebate.remove) {
            doRemoveRebate(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.rebate.sms) {
            doRebateSms(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.reagent.name) {
            doOrderReagent(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.contactform.name) {
            doContactForm(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.account.edit) {
            doAccountEdit(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.account.changepassword) {
            doAccountChangePassword(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.siteuser.changepassword) {
            doSiteUserChangePassword(request, btn, callFunction);
        }
        else if (
            functionName === codeprocess.api.credit.name ||
            functionName === codeprocess.api.payment.name) {
            doAccountPayment(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.order.tracking) {
            doAccountOrderTracking(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.websiteform.name) {
            doWebsiteFormSubmit(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.shopresellergallery.remove) {
            doRemoveShopResellerGallery(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.inquiry.name) {
            doAddInquiryRequest(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.inquiry.form) {
            doAddInquiryFormRequest(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.importrequest.name) {
            doImportRequest(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.cooperation.name) {
            doOperationRequest(request, btn, callFunction);
        }
        else if (functionName === codeprocess.api.shopresellerfollow.add ||
            functionName === codeprocess.api.shopresellerfollow.remove) {
            doShopResellerFollow(request, btn, callFunction);
        }
        else
            return;
        $.ajax(request);
    });

    $("[" + codeprocess.change + "]").change(function () {
        var btn = $(this);
        var callFunction = $(this).attr(codeprocess.callback.name);
        var request = createRequest(callFunction);
        var functionName = $(btn).attr(codeprocess.change);

        if (functionName === codeprocess.api.basket.update) {
            doEditBasket(request, btn, callFunction);
        }
        else
            return;

        $.ajax(request);
    });

    var maps = $("[" + codeprocess.map + "]");
    if (maps.length > 0)
    {
        for (var i = 0; i < maps.length; i++) {
            var mapEntity = maps[i];
            var mapFunction = $(mapEntity).attr(codeprocess.map);
            if (mapFunction === codeprocess.mapApi.marker) {
                //TODO
            }
        }
        google.maps.event.addDomListener(window, 'load', initialize);
    }
});

function doWebsiteFormSubmit(request, btn, callback) {
    var formName = $(btn).attr(codeprocess.field.websiteform.formId);
    request.url = request.url + codeprocess.api.websiteform.name;
    request.type = apirequest.type.Post;
    request.data = JSON.stringify(getFormContent(formName));
    request.success = function (result) {
        if (doApiCallBack(result, callback) === true) {
            $("form input").val("");
        }
    };
}

function doAccountEdit(request, btn, callback) {
    request.url = request.url + codeprocess.api.account.name;
    request.type = apirequest.type.Put;
    request.data = ko.toJSON(viewModel.Account);
    request.success = function (result) {
        if (doApiCallBack(result, callback) === true) {
            updateViewModelAccount(result);
        }
    };
}

function doAccountChangePassword(request, btn, callFunction) {
    var new_password = getCodeprocessValue(codeprocess.field.newPassword);
    var confirm_password = getCodeprocessValue(codeprocess.field.confirmPassword);
    request.url = request.url + codeprocess.api.changepassword.name + "?newPassword=" + new_password + "&confirmPassword=" + confirm_password;
    request.type = apirequest.type.Put;
    request.success = function (result) {
        if (doApiCallBack(result, callFunction) === true) {
            doCodeprocessClear(codeprocess.field.account.password);
            doCodeprocessClear(codeprocess.field.newPassword);
            doCodeprocessClear(codeprocess.field.confirmPassword);
        }
    };
}

function doSiteUserChangePassword(request, btn, callFunction) {
    var new_password = getCodeprocessValue(codeprocess.field.newPassword);
    var confirm_password = getCodeprocessValue(codeprocess.field.confirmPassword);
    request.url = request.url + codeprocess.api.changepassword.siteuser + "?newPassword=" + new_password + "&confirmPassword=" + confirm_password;
    request.type = apirequest.type.Put;
    request.success = function (result) {
        if (doApiCallBack(result, callFunction) === true) {
            doCodeprocessClear(codeprocess.field.account.password);
            doCodeprocessClear(codeprocess.field.newPassword);
            doCodeprocessClear(codeprocess.field.confirmPassword);
        }
    };
}

function doAccountOrderTracking(request, btn, callFunction) {
    var recaptchaValue = $("[name='" + codeprocess.field.google.recaptcha + "']").val();
    var trackingCode = $("[" + codeprocess.field.attrName + "='" + codeprocess.field.order.tracking.code + "']").val();
    request.type = apirequest.type.Post;
    request.url = request.url + codeprocess.api.order.tracking + "?code=" + trackingCode;
    request.success = function (result) {
        if (doApiCallBack(result, callFunction, "no-message") === true) {
            var orderInfo = result.Value;
            var html = "شماره سفارش: " + orderInfo.Id + "، مشتری: " + orderInfo.Account.FullName + "، وضعیت سفارش: " + orderInfo.Status.Name;
            $("[" + codeprocess.field.attrName + "='" + codeprocess.field.order.tracking.result + "']").html(html);
        } else {
            $("[" + codeprocess.field.attrName + "='" + codeprocess.field.order.tracking.result + "']").html(result.Message);
        }
    };
}

function doOrderReagent(request, btn, callFunction) {
    var recaptchaValue = $("[name='" + codeprocess.field.google.recaptcha + "']").val();
    var fullName = getCodeprocessValue(codeprocess.field.reagent.fullName);
    var mobile = getCodeprocessValue(codeprocess.field.reagent.mobile);
    var email = getCodeprocessValue(codeprocess.field.reagent.email);
    
    request.type = apirequest.type.Post;
    request.url = request.url + codeprocess.api.reagent.name + "?fullName=" + fullName + "&mobile=" + mobile + "&email=" + email + "&recaptcha=" + recaptchaValue;
    request.success = function (result) {
        if (doApiCallBack(result, callFunction) === true) {
            $("[" + codeprocess.field.attrName + "='" + codeprocess.field.reagent.fullName + "']").val(null);
            $("[" + codeprocess.field.attrName + "='" + codeprocess.field.reagent.email + "']").val(null);
            $("[" + codeprocess.field.attrName + "='" + codeprocess.field.reagent.mobile + "']").val(null);
        }
    };
}

function doAccountPayment(request, btn, callFunction) {
    var entity = {
        PaymentSubject: {
            Label: "CREDIT"
        },
        Description: "طرح فلان",
        Price: 1000
    };
    request.data = JSON.stringify(entity);
    request.type = apirequest.type.Post;
    request.url = request.url + codeprocess.api.payment.name;
    request.success = function (result) {
        if (doApiCallBack(result, callFunction) === true) {
            document.location = result.Value.Url;
        } else {
            alert("ERROR");
        }
    };
}

function doContactForm(request, btn, callFunction) {
    request.type = apirequest.type.Post;
    request.data = ko.toJSON(viewModel.ContactForm);
    request.url = request.url + codeprocess.api.contactform.name;
    request.success = function (result) {
        if (doApiCallBack(result, callFunction) === true) {
            viewModel.ContactForm.FullName("");
            viewModel.ContactForm.Mobile("");
            viewModel.ContactForm.Email("");
            viewModel.ContactForm.Body("");
        }
    };
}

function doRebateSms(request, btn, callFunction) {
    var rebateMobile = getCodeprocessValue(codeprocess.field.rebateMobile);
    request.type = apirequest.type.Put;
    request.url = request.url + codeprocess.api.rebate.name + "?rebateMobile=" + rebateMobile;
    request.success = function (result) {
        if (doApiCallBack(result, callFunction) === true) {
            $("[" + codeprocess.field.attrName + "='" + codeprocess.field.rebateMobile + "']").val(null);
        }
    };
}

function doOrderRebate(request, btn, callFunction) {
    var rebateValue = getCodeprocessValue(codeprocess.field.rebateValue);
    var orderId = getCodeprocessValue(codeprocess.field.orderId);
    request.type = apirequest.type.Post;
    request.url = request.url + codeprocess.api.rebate.name + "?rebateValue=" + rebateValue + "&orderId=" + orderId;
    request.success = function (result) {
        if (doApiCallBack(result, callFunction) === true) {
            document.location = document.location;
        }
    };
}

function doRemoveRebate(request, btn, callFunction) {
    var orderId = $(btn).attr(codeprocess.field.orderId);
    request.type = apirequest.type.Delete;
    request.url = request.url + codeprocess.api.rebate.name + "?orderId=" + orderId;
    request.success = function (result) {
        if (doApiCallBack(result, callFunction) === true) {
            document.location = document.location;
        }
    };
}

function doAccountRegister(request, btn, callFunction) {
    var confirm = getCodeprocessValue(codeprocess.field.account.confirm);
    request.data = ko.toJSON(viewModel.Account);
    request.type = apirequest.type.Post;
    request.url = request.url + codeprocess.api.register.name + "?remember=true&confirm=" + confirm;
    request.success = function (result) {
        if (doApiCallBack(result, callFunction) === true) {
            updateViewModelAccount(result);
        }
    };
}

function doAccountRecoverPassword(request, btn, callFunction) {
    request.data = ko.toJSON(viewModel.Account);
    request.type = apirequest.type.Post;
    request.url = request.url + codeprocess.api.recover.name;
    request.success = function (result) {
        if (doApiCallBack(result, callFunction) === true) {
            viewModel.Account.IsRecover(true);
        }
    };
}

function doAccountRecoverPasswordDone(request, btn, callFunction) {
    var recoverValue = getCodeprocessValue(codeprocess.field.account.recoverValue);
    request.type = apirequest.type.Put;
    request.url = request.url + codeprocess.api.recover.name + "?recoverValue=" + recoverValue;
    request.success = function (result) {
        if (doApiCallBack(result, callFunction) === true) {
            updateViewModelAccount(result);
        }
    };
}

function doAccountLogin(request, btn, callFunction) {
    var recaptchaValue = $("[name='" + codeprocess.field.google.recaptcha + "']").val();
    request.data = getAccountEntity();
    request.type = apirequest.type.Post;
    request.url = request.url + codeprocess.api.login.name + "?remember=true&recaptcha=" + recaptchaValue;
    request.success = function (result) {
        try {
            grecaptcha.reset();
        }
        catch (e) {
            // TODO
        }
        if (doApiCallBack(result, callFunction) === true) {
            updateViewModelAccount(result);
            doGetBasket();
        }
    };
}

function doAccountLogout(request, btn, callFunction) {
    request.type = apirequest.type.Post;
    request.url = request.url + codeprocess.api.logout.name;
    request.success = function (result) {
        if (doApiCallBack(result, callFunction) === true) {
            clearViewModelAccount();
        }
    };
}

function getFormContent(formName) {
    var entity = {
        Label: "",
        FormValues: []
    };
    var formLabel = $("#" + formName).find("[name='FormLabel']").val();
    entity.Label = formLabel;

    var fields = $("#" + formName).find("[form-field-id]");
    for (var i = 0; i < fields.length; i++) {
        entity.FormValues.push({
            ColumnId: $(fields[i]).attr("form-field-id"),
            Value: $(fields[i]).val()
        });
    }
    return entity;
}

function getAccountEntity()
{
    return ko.toJSON(viewModel.Account);
}

function getCodeprocessValue(fieldName) {
    var cprObject = $("[" + codeprocess.field.attrName + "='" + fieldName + "']");
    var value = $(cprObject).val();
    return value === undefined ? null : value;
}

function doCodeprocessClear(fieldName) {
    var cprObject = $("[" + codeprocess.field.attrName + "='" + fieldName + "']");
    $(cprObject).val(null);
}

function doSearchProduct() {
    var request = createRequest();
    request.url = request.url + codeprocess.api.product.name;
    request.url = request.url + "?pageSize=" + viewModel.SearchResult.PageSize();
    request.url = request.url + "&index=" + viewModel.SearchResult.PageIndex();
    request.url = request.url + "&name=" + viewModel.SearchResult.Name();
    request.url = request.url + "&typeId=" + viewModel.SearchResult.ProductType();
    request.url = request.url + "&categoryId=" + viewModel.SearchResult.ProductCategory();
    request.url = request.url + "&subCategoryId=" + viewModel.SearchResult.ProductSubCategory();
    request.url = request.url + "&brandId=" + viewModel.SearchResult.ProductBrand();
    request.success = function (result) {
        var resultList = result.Value;
        viewModel.SearchResult.Results(resultList);
    };
    $.ajax(request);
}

function doCompareProduct() {
    var request = createRequest();
    request.url = request.url + codeprocess.api.product.name;
    request.url = request.url + "?pageSize=" + viewModel.Compare.Filters.PageSize();
    request.url = request.url + "&index=" + viewModel.Compare.Filters.PageIndex();
    request.url = request.url + "&name=" + viewModel.Compare.Filters.Name();
    request.url = request.url + "&typeId=" + viewModel.Compare.Filters.ProductType();
    request.url = request.url + "&categoryId=" + viewModel.Compare.Filters.ProductCategory();
    request.url = request.url + "&subCategoryId=" + viewModel.Compare.Filters.ProductSubCategory();
    request.url = request.url + "&brandId=" + viewModel.Compare.Filters.ProductBrand();
    request.success = function (result) {
        var resultList = result.Value;
        viewModel.Compare.Results(resultList);
    };
    $.ajax(request);
}

function doCustomSearchProduct() {
    var request = createRequest();
    request.url = request.url + codeprocess.api.product.name;
    request.url = request.url + "?pageSize=" + viewModel.SearchResult.PageSize();
    request.url = request.url + "&index=" + viewModel.SearchResult.PageIndex();
    request.url = request.url + "&name=" + viewModel.SearchResult.Name();
    request.url = request.url + "&typeId=" + viewModel.SearchResult.ProductType();
    request.url = request.url + "&categoryId=" + viewModel.SearchResult.ProductCategory();
    request.url = request.url + "&subCategoryId=" + viewModel.SearchResult.ProductSubCategory();
    request.url = request.url + "&brandId=" + viewModel.SearchResult.ProductBrand();
    request.success = function (result) {
        var resultList = result.Value;
        viewModel.SearchResult.CustomResult(resultList);
    };
    $.ajax(request);
}

function doSearchProductBrands() {
    var request = createRequest();
    request.url = request.url + codeprocess.api.productbrand.name;
    request.url = request.url + "?typeId=" + viewModel.SearchResult.ProductType();
    request.url = request.url + "&pageSize=" + viewModel.ProductBrands.PageSize();
    request.url = request.url + "&index=" + viewModel.ProductBrands.PageIndex();
    request.success = function (result) {
        var resultList = result.Value;
        viewModel.ProductBrands.Results(resultList);
    };
    $.ajax(request);
}

function doProductComment(request, btn, callFunction)
{
    var productId = $(btn).attr("product-id");
    request.type = apirequest.type.Post;
    var entity = {
        Product: {
            Id: productId
        },
        NameFamily: $("[" + codeprocess.field.attrName + "='" + codeprocess.field.nameFamily + "']").val(),
        Body: $("[" + codeprocess.field.attrName + "='" + codeprocess.field.body + "']").val()
    };
    request.data = JSON.stringify(entity);
    request.url = request.url + codeprocess.api.productcomment.name;
    request.success = function (result) {
        if (doApiCallBack(result, callFunction) === true) {
            $("[" + codeprocess.field.attrName + "='" + codeprocess.field.body + "']").val("");
        }
    };
}

function doAddInquiryRequest(request, btn, callFunction) {
    request.type = apirequest.type.Post;
    request.url = request.url + codeprocess.api.inquiry.name;
    request.success = function (result) {
        if (doApiCallBack(result, callFunction) === true) {
            document.location = "/account/invoice";
        }
    };
}

function doAddInquiryFormRequest(request, btn, callFunction) {
    var productCodeValue = $("#txtInquiryCodeValue").val();
    var productCount = $("#txtInquiryCount").val();
    request.type = apirequest.type.Post;
    var entity = {
        ProductCodeValue: productCodeValue,
        Count: productCount
    };
    request.data = JSON.stringify(entity);
    request.url = request.url + codeprocess.api.inquiry.form;
    request.success = function (result) {
        if (doApiCallBack(result, callFunction) === true) {
            document.location = "/account/invoice";
        }
    };
}

function doImportRequest(request, btn, callFunction) {
    request.type = apirequest.type.Post;
    request.url = request.url + codeprocess.api.importrequest.name;
    request.data = ko.toJSON(viewModel.ImportRequest);
    request.success = function (result) {
        if (doApiCallBack(result, callFunction) === true) {
            // DO CALLBACK
        }
    };
}

function doOperationRequest(request, btn, callFunction) {
    request.type = apirequest.type.Post;
    request.url = request.url + codeprocess.api.cooperation.name;
    request.data = ko.toJSON(viewModel.Cooperation);
    request.success = function (result) {
        if (doApiCallBack(result, callFunction) === true) {
            viewModel.Cooperation.Address(null);
            viewModel.Cooperation.CareerBackground(null);
            viewModel.Cooperation.CompanyName(null);
            viewModel.Cooperation.DegreeAndUniversity(null);
            viewModel.Cooperation.DegreeEducation(null);
            viewModel.Cooperation.EmailAddress(null);
            viewModel.Cooperation.Family(null);
            viewModel.Cooperation.Mobile(null);
            viewModel.Cooperation.Name(null);
            viewModel.Cooperation.Phone(null);
            viewModel.Cooperation.SectionRequested(null);
            viewModel.Cooperation.SellBAckground(null);
            viewModel.Cooperation.SummaryCourses(null);
        }
    };
}

function doProductConsultant(request, btn, callFunction) {
    var productId = $(btn).attr("product-id");
    request.type = apirequest.type.Post;
    var entity = {
        Product: {
            Id: productId
        },
        Body: $("[" + codeprocess.field.attrName + "='" + codeprocess.field.questionConsultant + "']").val()
    };
    request.data = JSON.stringify(entity);
    request.url = request.url + codeprocess.api.productconsultant.name;
    request.success = function (result) {
        if (doApiCallBack(result, callFunction) === true) {
            $("[" + codeprocess.field.attrName + "='" + codeprocess.field.questionConsultant + "']").val("");
        }
    };
}

function doProductQuestion(request, btn, callFunction) {
    var productId = $(btn).attr("product-id");
    request.type = apirequest.type.Post;
    var entity = {
        Product: {
            Id: productId
        },
        Body: $("[" + codeprocess.field.attrName + "='" + codeprocess.field.questionBody + "']").val()
    };
    request.data = JSON.stringify(entity);
    request.url = request.url + codeprocess.api.productquestion.name;
    request.success = function (result) {
        if (doApiCallBack(result, callFunction) === true) {
            $("[" + codeprocess.field.attrName + "='" + codeprocess.field.questionBody + "']").val("");
        }
    };
}

function doProductQuestionAnswer(request, btn, callFunction) {
    var productId = $(btn).attr("question-id");
    request.type = apirequest.type.Post;
    var entity = {
        Question: {
            Id: productId
        },
        Body: $("[" + codeprocess.field.attrName + "='" + codeprocess.field.questionAnswer + "']").val()
    };
    request.data = JSON.stringify(entity);
    request.url = request.url + codeprocess.api.productquestionanswer.name;
    request.success = function (result) {
        if (doApiCallBack(result, callFunction) === true) {
            $("[" + codeprocess.field.attrName + "='" + codeprocess.field.questionAnswer + "']").val("");
        }
    };
}

function doAddNewsletter(request, btn, callback) {
    var entity = {
        WebsiteId: $("#newsletterWebsiteId").val(),
        Email: $("#newsletterEmail").val(),
        Mobile: $("#newsletterMobile").val()
    };
    request.data = JSON.stringify(entity);
    request.type = apirequest.type.Post;
    request.url = request.url + codeprocess.api.newsletter.name;
    request.success = function (result) {
        if (doApiCallBack(result, callback) === true) {
            $("#newsletterEmail").val(null);
            $("#newsletterMobile").val(null);
        }
    };
}

function doShopFollow(request, btn, callback) {
    var shopId = $(btn).attr("shop-id");
    request.type = apirequest.type.Post;
    request.url = request.url + codeprocess.api.shopfollow.name + "?shopId=" + shopId;
    console.log(request.url);
    request.success = function (result) {
        if (doApiCallBack(result, callback) === true) {
            $(btn).attr(codeprocess.function, codeprocess.api.shopfollow.unfollow);
        }
    };
}

function doShopUnFollow(request, btn, callback) {
    var shopId = $(btn).attr("shop-id");
    request.type = apirequest.type.Delete;
    request.url = request.url + codeprocess.api.shopfollow.name + "?shopId=" + shopId;
    request.success = function (result) {
        if (doApiCallBack(result, callback) === true) {
            $(btn).attr(codeprocess.function, codeprocess.api.shopfollow.follow);
        }
    };
}

function doAddBasket(request, btn, callback) {
    var productId = $(btn).attr("product-id");
    var productColorId = $(btn).attr("product-color-id");
    var productSizeId = $(btn).attr("product-size-id");
    var resellerId = $(btn).attr("reseller-id");
    var packId = $(btn).attr("product-pack-id");
    request.type = apirequest.type.Post;
    request.url = request.url + codeprocess.api.basket.name +
        "?productId=" + productId +
        "&colorId=" + productColorId +
        "&sizeId=" + productSizeId +
        "&resellerId=" + resellerId +
        "&packId=" + packId +
        "&count=" + viewModel.Basket.AddCount();
    request.success = function (result) {
        if (doApiCallBack(result, callback) === true) {
            updateViewModelBasket(result);
        }
    };
}

function createRequest(callbackFunctions) {
    var response = {
        url: "/cpr/",
        type: "GET",
        dataType: "json",
        cache: false,
        contentType: "application/json; charset=utf-8",
        error: function (a) {
            createMessage("error", a.Message);
        },
        success: function (result) {
            doApiCallBack(result);
            doCodeprocessCallback(callbackFunctions);
        }
    };
    return response;
}

function doAddBasketAjax(data, target) {
    var request = createRequest();
    var btn = $(event.target);
    if ($(btn).attr("product-id") === undefined) {
        btn = $(btn).parent();
    }
    var callback = $(btn).attr(codeprocess.callback.name);
    doAddBasket(request, btn, callback);
    $.ajax(request);
}

function doEditBasketAjax(data, event) {
    var request = createRequest();
    var btn = $(event.target).parent();
    if ($(btn).attr(codeprocess.field.actionType.name) === undefined) {
        btn = $(event.target);
    }
    var callback = $(btn).attr(codeprocess.callback.name);
    doEditBasket(request, btn, callback);
    $.ajax(request);
}

function doEditBasket(request, btn, callback) {
    var basketId = $(btn).attr(codeprocess.field.basketId);
    var actionType = $(btn).attr(codeprocess.field.actionType.name);
    var productId = $(btn).attr("product-id");
    var productColorId = $(btn).attr("product-color-id") === undefined ? null : $(btn).attr("product-color-id");
    var productSizeId = $(btn).attr("product-size-id") === undefined ? null : $(btn).attr("product-size-id");
    var productPackId = $(btn).attr("product-pack-id") === undefined ? null : $(btn).attr("product-pack-id");
    var count = 1;
    if (actionType === codeprocess.field.actionType.update) {
        count = $(btn).val();
    }
    request.type = apirequest.type.Put;
    request.url = request.url + codeprocess.api.basket.name +
        "?basketId=" + basketId +
        "&actionType=" + actionType +
        "&productId=" + productId +
        "&colorId=" + productColorId +
        "&sizeId=" + productSizeId +
        "&packId=" + productPackId +
        "&count=" + count;
    request.success = function (result) {
        if (doApiCallBack(result, callback, "no-message") === true) {
            updateViewModelBasket(result);
        }
    };
}

function doRemoveBasketAjax(data, event) {
    var btn = $(event.target).parent();
    if ($(btn).attr(codeprocess.field.productId) === undefined) {
        btn = $(event.target);
    }
    var callFunction = $(btn).attr(codeprocess.callback.name);
    var request = createRequest();
    doRemoveBasket(request, btn, callFunction);
    $.ajax(request);
}

function doRemoveBasket(request, btn, callback) {
    var basketId = $(btn).attr(codeprocess.field.basketId);
    var productId = $(btn).attr("product-id");
    var productColorId = $(btn).attr("product-color-id") === undefined ? null : $(btn).attr("product-color-id");
    var productSizeId = $(btn).attr("product-size-id") === undefined ? null : $(btn).attr("product-size-id");
    var productPackId = $(btn).attr("product-pack-id") === undefined ? null : $(btn).attr("product-pack-id");
    request.type = apirequest.type.Delete;
    request.url = request.url + codeprocess.api.basket.name + "?basketId=" + basketId + "&productId=" + productId + "&colorId=" + productColorId + "&sizeId=" + productSizeId + "&packId=" + productPackId;
    request.success = function (result) {
        if (doApiCallBack(result, callback, "no-message") === true) {
            updateViewModelBasket(result);
        }
    };
}

function clearViewModelAccountAddressItem() {
    var data = {
        Id: 0, 
        StateId: 0,
        State: {
            Id: 0
        },
        CityId: 0,
        City: {
            Id: 0
        }
    };
    updateViewModelAccountAddressItem(data);
}

function updateViewModelAccountAddressItem(data)
{
    viewModel.Account.Addresses.Item.Id(data.Id);
    viewModel.Account.Addresses.Item.NameFamily(data.NameFamily);
    viewModel.Account.Addresses.Item.AddressValue(data.AddressValue);
    viewModel.Account.Addresses.Item.Mobile(data.Mobile);
    viewModel.Account.Addresses.Item.Phone(data.Phone);
    viewModel.Account.Addresses.Item.PostalCode(data.PostalCode);
    viewModel.Account.Addresses.Item.CityName(data.CityName);
    viewModel.Account.Addresses.Item.StateId(data.StateId);
    viewModel.Account.Addresses.Item.CityId(data.CityId);
    if (data.State !== null) {
        viewModel.Account.Addresses.Item.State.Id(data.State.Id);
        viewModel.Account.Addresses.Item.State.Name(data.State.Name);
    }
    if (data.City !== null) {
        viewModel.Account.Addresses.Item.City.Id(data.City.Id);
        viewModel.Account.Addresses.Item.City.Name(data.City.Name);
    }
}

function updateViewModelBasket(result) {
    viewModel.Basket.Items(result.Value);
    //$("[" + codeprocess.field.attrName + "='" + codeprocess.field.basketCount + "']").html(basketCount);
}

function updateViewModelProduct(result) {
    viewModel.Product.Id(result.Id);
    viewModel.Product.Name(result.Name);
    viewModel.Product.CodeValue(result.CodeValue);
    viewModel.Product.Summary(result.Summary);
    viewModel.Product.Description(result.Description);
    if (result.ProductType != null) {
        viewModel.Product.ProductType.Id(result.ProductType.Id);
        viewModel.Product.ProductType.Name(result.ProductType.Name);
    }
    if (result.ProductCategory !== null) {
        viewModel.Product.ProductCategory.Id(result.ProductCategory.Id);
        viewModel.Product.ProductCategory.Name(result.ProductCategory.Name);
    }
    if (result.ProductSubCategory !== null) {
        viewModel.Product.ProductSubCategory.Id(result.ProductSubCategory.Id);
        viewModel.Product.ProductSubCategory.Name(result.ProductSubCategory.Name);
    }
    if (result.Picture !== null) {
        viewModel.Product.Picture.Id(result.Picture.Id);
        viewModel.Product.Picture.Url(result.Picture.Url);
    }
    viewModel.Product.ProductBrand(result.ProductBrand);
    viewModel.Product.Items(result.Items);
    viewModel.Product.LikesCount(result.LikesCount);
    viewModel.Product.Status.Name(result.Status.Name);
    viewModel.Product.Status.Label(result.Status.Label);
    viewModel.Product.LastPrice(result.LastPrice);
    viewModel.Product.Price(result.Price);
    viewModel.Product.DiscountPrice(result.DiscountPrice);
    viewModel.Product.Document(result.Document);
    viewModel.Product.Pictures(result.Pictures);
    viewModel.Product.Colors(result.Colors);
    viewModel.Product.Sizes(result.Sizes);
    viewModel.Product.Active(result.Active);
}

function updateViewModelAccount(result) {
    var entity = result.Value;
    viewModel.Account.Address(entity.Address);
    viewModel.Account.Company(entity.Company);
    viewModel.Account.CompanyNo(entity.CompanyNo);
    viewModel.Account.Email(entity.Email);
    viewModel.Account.FullName(entity.FullName);
    viewModel.Account.Job(entity.Job);
    viewModel.Account.Mobile(entity.Mobile);
    viewModel.Account.BirthDate(entity.BirthDate);
    viewModel.Account.NationalCode(entity.NationalCode);
    viewModel.Account.Phone(entity.Phone);
    viewModel.Account.Agent(entity.Agent);
    viewModel.Account.AgentPhone(entity.AgentPhone);
    viewModel.Account.IsMale(entity.IsMale);
    viewModel.Account.TrackingCode(entity.TrackingCode);
    viewModel.Account.IsOnline(true);
    viewModel.Account.IsRecover(false);
    viewModel.Account.CreditAmount(entity.CreditAmount);
    viewModel.Account.Items(entity.Items);
}

function clearViewModelAccount() {
    viewModel.Account.Address(null);
    viewModel.Account.Company(null);
    viewModel.Account.CompanyNo(null);
    viewModel.Account.Email(null);
    viewModel.Account.FullName(null);
    viewModel.Account.Job(null);
    viewModel.Account.Mobile(null);
    viewModel.Account.BirthDate(null);
    viewModel.Account.NationalCode(null);
    viewModel.Account.Phone(null);
    viewModel.Account.Agent(null);
    viewModel.Account.AgentPhone(null);
    viewModel.Account.IsMale(true);
    viewModel.Account.TrackingCode(null);
    viewModel.Account.IsOnline(false);
    viewModel.Account.IsRecover(false);
    if (viewModel.Account.Grade !== null) {
        viewModel.Account.Grade.Id(null);
        viewModel.Account.Grade.Name(null);
        viewModel.Account.Grade.MinScore(null);
        viewModel.Account.Grade.DiscountPercent(null);
        viewModel.Account.Grade.CreditPercent(null);
    }
}

function updateViewModelShopReseller(result) {
    var reseller = result.Value;
    viewModel.ShopReseller.Name(reseller.Name);
    viewModel.ShopReseller.Website(reseller.Website);
    if (reseller.Picture !== null) {
        viewModel.ShopReseller.PictureId(reseller.Picture.Id);
        viewModel.ShopReseller.Picture.Id(reseller.Picture.Id);
        viewModel.ShopReseller.Picture.Url(reseller.Picture.Url);
    }
}

function doAddAddress(request, btn, callback) {
    if (viewModel.Account.Addresses.Item.Id() === 0) {
        request.type = apirequest.type.Post;
    } else {
        request.type = apirequest.type.Put;
    }
    request.url = request.url + codeprocess.api.address.name;
    request.data = ko.toJSON(viewModel.Account.Addresses.Item);
    request.success = function (result) {
        if (doApiCallBack(result, callback) === true) {
            viewModel.Account.Addresses.List(result.Value);
        }
    };
}

function doRemoveAddress(request, btn, callback) {
    var addressId = $(btn).attr("address-id");
    request.type = apirequest.type.Delete;
    request.url = request.url + codeprocess.api.address.name + "?addressId=" + addressId;
    request.success = function (result) {
        if (doApiCallBack(result, callback) === true) {
            viewModel.Account.Addresses.List(result.Value);
        }
    };
}

function doRemoveAddressAjax(data, event) {
    var request = createRequest();
    var btn = $(event.target).parent();
    if ($(btn).attr("address-id") === undefined) {
        btn = $(event.target);
    }
    var addressId = $(btn).attr("address-id");
    var callback = $(btn).attr(codeprocess.callback.name);
    doRemoveAddress(request, btn, callback);
    $.ajax(request);
}

function doProductLikeAjax(data, event)
{
    var request = createRequest();
    var btn = $(event.target).parent();
    var callback = $(btn).attr(codeprocess.callback.name);
    doProductLike(request, btn, callback);
    $.ajax(request);
}

function doProductLike(request, btn, callback) {
    var productId = $(btn).attr("product-id");
    var functionName = $(btn).attr(codeprocess.function);
    if (functionName === codeprocess.api.productlike.add)
    {
        request.type = apirequest.type.Post;
        request.url = request.url + codeprocess.api.productlike.name + "?productId=" + productId;
        request.success = function (result) {
            if (doApiCallBack(result, callback) === true) {
                $(btn).attr(codeprocess.function, codeprocess.api.productlike.remove);
                viewModel.Account.Favorites(result.Value);
            }
        };
    }
    else
    {
        request.type = apirequest.type.Delete;
        request.url = request.url + codeprocess.api.productlike.name + "?productId=" + productId;
        request.success = function (result) {
            if (doApiCallBack(result, callback) === true) {
                $(btn).attr(codeprocess.function, codeprocess.api.productlike.add);
                viewModel.Account.Favorites(result.Value);
            }
        };
    }
}

function doProductCommentLike(request, btn, callback) {
    var commentId = $(btn).attr("comment-id");
    var functionName = $(btn).attr(codeprocess.function);
    if (functionName === codeprocess.api.productcommentlike.add) {
        request.type = apirequest.type.Post;
        request.url = request.url + codeprocess.api.productcommentlike.name + "?commentId=" + commentId;
        request.success = function (result) {
            if (doApiCallBack(result, callback) === true) {
                $(btn).attr(codeprocess.function, codeprocess.api.productcommentlike.remove);
                
            }
        };
    }
    else {
        request.type = apirequest.type.Delete;
        request.url = request.url + codeprocess.api.productcommentlike.name + "?commentId=" + commentId;
        request.success = function (result) {
            if (doApiCallBack(result, callback) === true) {
                $(btn).attr(codeprocess.function, codeprocess.api.productcommentlike.add);
                
            }
        };
    }
}

function doProductNotify(request, btn, callback) {
    var productId = $(btn).attr("product-id");
    var colorId = $(btn).attr("product-color-id");
    var sizeId = $(btn).attr("product-size-id");
    request.type = apirequest.type.Post;
    request.url = request.url + codeprocess.api.productnotify.name + "?productId=" + productId + "&colorId=" + colorId + "&sizeId=" + sizeId;
}

function doProductNotifyRemove(request, btn, callback) {
    var productId = $(btn).attr("product-id");
    request.type = apirequest.type.Delete;
    request.url = request.url + codeprocess.api.productnotify.name + "?productId=" + productId;
}

function doProductNotifyDiscount(request, btn, callback) {
    var productId = $(btn).attr("product-id");
    request.type = apirequest.type.Post;
    request.url = request.url + codeprocess.api.productnotifydiscount.name + "?productId=" + productId;
}

function doProductRate(request, btn, callback) {
    var productId = $(btn).attr("product-id");
    var rateValue = $(btn).attr("rate-value");
    request.type = apirequest.type.Post;
    request.url = request.url + codeprocess.api.productrate.name + "?productId=" + productId + "&rateValue=" + rateValue;
    request.success = function (result) {
        doApiCallBack(result, callback);
    };
}

function doApiCallBack(result, callback, msg) {
    if (result.Code === apirequest.status.Exception) {
        if (msg !== "no-message")
            createMessage("error", "خطای سرور");
        return false;
    } else if (result.Code === apirequest.status.Success) {
        if (msg !== "no-message")
            createMessage("success", result.Message);
        doCodeprocessCallback(callback);
        return true;
    } else if (result.Code === apirequest.status.InvalidKey) {
        var login = "<a href='/login?back=" + window.location.pathname + "'>باید ابتدا در سیستم وارد شوید</a>";
        if (msg !== "no-message")
            createMessage("error", login);
        return false;
    } else if (result.Code === apirequest.status.Error) {
        if (msg !== "no-message" || msg === undefined)
            createMessage("error", result.Message);
        return false;
    }
}

function doCodeprocessCallback(callbackFunctions) {
    if (callbackFunctions !== undefined) {
        var funcArray = callbackFunctions.toString().split(',');
        for (var i = 0; i < funcArray.length; i++) {
            try {
                window[funcArray[i]]();
            }
            catch (e) { console.log(e) }
        }
    }   
}

function doGetBasket(callback) {
    var request = createRequest();
    request.url = request.url + codeprocess.api.basket.name;
    request.success = function (result) {
        if (result.Code === apirequest.status.Success) {
            doCodeprocessCallback(callback);
            updateViewModelBasket(result);
        }
    }
    $.ajax(request);
}

function doGetProduct(Id, callback) {
    var request = createRequest();
    request.url = request.url + codeprocess.api.product.name + "?Id=" + Id;
    request.success = function (result) {
        if (result.Code === apirequest.status.Success) {
            doCodeprocessCallback(callback);
            updateViewModelProduct(result.Value);
        }
    }
    $.ajax(request);
}

function doGetCurrentAccount(callback) {
    var request = createRequest();
    request.url = request.url + codeprocess.api.account.name;
    request.success = function (result) {
        if (result.Code === apirequest.status.Success) {
            updateViewModelAccount(result);
            doCodeprocessCallback(callback);
        }
    }
    $.ajax(request);
}

function doGetStateList(callback) {
    var request = createRequest();
    request.url = request.url + codeprocess.api.state.name;
    request.success = function (result) {
        if (result.Code === apirequest.status.Success) {
            viewModel.StateList(result.Value);
            doCodeprocessCallback(callback);
        }
    };
    $.ajax(request);
}

function doGetCityList(stateId) {
    var request = createRequest();
    request.url = request.url + codeprocess.api.city.name + "?stateId=" + stateId;
    request.success = function (result) {
        if (result.Code === apirequest.status.Success) {
            viewModel.CityList(result.Value);
            viewModel.Account.Addresses.Item.CityId(viewModel.Account.Addresses.Item.City.Id());
        }
    };
    $.ajax(request);
}

function doGetAccountAddresses(callback) {
    var request = createRequest();
    request.url = request.url + codeprocess.api.address.name;
    request.success = function (result) {
        if (result.Code === apirequest.status.Success) {
            viewModel.Account.Addresses.List(result.Value);
            doCodeprocessCallback(callback);
        }
    };
    $.ajax(request);
}

function doGetProductLikes(callback) {
    var request = createRequest();
    request.url = request.url + codeprocess.api.productlike.name;
    request.success = function (result) {
        if (result.Code === apirequest.status.Success) {
            viewModel.Account.Favorites(result.Value);
            doCodeprocessCallback(callback);
        }
    };
    $.ajax(request);
}

function doGetShopReseller(callback) {
    var request = createRequest();
    request.url = request.url + codeprocess.api.shopreseller.name;
    request.success = function (result) {
        if (result.Code === apirequest.status.Success) {
            updateViewModelShopReseller(result);
            doCodeprocessCallback(callback);
        }
    };
    $.ajax(request);
}

function doGetShopResellerProducts(callback) {
    var request = createRequest();
    request.url = request.url + codeprocess.api.shopresellerproduct.name;
    request.success = function (result) {
        if (result.Code === apirequest.status.Success) {
            viewModel.ShopReseller.ShopResellerProducts(result.Value);
            doCodeprocessCallback(callback);
        }
    };
    $.ajax(request);
}

function doGetShopResellerCollection(callback) {
    var resellerId = $("#RequestShopResellerId").val();
    var request = createRequest();
    request.url = request.url + codeprocess.api.shopresellercollection.name;
    if (resellerId !== undefined) {
        request.url = request.url + "&resellerId=" + resellerId;
    }
    request.success = function (result) {
        if (result.Code === apirequest.status.Success) {
            viewModel.ShopReseller.ShopResellerCollections(result.Value);
            doCodeprocessCallback(callback);
        }
    };
    $.ajax(request);
}

function doShopResellerFollow(request, btn, callback) {
    var resellerId = $(btn).attr("reseller-id");
    console.log(resellerId);
    var functionName = $(btn).attr(codeprocess.function);
    if (functionName === codeprocess.api.shopresellerfollow.add) {
        request.type = apirequest.type.Post;
        request.url = request.url + codeprocess.api.shopresellerfollow.name + "?resellerId=" + resellerId;
        request.success = function (result) {
            if (doApiCallBack(result, callback) === true) {
                $(btn).attr(codeprocess.function, codeprocess.api.shopresellerfollow.remove);
            }
        };
    }
    else {
        request.type = apirequest.type.Delete;
        request.url = request.url + codeprocess.api.shopresellerfollow.name + "?resellerId=" + resellerId;
        request.success = function (result) {
            if (doApiCallBack(result, callback) === true) {
                $(btn).attr(codeprocess.function, codeprocess.api.shopresellerfollow.add);
            }
        };
    }
}

function doGetShopResellerGallery(callback) {
    var request = createRequest();
    request.url = request.url + codeprocess.api.shopresellergallery.name;
    request.success = function (result) {
        if (result.Code === apirequest.status.Success) {
            viewModel.ShopReseller.ShopResellerGalleries(result.Value);
            doCodeprocessCallback(callback);
        }
    };
    $.ajax(request);
}

function doRemoveShopResellerGallery(request, btn, callFunction) {
    var galleryId = $(btn).attr("gallery-id");
    request.url = request.url + codeprocess.api.shopresellergallery.name + "?galleryId=" + galleryId;
    request.type = apirequest.type.Delete;
    request.success = function (result) {
        if (result.Code === apirequest.status.Success) {
            viewModel.ShopReseller.ShopResellerGalleries(result.Value);
            doCodeprocessCallback(callFunction);
        }
    };
}

function doGetShopResellerStories(callback) {
    var request = createRequest();
    request.url = request.url + codeprocess.api.shopresellerstory.name;
    request.success = function (result) {
        if (result.Code === apirequest.status.Success) {
            viewModel.ShopReseller.ShopResellerStories(result.Value);
            doCodeprocessCallback(callback);
        }
    }
    $.ajax(request);
}

function doGetShopResellerProductTypeReport(callback) {
    var request = createRequest();
    request.url = request.url + codeprocess.api.shopresellerproducttypereport.name;
    request.success = function (result) {
        if (result.Code === apirequest.status.Success) {
            viewModel.ShopReseller.ShopResellerProductTypeReport(result.Value);
            doCodeprocessCallback(callback);
        }
    }
    $.ajax(request);
}

function initializeProfileCommonAddressPageScript() {
    doGetAccountAddresses();

    $("#btnAddNewAddress").click(function () {
        clearViewModelAccountAddressItem();
        $("#modalAddressNew").modal("show");
    });

    doGetStateList("doGetCityListForAddressProfile");
}

function doGetCityListForAddressProfile() {
    viewModel.Account.Addresses.Item.StateId.subscribe(() => {
        doGetCityList(viewModel.Account.Addresses.Item.StateId());
    });
}

function closeProfileModal() {
    $(".modal").modal("hide");
}

function clearProfileAddressModal() {
    clearViewModelAccountAddressItem();
}

function showProfileModalAddressForEdit(data, event) {
    updateViewModelAccountAddressItem(data);
    $("#modalAddressNew").modal("show");
}

function showProfileModalAddressForDelete(data, target) {
    $("#btnRemoveAddressItem").attr("address-id", data.Id);
    $("#modalAddressRemove").modal("show");
}

function initalizeOrdersPageScript() {
    $(".detailes-order").click(function () {
        $(this).toggleClass("displaced");
        var showDetails = $(this).closest(".orders-history").find(".datails-table");
        $(showDetails).toggleClass("show-up");
        $(this).closest(".order-row").toggleClass("show-table");

    });
}