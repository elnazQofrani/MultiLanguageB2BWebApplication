function initializeCommonScript() {
    doGetCurrentAccount();
    doGetBasket();

	initializeMainMenuScript();
    initializeResponsiveMenuScript();
    initializeTopNavTitleScript();
}

function initializeTopNavTitleScript() {
    setInterval(function () {
        var showIndex = $(".top-nav-title .active").attr("show-index");
        showIndex = parseInt(showIndex) + 1;
        showIndex = isNaN(showIndex) === true ? 0 : showIndex;

        $(".top-nav-title .active").removeClass("active");
        $(".top-nav-title [show-index='" + showIndex + "']").addClass("active");

    }, 5000);
}

function initializeHomePageScript() {
	var mainSlider = new Swiper('.main-slider', {
		autoplay: true,
		pagination: {
			el: '.main-slider-pagination',
			clickable: true
		},
		navigation: {
			nextEl: '.main-slider-next',
			prevEl: '.main-slider-prev',
		},
    });

    var productSlider = new Swiper('.product-slider', {
        navigation: {
            nextEl: '.right-swiper-products',
            prevEl: '.left-swiper-products',
        },
        loop: true,
        slidesPerView: 1,
        spaceBetween: 5,
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        breakpoints: {
            640: {
                slidesPerView: 2,
                spaceBetween: 20,
            },
            768: {
                slidesPerView: 4,
                spaceBetween: 40,
            },
            1024: {
                slidesPerView: 4,
                spaceBetween: 50,
            },
        }
    });

    var brandSwiper = new Swiper('.brands-swiper', {
        loop: true,
        slidesPerView: 2,
        spaceBetween: 15,
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        breakpoints: {
            640: {
                slidesPerView: 2,
                spaceBetween: 20,
            },
            1024: {
                slidesPerView: 6,
                spaceBetween: 30,
            },
        }
    });
}

function initializeMainMenuScript() {
	$(".sub-side-menu li").hover(function() {
		var thisId = $(this).attr("category-id");
		$(".sub-side-menu li").removeClass("active");
		$(this).addClass("active");
		$("[menu-category-id]").removeClass("active");
		$("[menu-category-id='" + thisId + "']").addClass("active");
	}, function() {
		
	});
}

function initializeResponsiveMenuScript() {
	$(".mobile-menu-trigger").click(function() {
		$(".overlay").addClass("show-up");
		$(".menu-mobile").addClass("show-up");
	});
	
	$(".close-menu, .close-mobile-menu").click(function() {
		$(".overlay").removeClass("show-up");
		$(".menu-mobile").removeClass("show-up");
	});
	
	$('.has-sub').click(function () {
		$(this).toggleClass('lv-show');
	});
	
	$('.mob-menu-tr').click(function () {
		$('.mob-menu').addClass('op-menu');
	});
	
	$('.close-mob').click(function () {
		$('.mob-menu').removeClass('op-menu');
	});
	
	$('.mob-menu-ov').click(function () {
		$('.mob-menu').removeClass('op-menu');
	});
	
	$('.search-tr').click(function () {
		$('.mob-search').addClass('show-search');
	});
	
	$('.close-mob-search').click(function () {
		$('.mob-search').removeClass('show-search');
	});
}

function initializeProductPageScript() {
	$(".tab-title").click(function () {
		var currentTab = $(this).attr("target-tab");
        $(".current-tab").removeClass("current-tab");
        $(this).addClass("current-tab");
		
		$(".tab-pane").removeClass("in active");
		$(".tab-pane").addClass("fade");
		$(currentTab).removeClass("fade");
		$(currentTab).addClass("in active");
    });
	
    var productSlider = new Swiper('.product-slider', {
        navigation: {
            nextEl: '.right-swiper-products',
            prevEl: '.left-swiper-products',
        },
        loop: true,
        slidesPerView: 1,
        spaceBetween: 5,
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        breakpoints: {
            640: {
                slidesPerView: 2,
                spaceBetween: 20,
            },
            768: {
                slidesPerView: 4,
                spaceBetween: 40,
            },
            1024: {
                slidesPerView: 4,
                spaceBetween: 50,
            },
        }
    });
}

function initializeSearchPageScript() {
    doRangeSlider("slider-range-1", 1, "printernalfrom", "printernalto");
    doRangeSlider("slider-range-2", 2, "prexternalfrom", "prexternalto");
    doRangeSlider("slider-range-3", 3, "prheightfrom", "prheightto");
	
	$("[change-show-type]").click(function() {
        $("[show-type]").attr("show-type", $(this).attr("change-show-type"));
        $("[change-show-type].active").removeClass("active");
        $(this).addClass("active");
    });

    $("[name='prorder']").change(function () {
        doSubmit();
    });
}

function initalizeBasketPageScript() {
    doGetBasket();
}

function initializeBlogIndexPageScript() {
    var mainSlider = new Swiper('.swiper-container', {
        autoplay: true,
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
    });
}

function gotoRecoverPage() {
    document.location = "/account/recovermobile";
}

function gotoHomePage() {
    document.location = "/";
}

function doSubmit() {
    $("#frmSearch").submit();
}

function doRangeSlider(id, index, from, to) {
    var startValue = parseInt($("#" + from).val());
    var endValue = parseInt($("#" + to).val());

    startValue = isNaN(startValue) ? 0 : startValue;
    endValue = isNaN(endValue) ? 200 : endValue;
    
    var keypressSlider = document.getElementById(id);
    noUiSlider.create(keypressSlider, {
        start: [startValue, endValue],
        connect: true,
        direction: 'rtl',
        range: {
            'min': 0,
            'max': 200
        }
    });

    keypressSlider.noUiSlider.on('change', function (values, handle) {
        $("[price-index='" + handle + "']").val(values[handle]);
        doSubmit();
    });

    keypressSlider.noUiSlider.on('update', function (values, handle) {
		var intValue = parseInt(values[handle].toString());
        if (handle === 0) {
            $("#lblRange" + index + "MinValue").val(intValue);
            $("#" + from).val(intValue);
        } else {
            $("#lblRange" + index + "MaxValue").val(intValue);
            $("#" + to).val(intValue);
        }
        $("[price-index='" + handle + "']").html(values[handle]);
    });

    $("#lblRange" + index + "MinValue").keyup(function () {
        var thisValue = parseFloat($(this).val());
        if (isNaN(thisValue) === false) {
            keypressSlider.noUiSlider.set([thisValue, null]);
        }
    });

    $("#lblRange" + index + "MaxValue").keyup(function () {
        var thisValue = parseFloat($(this).val());
        if (isNaN(thisValue) === false) {
            keypressSlider.noUiSlider.set([null, thisValue]);
        }
    });

    $("#lblRange" + index + "MinValue").change(function () {
        doSubmit();
    });

    $("#lblRange" + index + "MaxValue").change(function () {
        doSubmit();
    });
}

function gotoBackPage() {
    document.location = $("#inputBackPage").val();
}